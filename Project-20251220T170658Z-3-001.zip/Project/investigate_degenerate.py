"""Deep dive: Are solutions REALLY equivalent, or is something broken?"""
import numpy as np
from core.data import load_and_prepare
from core.custom_objectives import CustomObjectiveBuilder
from core.optimize import OptimizationEngine
from core.marginal import MarginalContributionEngine

raw, norm = load_and_prepare('fleet_sample.csv')

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])
builder.add_objective('Operations', ['maintenance_cost_per_year', 'downtime_cost_per_day'], [0.6, 0.4])
builder.add_objective('Asset Quality', ['reliability_score', 'remaining_useful_life'], [0.7, 0.3])

objectives = builder.build()

feas = {
    'budget': 7_000_000,
    'service_level': 0.95,
    'charging_capacity': 50,
    'min_fleet_size': 3,
}

print("=" * 70)
print("INVESTIGATING DEGENERATE SOLUTIONS")
print("=" * 70)

# Baseline
opt = OptimizationEngine(raw, norm, objectives, feas)
x_base, obj_base = opt.solve()
selected_base = [i for i in range(10) if x_base[i] > 0.5]
cost_base = raw.iloc[selected_base]['capex_ev'].sum()

print(f"\nBASELINE SOLUTION")
print(f"  Selected vehicles: {selected_base}")
print(f"  Budget used: ₹{cost_base:,.0f} / ₹7M")
print(f"  Objectives:")
for obj_name, val in obj_base.items():
    print(f"    {obj_name}: {val:.6f}")

# Remove each vehicle and compare
print(f"\nREMOVING EACH BASELINE VEHICLE:")
for vehicle in selected_base:
    raw_mod = raw.drop(index=vehicle).reset_index(drop=True)
    norm_mod = norm.drop(index=vehicle).reset_index(drop=True)
    
    opt_mod = OptimizationEngine(raw_mod, norm_mod, objectives, feas)
    x_mod, obj_mod = opt_mod.solve()
    selected_mod = [i for i in range(10) if i != vehicle and x_mod[i-1 if i > vehicle else i] > 0.5]
    # (index mapping is complex, just check objectives)
    
    print(f"\n  Remove V{vehicle:02d}:")
    changes = []
    for obj_name in objectives.keys():
        diff = obj_mod[obj_name] - obj_base[obj_name]
        status = "✓ SAME" if abs(diff) < 1e-6 else f"CHANGED {diff:+.6f}"
        print(f"    {obj_name}: {status}")
        if abs(diff) >= 1e-6:
            changes.append(obj_name)
    
    if not changes:
        print(f"    → ALL OBJECTIVES UNCHANGED (purely equivalent solution)")
    else:
        print(f"    → {', '.join(changes)} changed")
