import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import hashlib

from core.data import load_and_prepare
from core.objective_composer import ObjectiveCompositionEngine, PolicyState
from core.optimize import OptimizationEngine
from core.montecarlo import MonteCarloEngine
from core.projection import ProjectionEngine
from core.explainability import ExplainabilityEngine

# ======================================================
# Page config
# ======================================================
st.set_page_config(layout="wide")
st.title("HOSF – Explainable & Robust Decision Intelligence")
st.caption(
    "Target-driven optimization • Monte Carlo robustness • Actionable recommendations"
)

# ======================================================
# Utilities
# ======================================================
def hash_dict(d):
    return hashlib.md5(str(sorted(d.items())).encode()).hexdigest()

# ======================================================
# Session State
# ======================================================
for k in [
    "engine_ran",
    "result_df",
    "marginal_contributions",
    "x_star",
    "last_feas_hash",
    "last_obj_hash",
    "projection_engine",
    "vehicle_ids",
]:
    if k not in st.session_state:
        st.session_state[k] = None

# ======================================================
# Upload
# ======================================================
uploaded = st.sidebar.file_uploader("Upload Fleet CSV", type="csv")
if not uploaded:
    st.info("⬅️ Upload fleet data to begin")
    st.stop()

raw_df, norm_df = load_and_prepare(uploaded)

# ======================================================
# Objective Builder (DYNAMIC & CONFIGURABLE)
# ======================================================
st.sidebar.subheader("Policy Configuration")

# Create checkboxes with unique keys
ev_mandate = st.sidebar.checkbox("EV Mandate", False, key="policy_ev_mandate")
subsidy_active = st.sidebar.checkbox("Subsidy Program", False, key="policy_subsidy_active")
carbon_tax = st.sidebar.checkbox("Carbon Tax", False, key="policy_carbon_tax")

# Create conditional inputs based on checkbox values
subsidy_fraction = (st.sidebar.slider("Subsidy %", 0.0, 50.0, 0.0, key="policy_subsidy_fraction") / 100.0) if subsidy_active else 0.0
carbon_tax_per_gco2 = st.sidebar.number_input("Tax (INR/gCO2)", 0.0, 5.0, 0.0, key="policy_carbon_tax_amount") if carbon_tax else 0.0

# Build objectives using OCE
policy_state = PolicyState(
    EV_mandate=ev_mandate,
    subsidy_active=subsidy_active,
    subsidy_fraction=subsidy_fraction,
    carbon_tax=carbon_tax,
    carbon_tax_per_gco2=carbon_tax_per_gco2,
    emission_cap_gpkm=st.sidebar.number_input("Emission Cap (gCO2/km)", 50.0, 200.0, 100.0, key="policy_emission_cap"),
    region=st.sidebar.selectbox("Region", ["India", "Europe", "US"], key="policy_region"),
    year=st.sidebar.number_input("Year", 2025, 2030, 2025, key="policy_year")
)

oce = ObjectiveCompositionEngine(raw_df, norm_df, policy_state)
objectives = oce.build_objectives()
objectives = oce.apply_policy_modifiers()

objective_config = objectives
objective_weights = {}

objective_names = list(objectives.keys())
st.sidebar.subheader("Objective Preferences")

for name in objective_names:
    weight = st.sidebar.slider(
        f"{name} weight",
        0.0, 1.0, 0.25,
        step=0.05,
        label_visibility="collapsed",
        key=f"weight_{name}"
    )
    objective_weights[name] = weight

# Normalize weights
weight_sum = sum(objective_weights.values())
if weight_sum > 0:
    objective_weights = {k: v / weight_sum for k, v in objective_weights.items()}

# ---------- dynamic objective refresh ----------
obj_hash = hash_dict(objective_config)
if obj_hash != st.session_state.last_obj_hash:
    st.session_state.result_df = None
    st.session_state.marginal_contributions = None
    st.session_state.x_star = None
    st.session_state.last_obj_hash = obj_hash

# ======================================================
# Feasibility (dynamic)
# ======================================================
st.sidebar.subheader("Feasibility Constraints")

budget = st.sidebar.number_input(
    "Total Budget", 1_000_000, 50_000_000, 10_000_000, step=250_000
)
min_service = st.sidebar.slider("Minimum Service Level", 0.0, 30.0, 8.0)
max_charging = st.sidebar.slider("Charging Capacity", 1, 200, 50)

feasibility = {
    "budget": budget,
    "min_service_level": min_service,
    "max_charging_load": max_charging,
}

feas_hash = hash_dict(feasibility)
if feas_hash != st.session_state.last_feas_hash:
    st.session_state.result_df = None
    st.session_state.marginal_contributions = None
    st.session_state.x_star = None
    st.session_state.last_feas_hash = feas_hash

# ======================================================
# Explicit run (structure changes)
# ======================================================
if st.sidebar.button("🚀 Run Decision Engine"):
    st.session_state.engine_ran = True
    st.session_state.result_df = None

if not st.session_state.engine_ran:
    st.stop()

# ======================================================
# Compute Engine
# ======================================================
if st.session_state.result_df is None:
    with st.spinner("⏳ Computing optimization & Monte Carlo..."):
        try:
            # Objectives already built and modified via OCE above
            opt = OptimizationEngine(raw_df, norm_df, objective_config, feasibility)
            x_star, _ = opt.solve()

            mc = MonteCarloEngine(
                raw_df,
                oce,
                feasibility,
                n_scenarios=40
            )
            marginal_contributions = mc.run()  # Dict[objective_name -> ndarray(S, N)]

            # Initialize projection engine
            vehicle_ids = raw_df["vehicle_id"].tolist()
            projection_engine = ProjectionEngine(
                marginal_contributions,
                vehicle_ids,
                list(objective_config.keys())
            )

            # Get summary with configured weights
            st.session_state.result_df = projection_engine.get_summary_table(objective_weights)
            st.session_state.marginal_contributions = marginal_contributions
            st.session_state.projection_engine = projection_engine
            st.session_state.vehicle_ids = vehicle_ids
            st.session_state.x_star = x_star
            
            st.success("✅ Computation complete!")
        except Exception as e:
            st.error(f"❌ Error: {str(e)}")
            st.stop()

df = st.session_state.result_df
projection_engine = st.session_state.projection_engine
vehicle_ids = st.session_state.vehicle_ids
marginal_contributions = st.session_state.marginal_contributions

# ======================================================
# 🎨 CLASS COLORS (NEW PALETTE)
# ======================================================
CLASS_COLORS = {
    "Feasibility-Critical": "#d73027",
    "High-Priority Robust": "#1a9850",
    "High-Priority Sensitive": "#fdae61",
    "Medium-Priority": "#4575b4",
    "Low-Priority Robust": "#dddddd",
    "Low-Priority Sensitive": "#c2a5cf",
}

CLASS_RECOMMENDATIONS = {
    "Feasibility-Critical":
        "Mandatory asset. System infeasible without this vehicle. Act immediately.",
    "High-Priority Robust":
        "Strong and stable priority. Recommended for immediate replacement.",
    "High-Priority Sensitive":
        "High impact but sensitive to uncertainty. Evaluate across policy scenarios.",
    "Medium-Priority":
        "Moderate importance. Address after high-priority vehicles.",
    "Low-Priority Robust":
        "Low impact and stable. Safe to defer.",
    "Low-Priority Sensitive":
        "Low impact but volatile. Monitor only if conditions change."
}

# ======================================================
# Explainability helper
# ======================================================
def explain_class(row):
    rpi = row["RPI"]
    vol = row["Volatility"]
    cls = row["Classification"]

    if cls == "Feasibility-Critical":
        return "Removing this vehicle violates one or more hard feasibility constraints."

    if "High-Priority" in cls:
        return (
            f"High marginal impact (RPI={rpi:.2f}). "
            + ("Stable across scenarios." if "Robust" in cls
               else "Sensitive to scenario uncertainty.")
        )

    if cls == "Medium-Priority":
        return (
            f"Moderate marginal impact (RPI={rpi:.2f}). "
            "Priority depends on strategic preferences."
        )

    if "Low-Priority" in cls:
        return (
            f"Low marginal impact (RPI={rpi:.2f}). "
            + ("Consistently low impact." if "Robust" in cls
               else "Low impact with variability.")
        )

    return "No explanation available."

# ======================================================
# Prepare display table
# ======================================================
display_df = df.copy()
display_df.insert(0, "Action Order", range(1, len(display_df) + 1))
display_df["Recommendation"] = display_df["Classification"].map(CLASS_RECOMMENDATIONS)
display_df["Explanation"] = display_df.apply(explain_class, axis=1)

# ======================================================
# WEIGHT ADJUSTMENT (DYNAMIC)
# ======================================================
st.divider()
st.subheader("⚙️ Adjust Objective Weights (Live Updates)")
st.write("Change weights below to see rankings update instantly:")

col_weights = st.columns(len(objective_weights))
adjusted_weights = {}

for col, (obj_name, base_weight) in zip(col_weights, objective_weights.items()):
    with col:
        adjusted_weights[obj_name] = st.slider(
            obj_name,
            0.0, 1.0,
            value=base_weight,
            step=0.05,
            label_visibility="collapsed",
            key=f"weight_adj_{obj_name}"
        )

# Normalize adjusted weights
weight_sum = sum(adjusted_weights.values())
if weight_sum > 0:
    adjusted_weights = {k: v / weight_sum for k, v in adjusted_weights.items()}

# Recompute summary table with adjusted weights
df = projection_engine.get_summary_table(adjusted_weights)

# Prepare display table with adjusted rankings
display_df = df.copy()
display_df.insert(0, "Action Order", range(1, len(display_df) + 1))
display_df["Recommendation"] = display_df["Classification"].map(CLASS_RECOMMENDATIONS)
display_df["Explanation"] = display_df.apply(explain_class, axis=1)

# Gradient styling by RPI
rpi_vals = display_df["RPI"].replace(np.inf, np.nan)
rpi_min, rpi_max = rpi_vals.min(), rpi_vals.max()

def rpi_gradient(val):
    if not np.isfinite(val):
        return ""
    intensity = (val - rpi_min) / (rpi_max - rpi_min + 1e-9)
    alpha = 0.2 + 0.8 * intensity
    return f"background-color: rgba(0, 123, 255, {alpha})"

def style_row(row):
    styles = []
    base_color = CLASS_COLORS.get(row["Classification"], "white")
    for col in row.index:
        if col == "RPI":
            styles.append(rpi_gradient(row[col]))
        else:
            styles.append(f"background-color: {base_color}")
    return styles

styled_df = display_df.style.apply(style_row, axis=1)

# ======================================================
# RESULTS TABLE
# ======================================================
st.subheader("📊 Replacement Priority Index – Decision View")

st.markdown("### 🎯 Priority Classes & Actions")
for cls, color in CLASS_COLORS.items():
    st.markdown(
        f"<div style='background-color:{color}; padding:8px; border-radius:6px; margin-bottom:6px;'>"
        f"<b>{cls}</b>: {CLASS_RECOMMENDATIONS[cls]}</div>",
        unsafe_allow_html=True
    )

st.markdown("🟦 **RPI Gradient**: darker = higher priority")

st.data_editor(
    styled_df,
    width='stretch',
    hide_index=True,
    disabled=True
)

# ======================================================
# 🔥 RPI BAR
# ======================================================
st.markdown("### 🔥 Priority Intensity (RPI)")
fig_rpi = px.bar(
    df,
    x="vehicle_id",
    y="RPI",
    color="RPI",
    color_continuous_scale="Blues"
)
st.plotly_chart(fig_rpi, width='stretch')

# ======================================================
# 🎚 Monte Carlo Scenario Explorer
# ======================================================
st.markdown("### 🎚 Monte Carlo Scenario Explorer")

n_scenarios = next(iter(marginal_contributions.values())).shape[0]

scenario_idx = st.slider(
    "Select Scenario",
    0,
    n_scenarios - 1,
    0
)

# Get weighted values for this scenario
weighted_vals, _ = projection_engine.project_scenario_slice(scenario_idx, objective_weights)

scenario_df = pd.DataFrame({
    "Vehicle": vehicle_ids,
    "Marginal Contribution": weighted_vals
})

fig_scen = px.bar(
    scenario_df.sort_values("Marginal Contribution", ascending=False).head(15),
    x="Vehicle",
    y="Marginal Contribution",
    color="Marginal Contribution",
    color_continuous_scale="RdYlGn",
    title=f"Scenario {scenario_idx + 1}: Weighted Marginal Contributions"
)
st.plotly_chart(fig_scen, width='stretch')

# ======================================================
# 🎬 Scenario Animation
# ======================================================
st.markdown("### 🎬 Scenario Animation")

n_scenarios = next(iter(marginal_contributions.values())).shape[0]

# Generate frames for each scenario
frames = []
for s in range(n_scenarios):
    weighted_vals, _ = projection_engine.project_scenario_slice(s, objective_weights)
    frames.append(
        go.Frame(
            data=[go.Bar(x=vehicle_ids, y=weighted_vals)],
            name=f"S{s+1}"
        )
    )

# Initial data (scenario 1)
weighted_vals_0, _ = projection_engine.project_scenario_slice(0, objective_weights)

fig_anim = go.Figure(
    data=[go.Bar(x=vehicle_ids, y=weighted_vals_0)],
    frames=frames
)

fig_anim.update_layout(
    updatemenus=[{
        "type": "buttons",
        "showactive": False,
        "buttons": [
            {"label": "▶ Play", "method": "animate",
             "args": [None, {"frame": {"duration": 500}, "fromcurrent": True}]},
            {"label": "⏸ Pause", "method": "animate",
             "args": [[None], {"frame": {"duration": 0}}]}
        ]
    }]
)

st.plotly_chart(fig_anim, width='stretch')

st.success("Decision intelligence dashboard updated")
