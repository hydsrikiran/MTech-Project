"""Check marginals with your balanced objectives and tight constraints"""
import numpy as np
from core.data import load_and_prepare
from core.custom_objectives import CustomObjectiveBuilder
from core.montecarlo_custom import MonteCarloEngineCustom

raw, norm = load_and_prepare('fleet_sample.csv')

# YOUR balanced objectives
builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])
builder.add_objective('Operations', ['maintenance_cost_per_year', 'downtime_cost_per_day'], [0.6, 0.4])
builder.add_objective('Asset Quality', ['reliability_score', 'remaining_useful_life'], [0.7, 0.3])

objectives = builder.build()

# YOUR tight constraints
feas = {
    'budget': 7_000_000,
    'service_level': 0.95,
    'charging_capacity': 50,
    'min_fleet_size': 3,
}

print("=" * 70)
print("MARGINAL INSPECTION - 5 SCENARIOS")
print("=" * 70)
print(f"Objectives: {list(objectives.keys())}")
print()

mc = MonteCarloEngineCustom(raw, norm, builder, feas, n_scenarios=5, seed=42)
marginals = mc.run()

print("\n" + "=" * 70)
print("FIRST SCENARIO MARGINALS")
print("=" * 70)

for obj_name, arr in marginals.items():
    scenario_0 = arr[0]  
    print(f"\n{obj_name}:")
    print(f"  Raw values: {scenario_0}")
    print(f"  Min={np.min(scenario_0):.6f}, Max={np.max(scenario_0):.6f}")
    print(f"  All zeros? {np.all(scenario_0 == 0)}")
    
print("\n" + "=" * 70)
print("ALL 5 SCENARIOS SUMMARY")
print("=" * 70)

for obj_name, arr in marginals.items():
    all_zero = np.all(arr == 0)
    print(f"{obj_name}: all_zero={all_zero}, min={np.min(arr):.6f}, max={np.max(arr):.6f}")
