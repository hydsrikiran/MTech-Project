import numpy as np
import pandas as pd

class RPIEngine:
    """
    Aggregates Monte Carlo marginal contributions
    into Replacement Priority Index (RPI)
    """

    def __init__(self, scenario_marginals, vehicle_ids=None):
        """
        scenario_marginals: ndarray shape (S, N)
        """
        self.marginals = scenario_marginals
        self.S, self.N = scenario_marginals.shape
        self.vehicle_ids = vehicle_ids or list(range(self.N))

    # -------------------------------
    # Compute RPI
    # -------------------------------

    def compute_rpi(self):
        rpi = np.mean(self.marginals, axis=0)
        return rpi

    # -------------------------------
    # Compute volatility
    # -------------------------------

    def compute_volatility(self):
        return np.std(self.marginals, axis=0)

    # -------------------------------
    # Top-K persistence probability
    # -------------------------------

    def top_k_probability(self, k=10):
        ranks = np.argsort(-self.marginals, axis=1)  # descending
        topk = ranks[:, :k]

        probs = []
        for i in range(self.N):
            count = np.sum(topk == i)
            probs.append(count / self.S)

        return np.array(probs)

    # -------------------------------
    # Classification
    # -------------------------------

    def classify(self):
        rpi = self.compute_rpi()
        vol = self.compute_volatility()

        finite_rpi = rpi[np.isfinite(rpi)]
        finite_vol = vol[np.isfinite(vol)]

        rpi_q75 = np.percentile(finite_rpi, 75)
        rpi_q25 = np.percentile(finite_rpi, 25)
        vol_q50 = np.percentile(finite_vol, 50)

        labels = []

        for i in range(self.N):
            if np.isinf(rpi[i]):
                labels.append("Feasibility-Critical")

            elif rpi[i] >= rpi_q75 and vol[i] <= vol_q50:
                labels.append("High-Priority Robust")

            elif rpi[i] >= rpi_q75 and vol[i] > vol_q50:
                labels.append("High-Priority Sensitive")

            elif rpi[i] <= rpi_q25 and vol[i] <= vol_q50:
                labels.append("Low-Priority Robust")

            elif rpi[i] <= rpi_q25 and vol[i] > vol_q50:
                labels.append("Low-Priority Sensitive")

            else:
                labels.append("Medium-Priority")

        return labels



    # -------------------------------
    # Final ranked output
    # -------------------------------

    def ranked_table(self):
        rpi = self.compute_rpi()
        vol = self.compute_volatility()
        labels = self.classify()

        df = pd.DataFrame({
            "vehicle_id": self.vehicle_ids,
            "RPI": rpi,
            "Volatility": vol,
            "Class": labels
        })

        class_order = {
            "Feasibility-Critical": 0,
            "Structurally Robust": 1,
            "Context-Sensitive": 2,
            "Low-Impact": 3,
            "Robustly Non-Critical": 4
        }

        df["ClassOrder"] = df["Class"].map(class_order)

        return (
            df
            .sort_values(
                by=["ClassOrder", "RPI", "Volatility"],
                ascending=[True, False, True]
            )
            .drop(columns=["ClassOrder"])
            .reset_index(drop=True)
        )

