"""
PROJECTION LAYER — Dynamic Re-Ranking Without Re-Optimization
================================================================

This module implements the critical "dynamic" component:
- Reweight RPI based on user objective preferences
- Project scenario outputs under new weights
- Enable instant UI updates without solver rerun

This is the KEY innovation that enables true interactivity.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional


class ProjectionEngine:
    """
    Projects cached Monte Carlo outputs under new objective weights.
    
    Allows instant ranking updates when targets/weights change WITHOUT
    re-running optimization or Monte Carlo.
    
    Mathematical basis:
    
    Projected_RPI_i = Σ_k ( w_k × normalized_marginal_contribution_ik )
    
    where:
        w_k = user-specified weight for objective k
        marginal_contribution_ik = marginal value of vehicle i under objective k
    """
    
    def __init__(
        self,
        scenario_marginals: np.ndarray,
        vehicle_ids: List[str],
        objective_names: List[str]
    ):
        """
        Parameters
        ----------
        scenario_marginals : dict
            {objective_name: ndarray(S, N)}
            S = number of scenarios
            N = number of vehicles
        vehicle_ids : List[str]
        objective_names : List[str]
        """
        self.scenario_marginals = scenario_marginals  # Dict[str, ndarray(S, N)]
        self.vehicle_ids = vehicle_ids
        self.objective_names = objective_names
        self.S, self.N = next(iter(scenario_marginals.values())).shape
        
        # Normalize each objective's marginals for fair weighting
        self._normalized_marginals = self._normalize_objectives()
    
    def _normalize_objectives(self) -> Dict[str, np.ndarray]:
        """
        Normalize marginals within each objective to [0, 1] scale.
        
        This ensures that objective weights are truly comparable and
        small/large absolute values don't dominate the weighting.
        """
        normalized = {}
        
        for obj_name, marginals in self.scenario_marginals.items():
            # Shape: (S, N)
            flat = marginals.flatten()
            finite = flat[np.isfinite(flat)]
            
            if len(finite) > 0:
                min_val = np.min(finite)
                max_val = np.max(finite)
                
                if max_val > min_val:
                    normalized[obj_name] = (marginals - min_val) / (max_val - min_val)
                else:
                    normalized[obj_name] = np.zeros_like(marginals)
            else:
                normalized[obj_name] = np.zeros_like(marginals)
        
        return normalized
    
    def project_rpi(self, objective_weights: Dict[str, float]) -> np.ndarray:
        """
        Compute weighted RPI under new objective preferences.
        
        Parameters
        ----------
        objective_weights : Dict[str, float]
            e.g., {'Economic': 0.5, 'Environmental': 0.3, 'Service': 0.2}
        
        Returns
        -------
        projected_rpi : ndarray(N,)
            Weighted mean marginal contribution across objectives
        """
        # Normalize weights
        total_weight = sum(objective_weights.values())
        if total_weight == 0:
            total_weight = 1.0
        
        weighted_marginals = np.zeros((self.S, self.N))
        
        for obj_name, weight in objective_weights.items():
            if obj_name in self._normalized_marginals:
                norm_weight = weight / total_weight
                weighted_marginals += norm_weight * self._normalized_marginals[obj_name]
        
        # Compute mean across scenarios
        projected_rpi = np.mean(weighted_marginals, axis=0)
        
        return projected_rpi
    
    def project_rankings(
        self,
        objective_weights: Dict[str, float]
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Compute projected rankings under new weights.
        
        Returns
        -------
        ranked_indices : ndarray(N,)
            Indices sorted by RPI (descending)
        projected_rpi : ndarray(N,)
            Projected RPI values
        """
        projected_rpi = self.project_rpi(objective_weights)
        ranked_indices = np.argsort(-projected_rpi)  # descending
        
        return ranked_indices, projected_rpi
    
    def project_volatility(self, objective_weights: Dict[str, float]) -> np.ndarray:
        """
        Compute volatility of projected RPI across scenarios.
        """
        weighted_marginals = np.zeros((self.S, self.N))
        
        total_weight = sum(objective_weights.values())
        if total_weight == 0:
            total_weight = 1.0
        
        for obj_name, weight in objective_weights.items():
            if obj_name in self._normalized_marginals:
                norm_weight = weight / total_weight
                weighted_marginals += norm_weight * self._normalized_marginals[obj_name]
        
        volatility = np.std(weighted_marginals, axis=0)
        return volatility
    
    def project_classification(
        self,
        objective_weights: Dict[str, float]
    ) -> List[str]:
        """
        Classify vehicles under new weights using percentile-based approach.
        
        Categories:
        - High-Priority Robust (RPI ≥ 75th, Vol ≤ 50th)
        - High-Priority Sensitive (RPI ≥ 75th, Vol > 50th)
        - Medium-Priority (25th < RPI < 75th)
        - Low-Priority Robust (RPI ≤ 25th, Vol ≤ 50th)
        - Low-Priority Sensitive (RPI ≤ 25th, Vol > 50th)
        - Feasibility-Critical (inf values)
        """
        rpi = self.project_rpi(objective_weights)
        vol = self.project_volatility(objective_weights)
        
        # Percentile-based thresholds (relative, not absolute)
        finite_rpi = rpi[np.isfinite(rpi)]
        finite_vol = vol[np.isfinite(vol)]
        
        if len(finite_rpi) > 0:
            rpi_q75 = np.percentile(finite_rpi, 75)
            rpi_q25 = np.percentile(finite_rpi, 25)
        else:
            rpi_q75 = 0
            rpi_q25 = 0
        
        if len(finite_vol) > 0:
            vol_q50 = np.percentile(finite_vol, 50)
        else:
            vol_q50 = 0
        
        labels = []
        for i in range(self.N):
            if np.isinf(rpi[i]):
                labels.append("Feasibility-Critical")
            elif rpi[i] >= rpi_q75 and vol[i] <= vol_q50:
                labels.append("High-Priority Robust")
            elif rpi[i] >= rpi_q75 and vol[i] > vol_q50:
                labels.append("High-Priority Sensitive")
            elif rpi[i] <= rpi_q25 and vol[i] <= vol_q50:
                labels.append("Low-Priority Robust")
            elif rpi[i] <= rpi_q25 and vol[i] > vol_q50:
                labels.append("Low-Priority Sensitive")
            else:
                labels.append("Medium-Priority")
        
        return labels
    
    def project_scenario_slice(
        self,
        scenario_idx: int,
        objective_weights: Dict[str, float]
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Get weighted marginal values for a specific scenario.
        
        Returns
        -------
        values : ndarray(N,)
            Weighted marginal values for that scenario
        ranked_indices : ndarray(N,)
            Ranking within that scenario
        """
        total_weight = sum(objective_weights.values())
        if total_weight == 0:
            total_weight = 1.0
        
        weighted = np.zeros(self.N)
        for obj_name, weight in objective_weights.items():
            if obj_name in self._normalized_marginals:
                norm_weight = weight / total_weight
                weighted += norm_weight * self._normalized_marginals[obj_name][scenario_idx]
        
        ranked_indices = np.argsort(-weighted)
        return weighted, ranked_indices
    
    def get_summary_table(
        self,
        objective_weights: Dict[str, float]
    ) -> pd.DataFrame:
        """
        Generate a summary table with projected metrics.
        """
        rpi = self.project_rpi(objective_weights)
        vol = self.project_volatility(objective_weights)
        labels = self.project_classification(objective_weights)
        rankings, _ = self.project_rankings(objective_weights)
        
        # Get rank position for each vehicle
        rank_pos = np.zeros(self.N, dtype=int)
        for rank, idx in enumerate(rankings):
            rank_pos[idx] = rank + 1
        
        # Scale RPI and Volatility to 0-100 for readability
        rpi_scaled = np.maximum(0, np.minimum(100, rpi * 100))
        vol_scaled = np.maximum(0, np.minimum(100, vol * 100))
        
        df = pd.DataFrame({
            "vehicle_id": self.vehicle_ids,
            "rank": rank_pos,
            "RPI": np.round(rpi_scaled, 1),
            "Volatility": np.round(vol_scaled, 1),
            "Classification": labels
        })
        
        return df.sort_values("rank").reset_index(drop=True)
    
    def get_contribution_breakdown(
        self,
        vehicle_idx: int,
        objective_weights: Dict[str, float]
    ) -> pd.DataFrame:
        """
        Show how each objective contributes to this vehicle's RPI.
        
        Useful for explainability.
        """
        data = []
        
        for obj_name in self.objective_names:
            if obj_name in self._normalized_marginals:
                marginal = self._normalized_marginals[obj_name][:, vehicle_idx]
                mean_contrib = np.mean(marginal)
                weight = objective_weights.get(obj_name, 0.0)
                
                total_weight = sum(objective_weights.values())
                if total_weight == 0:
                    total_weight = 1.0
                
                norm_weight = weight / total_weight
                weighted_contrib = mean_contrib * norm_weight
                
                data.append({
                    "Objective": obj_name,
                    "Mean_Contribution": mean_contrib,
                    "Weight": norm_weight,
                    "Weighted_Contribution": weighted_contrib
                })
        
        return pd.DataFrame(data).sort_values("Weighted_Contribution", ascending=False)
