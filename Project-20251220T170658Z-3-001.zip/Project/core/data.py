import pandas as pd
import numpy as np
import json

# Load variable metadata to get required columns
try:
    with open('variable_metadata.json') as f:
        VARIABLE_METADATA = json.load(f)
    REQUIRED_COLUMNS = ["vehicle_id"] + list(VARIABLE_METADATA.keys())
except FileNotFoundError:
    # Fallback to 18-variable schema if JSON not found
    REQUIRED_COLUMNS = [
        "vehicle_id",
        "fuel_cost_per_km",
        "maintenance_cost_per_year",
        "capex_ev",
        "downtime_cost_per_day",
        "co2_emission_gpkm",
        "pollutants_index",
        "compliance_liability",
        "utilization_percent",
        "service_criticality",
        "downtime_hours_annual",
        "vehicle_age",
        "remaining_useful_life",
        "reliability_score",
        "charging_availability",
        "grid_dependency",
        "fuel_price_volatility",
        "policy_stability_score"
    ]

def validate_schema(df: pd.DataFrame):
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

def normalize(df: pd.DataFrame):
    """Normalize data to [0,1] scale using metadata ranges where available."""
    norm_df = df.copy()

    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        if col == 'vehicle_id':
            continue
        
        # Try to use metadata range first
        if col in VARIABLE_METADATA:
            min_v, max_v = VARIABLE_METADATA[col].get('valid_range', [None, None])
            # If max_v is null (unlimited), use 1.5 * max of data
            if max_v is None:
                max_v = df[col].max() * 1.5
            if min_v is None:
                min_v = df[col].min() * 0.5
        else:
            # Fallback to data-driven normalization
            min_v = df[col].min()
            max_v = df[col].max()
        
        if max_v > min_v:
            norm_df[col] = (df[col] - min_v) / (max_v - min_v)
            norm_df[col] = norm_df[col].clip(0, 1)
        else:
            norm_df[col] = 0.0

    return norm_df

def load_and_prepare(csv_file):
    df = pd.read_csv(csv_file)
    validate_schema(df)
    norm_df = normalize(df)
    return df, norm_df
