"""
Custom Objective Builder
========================

Allows users to dynamically create objective functions by selecting variables
and assigning weights, instead of using pre-defined objectives.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional


class CustomObjectiveBuilder:
    """
    Build custom objectives from selected variables with user-defined weights.
    
    Example:
    --------
    builder = CustomObjectiveBuilder(norm_df, variable_registry)
    
    # User defines: "Cost Objective" = 0.4*fuel_cost + 0.3*maintenance + 0.3*capex
    cost_obj = builder.add_objective(
        name="Cost",
        variables=["fuel_cost_per_km", "maintenance_cost_per_year", "capex_ev"],
        weights=[0.4, 0.3, 0.3]
    )
    
    # User defines: "Environmental" = 0.5*emissions + 0.5*pollutants
    env_obj = builder.add_objective(
        name="Environmental",
        variables=["co2_emission_gpkm", "pollutants_index"],
        weights=[0.5, 0.5]
    )
    
    objectives = builder.build()
    # Returns: {"Cost": ndarray(N,), "Environmental": ndarray(N,)}
    """
    
    def __init__(self, norm_df: pd.DataFrame, variable_registry: Dict):
        """
        Initialize builder.
        
        Args:
            norm_df: Normalized vehicle data [0,1]
            variable_registry: Dict of variable metadata
        """
        self.norm_df = norm_df
        self.variable_registry = variable_registry
        self.objectives_config = {}
        self.n_vehicles = len(norm_df)
    
    def add_objective(
        self,
        name: str,
        variables: List[str],
        weights: List[float],
        normalize: bool = True
    ) -> None:
        """
        Define a custom objective function.
        
        Args:
            name: Objective name (e.g., "Cost", "Environmental")
            variables: List of variable names to include
            weights: Weights for each variable (will be normalized to sum=1)
            normalize: If True, normalize weights to sum to 1
        
        Raises:
            ValueError: If variable not in data or weights/variables length mismatch
        """
        if len(variables) != len(weights):
            raise ValueError(f"Variable count ({len(variables)}) != weight count ({len(weights)})")
        
        # Validate variables exist
        missing = [v for v in variables if v not in self.norm_df.columns]
        if missing:
            raise ValueError(f"Variables not in data: {missing}")
        
        # Normalize weights
        weights_array = np.array(weights, dtype=float)
        if normalize:
            weights_array = weights_array / weights_array.sum()
        
        self.objectives_config[name] = {
            "variables": variables,
            "weights": weights_array.tolist()
        }
    
    def remove_objective(self, name: str) -> None:
        """Remove a custom objective."""
        if name in self.objectives_config:
            del self.objectives_config[name]
    
    def get_available_variables(self) -> List[str]:
        """Get list of all available variables (excluding vehicle_id)."""
        return [col for col in self.norm_df.columns if col != 'vehicle_id']
    
    def get_objective_config(self, name: str) -> Optional[Dict]:
        """Get configuration for a specific objective."""
        return self.objectives_config.get(name)
    
    def list_objectives(self) -> List[str]:
        """Get list of defined objective names."""
        return list(self.objectives_config.keys())
    
    def build(self, norm_df: Optional[pd.DataFrame] = None) -> Dict[str, np.ndarray]:
        """
        Build objective values for all vehicles.
        
        Args:
            norm_df: Optional normalized data to use instead of self.norm_df
                     (used for Monte Carlo scenario rebuilding)
        
        Returns:
            Dict[objective_name -> ndarray(N,)] where N = number of vehicles
        """
        # Use provided data or default to self.norm_df
        data = norm_df if norm_df is not None else self.norm_df
        
        objectives = {}
        
        for obj_name, config in self.objectives_config.items():
            variables = config["variables"]
            weights = config["weights"]
            
            # Extract data for selected variables
            var_data = data[variables].values  # (N, n_vars)
            
            # Weighted sum: (N, n_vars) @ (n_vars,) -> (N,)
            obj_values = var_data @ np.array(weights)
            
            # Clip to [0,1]
            objectives[obj_name] = np.clip(obj_values, 0, 1)
        
        return objectives
    
    def get_summary(self) -> Dict:
        """Get human-readable summary of defined objectives."""
        summary = {}
        for obj_name, config in self.objectives_config.items():
            vars_weights = [
                f"{var}:{w:.2f}"
                for var, w in zip(config["variables"], config["weights"])
            ]
            summary[obj_name] = {
                "composition": " + ".join(vars_weights),
                "n_variables": len(config["variables"])
            }
        return summary
    
    def to_dict(self) -> Dict:
        """Export objective configuration as dict (for saving)."""
        return self.objectives_config.copy()
    
    @classmethod
    def from_dict(
        cls,
        norm_df: pd.DataFrame,
        variable_registry: Dict,
        config: Dict
    ) -> "CustomObjectiveBuilder":
        """
        Create builder from saved configuration.
        
        Args:
            norm_df: Normalized vehicle data
            variable_registry: Variable metadata
            config: Saved objective configuration dict
        """
        builder = cls(norm_df, variable_registry)
        for obj_name, obj_config in config.items():
            builder.add_objective(
                name=obj_name,
                variables=obj_config["variables"],
                weights=obj_config["weights"],
                normalize=False
            )
        return builder


class ObjectiveTemplate:
    """Pre-defined objective templates for quick setup."""
    
    @staticmethod
    def cost_focused() -> Dict[str, Dict]:
        """Objective template: Focus on costs."""
        return {
            "Acquisition Cost": {
                "variables": ["capex_ev"],
                "weights": [1.0]
            },
            "Operating Cost": {
                "variables": ["fuel_cost_per_km", "maintenance_cost_per_year", "downtime_cost_per_day"],
                "weights": [0.4, 0.35, 0.25]
            }
        }
    
    @staticmethod
    def environment_focused() -> Dict[str, Dict]:
        """Objective template: Focus on environmental impact."""
        return {
            "Emissions": {
                "variables": ["co2_emission_gpkm", "pollutants_index"],
                "weights": [0.5, 0.5]
            },
            "Compliance": {
                "variables": ["compliance_liability"],
                "weights": [1.0]
            }
        }
    
    @staticmethod
    def reliability_focused() -> Dict[str, Dict]:
        """Objective template: Focus on reliability and availability."""
        return {
            "Reliability": {
                "variables": ["reliability_score", "remaining_useful_life"],
                "weights": [0.6, 0.4]
            },
            "Availability": {
                "variables": ["downtime_hours_annual", "utilization_percent"],
                "weights": [0.4, 0.6]
            }
        }
    
    @staticmethod
    def all_balanced() -> Dict[str, Dict]:
        """Objective template: Balanced across all dimensions."""
        return {
            "Cost": {
                "variables": ["capex_ev", "fuel_cost_per_km", "maintenance_cost_per_year"],
                "weights": [0.33, 0.33, 0.34]
            },
            "Environment": {
                "variables": ["co2_emission_gpkm", "pollutants_index", "compliance_liability"],
                "weights": [0.33, 0.33, 0.34]
            },
            "Operations": {
                "variables": ["utilization_percent", "reliability_score", "downtime_hours_annual"],
                "weights": [0.33, 0.33, 0.34]
            },
            "Asset Quality": {
                "variables": ["remaining_useful_life", "vehicle_age", "grid_dependency"],
                "weights": [0.33, 0.33, 0.34]
            }
        }
