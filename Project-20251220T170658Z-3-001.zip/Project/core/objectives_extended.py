# Enhanced OBJECTIVES configuration with comprehensive variables
# Add this to replace the existing OBJECTIVES dictionary

OBJECTIVES_COMPREHENSIVE = {
    # ============================================
    # Economic Objectives
    # ============================================
    "Economic_TCO": {
        "variables": [
            "fuel_cost_per_km",
            "maintenance_cost_per_year", 
            "capex_ev",
            "downtime_cost_per_day"
        ],
        "display_name": "Total Cost of Ownership",
        "description": "Minimize total lifecycle and operational costs"
    },
    
    # ============================================
    # Environmental Objectives
    # ============================================
    "Environmental_Impact": {
        "variables": [
            "co2_emission_gpkm",
            "pollutants_index",
            "compliance_liability"
        ],
        "display_name": "Environmental Impact",
        "description": "Minimize emissions, pollution, and compliance risk"
    },
    
    # ============================================
    # Operational Objectives
    # ============================================
    "Operational_Efficiency": {
        "variables": [
            "utilization_percent",  # Note: negate or invert in transform
            "service_criticality",
            "downtime_hours_annual"
        ],
        "display_name": "Operational Excellence",
        "description": "Maximize utilization, maintain critical service, minimize downtime"
    },
    
    # ============================================
    # Asset Health Objectives
    # ============================================
    "Asset_Health": {
        "variables": [
            "vehicle_age",
            "remaining_useful_life",  # Note: higher is better
            "reliability_score"  # Note: higher is better
        ],
        "display_name": "Asset Health & Reliability",
        "description": "Replace aging vehicles, prefer those with high RUL and reliability"
    },
    
    # ============================================
    # Infrastructure Readiness
    # ============================================
    "Infrastructure_Readiness": {
        "variables": [
            "charging_availability",  # Note: higher is better
            "grid_dependency"  # Note: lower is better (independence)
        ],
        "display_name": "Infrastructure Readiness",
        "description": "Prefer vehicles in areas with charging infrastructure"
    },
    
    # ============================================
    # Risk Management
    # ============================================
    "Risk_Mitigation": {
        "variables": [
            "fuel_price_volatility",
            "policy_stability_score"  # Note: higher is better
        ],
        "display_name": "Risk & Uncertainty",
        "description": "Reduce exposure to fuel price volatility, favor policy-stable vehicles"
    },
    
    # ============================================
    # Policy Compliance (Can be hard constraint or soft objective)
    # ============================================
    "Policy_Alignment": {
        "variables": [
            "policy_mandate_level",
            "compliance_liability"
        ],
        "display_name": "Policy Alignment",
        "description": "Align with regulatory mandates and policy objectives"
    }
}

# Simplified mapping (4-5 main objectives for UI)
OBJECTIVES_SIMPLIFIED = {
    "Economic": ["fuel_cost_per_km", "maintenance_cost_per_year", "capex_ev", "downtime_cost_per_day"],
    "Environmental": ["co2_emission_gpkm", "pollutants_index", "compliance_liability"],
    "Operational": ["utilization_percent", "service_criticality", "downtime_hours_annual"],
    "Asset_Health": ["vehicle_age", "remaining_useful_life", "reliability_score"],
    "Infrastructure": ["charging_availability", "grid_dependency"],
    "Risk": ["fuel_price_volatility", "policy_stability_score"],
}
