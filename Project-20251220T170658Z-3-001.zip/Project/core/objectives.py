# core/objectives.py
from dataclasses import dataclass

@dataclass
class Objective:
    name: str
    variables: list
    transforms: dict
    target: float


def build_objectives(objective_config: dict):
    """
    Build objective objects dynamically from UI config.
    """
    objectives = []
    for name, cfg in objective_config.items():
        objectives.append(
            Objective(
                name=name,
                variables=cfg["variables"],
                transforms=cfg["transforms"],
                target=cfg["target"]
            )
        )
    return objectives
