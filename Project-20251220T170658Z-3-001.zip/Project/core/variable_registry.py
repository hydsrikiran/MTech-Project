"""
Variable Registry: Metadata for all variables in the system.

This registry describes every variable, its category, role, and behavior.
It serves as the source of truth for what variables exist and how they should be handled.

Variables ≠ Objectives. This registry documents variables only.
Objectives are composed from variables by ObjectiveCompositionEngine.
"""

VARIABLE_REGISTRY = {
    # ============================================================================
    # ECONOMIC VARIABLES
    # ============================================================================
    "fuel_cost_per_km": {
        "category": "Economic",
        "unit": "INR/km",
        "direction": "minimize",
        "type": "continuous",
        "role": "indicator",
        "description": "Average fuel cost per kilometer traveled"
    },
    "maintenance_cost_per_year": {
        "category": "Economic",
        "unit": "INR/year",
        "direction": "minimize",
        "type": "continuous",
        "role": "indicator",
        "description": "Annual maintenance and repair costs"
    },
    "capex_ev": {
        "category": "Economic",
        "unit": "INR",
        "direction": "minimize",
        "type": "continuous",
        "role": "indicator",
        "description": "Capital expenditure for EV (acquisition + charging infrastructure)"
    },
    "downtime_cost_per_day": {
        "category": "Economic",
        "unit": "INR/day",
        "direction": "minimize",
        "type": "continuous",
        "role": "indicator",
        "description": "Cost incurred per day of vehicle downtime"
    },

    # ============================================================================
    # ENVIRONMENTAL VARIABLES
    # ============================================================================
    "co2_emission_gpkm": {
        "category": "Environmental",
        "unit": "gCO2/km",
        "direction": "minimize",
        "type": "continuous",
        "role": "indicator",
        "description": "CO2 emissions per kilometer (tank-to-wheel for ICE, well-to-wheel for EV)"
    },
    "pollutants_index": {
        "category": "Environmental",
        "unit": "unitless [0-100]",
        "direction": "minimize",
        "type": "continuous",
        "role": "indicator",
        "description": "Composite index of NOx, PM2.5, and other pollutants (0=clean, 100=dirty)"
    },
    "compliance_liability": {
        "category": "Environmental",
        "unit": "INR",
        "direction": "minimize",
        "type": "continuous",
        "role": "policy_penalty",
        "description": "Financial penalty if vehicle fails emission norms (policy-driven)"
    },

    # ============================================================================
    # OPERATIONAL VARIABLES
    # ============================================================================
    "utilization_percent": {
        "category": "Operational",
        "unit": "% [0-100]",
        "direction": "maximize",
        "type": "continuous",
        "role": "indicator",
        "description": "Average fleet utilization (km/year / capacity)"
    },
    "service_criticality": {
        "category": "Operational",
        "unit": "unitless [1-10]",
        "direction": "maximize",
        "type": "continuous",
        "role": "indicator",
        "description": "How critical the vehicle is to service continuity (higher = more critical)"
    },
    "downtime_hours_annual": {
        "category": "Operational",
        "unit": "hours/year",
        "direction": "minimize",
        "type": "continuous",
        "role": "indicator",
        "description": "Expected annual downtime (maintenance + charging wait time)"
    },

    # ============================================================================
    # ASSET HEALTH VARIABLES
    # ============================================================================
    "vehicle_age": {
        "category": "Asset",
        "unit": "years",
        "direction": "minimize",
        "type": "continuous",
        "role": "indicator",
        "description": "Age of vehicle at decision point"
    },
    "remaining_useful_life": {
        "category": "Asset",
        "unit": "years",
        "direction": "maximize",
        "type": "continuous",
        "role": "indicator",
        "description": "Expected remaining useful life of vehicle"
    },
    "reliability_score": {
        "category": "Asset",
        "unit": "unitless [0-100]",
        "direction": "maximize",
        "type": "continuous",
        "role": "indicator",
        "description": "Historical reliability (based on failure rates, MTBF)"
    },

    # ============================================================================
    # INFRASTRUCTURE VARIABLES (NOT OBJECTIVES)
    # ============================================================================
    "charging_availability": {
        "category": "Infrastructure",
        "unit": "unitless [0-100]",
        "direction": "maximize",
        "type": "continuous",
        "role": "constraint",
        "description": "Availability of charging stations in service region (constraint, not objective)"
    },
    "grid_dependency": {
        "category": "Infrastructure",
        "unit": "unitless [0-100]",
        "direction": "minimize",
        "type": "continuous",
        "role": "constraint",
        "description": "Dependency on grid (constraint, not objective)"
    },

    # ============================================================================
    # RISK VARIABLES (NOT OBJECTIVES)
    # ============================================================================
    "fuel_price_volatility": {
        "category": "Risk",
        "unit": "coefficient of variation",
        "direction": "minimize",
        "type": "continuous",
        "role": "uncertainty_driver",
        "description": "Historical fuel price volatility (uncertainty driver, not objective)"
    },
    "policy_stability_score": {
        "category": "Risk",
        "unit": "unitless [0-100]",
        "direction": "maximize",
        "type": "continuous",
        "role": "uncertainty_driver",
        "description": "Confidence in policy continuity (uncertainty driver, not objective)"
    },
}

# ============================================================================
# OBJECTIVE CATEGORIES (Derived from Variable Registry)
# ============================================================================
# These are the ONLY categories that become objectives.
# Infrastructure and Risk are constraints/drivers, not objectives.

OBJECTIVE_CATEGORIES = [
    "Economic",
    "Environmental",
    "Operational",
    "Asset"
]

# ============================================================================
# POLICY STATE (Template)
# ============================================================================
# This is a separate concern from variables/objectives.
# Policies MODIFY objectives but are not themselves objectives.

DEFAULT_POLICY_STATE = {
    "EV_mandate": False,
    "emission_cap_gpkm": 100.0,  # gCO2/km
    "subsidy_active": False,
    "subsidy_fraction": 0.0,  # Fraction of CAPEX subsidized
    "carbon_tax": False,
    "carbon_tax_per_gco2": 0.0,  # INR per gCO2
    "mandatory_replacement": False,
    "region": "India",
    "year": 2025,
}

# ============================================================================
# POLICY CONDITIONING RULES
# ============================================================================
# How policies modify objective compositions

POLICY_RULES = {
    "subsidy_active": {
        "description": "Subsidy reduces effective EV capital cost",
        "affects": "Economic",
        "effect": {
            "capex_ev": "multiply_by_(1 - subsidy_fraction)"
        }
    },
    "carbon_tax": {
        "description": "Carbon tax increases effective emission cost",
        "affects": "Environmental",
        "effect": {
            "co2_emission_gpkm": "add_(carbon_tax_per_gco2 * co2_value)"
        }
    },
    "EV_mandate": {
        "description": "EV mandate enforces minimum EV share",
        "affects": "Feasibility",
        "constraint": "min_EV_share >= 0.3"
    },
    "emission_cap": {
        "description": "Emission cap penalizes vehicles exceeding threshold",
        "affects": "Environmental",
        "penalty": "apply_if_(co2 > cap)"
    }
}


def get_variables_by_category(category: str):
    """Get all variables in a specific category."""
    return {
        var: meta
        for var, meta in VARIABLE_REGISTRY.items()
        if meta["category"] == category
    }


def is_objective_variable(variable_name: str) -> bool:
    """
    Check if a variable should contribute to an objective.
    
    Returns False for constraints and uncertainty drivers.
    """
    var_meta = VARIABLE_REGISTRY.get(variable_name)
    if not var_meta:
        return False
    return var_meta["role"] == "indicator" or var_meta["role"] == "policy_penalty"


def is_constraint_variable(variable_name: str) -> bool:
    """Check if a variable is a constraint, not an objective."""
    var_meta = VARIABLE_REGISTRY.get(variable_name)
    if not var_meta:
        return False
    return var_meta["role"] == "constraint"


def is_uncertainty_driver(variable_name: str) -> bool:
    """Check if a variable is an uncertainty driver, not an objective."""
    var_meta = VARIABLE_REGISTRY.get(variable_name)
    if not var_meta:
        return False
    return var_meta["role"] == "uncertainty_driver"
