import numpy as np
from copy import deepcopy
from typing import Dict
from core.marginal import MarginalContributionEngine
from core.data import normalize
from core.objective_composer import ObjectiveCompositionEngine, PolicyState
import pandas as pd


class MonteCarloEngine:
    """
    Monte Carlo Simulation Engine.
    
    Runs multiple scenarios with perturbed inputs to capture:
    - Robustness of decisions
    - Volatility of vehicle marginal contributions
    - Sensitivity to parameter uncertainty
    
    Accepts: ObjectiveCompositionEngine (OCE) instead of objectives_config
    
    OUTPUT: Dict[objective_name -> ndarray(S, N)]
    where S = scenarios, N = vehicles
    """
    
    def __init__(
        self,
        raw_df,
        oce,
        feasibility_config,
        n_scenarios=50,
        seed=42
    ):
        """
        Initialize Monte Carlo engine.
        
        Args:
            raw_df: Raw vehicle data
            oce: ObjectiveCompositionEngine instance (provides policy + aggregation rules)
            feasibility_config: Dict with constraints
            n_scenarios: Number of scenarios to run
            seed: Random seed for reproducibility
        """
        self.raw_df = raw_df
        self.oce = oce
        self.policy_state = oce.policy_state
        self.base_feas = feasibility_config
        self.n_scenarios = n_scenarios
        self.rng = np.random.default_rng(seed)

    def run(self) -> Dict[str, np.ndarray]:
        """
        Run Monte Carlo simulation.
        
        Returns
        -------
        marginals : Dict[objective_name -> ndarray(S, N)]
            S scenarios × N vehicles for each objective
        """
        
        # Get objective names from OCE
        base_objectives = self.oce.build_objectives()
        objective_names = list(base_objectives.keys())
        
        results = {
            obj_name: [] for obj_name in objective_names
        }

        for scenario_idx in range(self.n_scenarios):
            raw, norm = self._perturb_inputs()
            
            # Create OCE for this scenario with same policy state
            scenario_oce = ObjectiveCompositionEngine(raw, norm, self.policy_state)
            objectives = scenario_oce.build_objectives()
            objectives = scenario_oce.apply_policy_modifiers()

            engine = MarginalContributionEngine(
                raw, norm, objectives, self.base_feas
            )
            
            # Get per-objective marginals for this scenario
            scenario_marginals = engine.compute_marginal_contributions()
            
            # Accumulate
            for obj_name, marginals in scenario_marginals.items():
                results[obj_name].append(marginals)

        # Convert to numpy arrays: shape (S, N)
        results = {
            obj_name: np.array(marginals)
            for obj_name, marginals in results.items()
        }
        
        return results

    def _perturb_inputs(self):
        """
        Perturb input data to simulate uncertainty.
        
        Uncertainty parameters:
        - Fuel costs: ±20%
        - Maintenance: ±15%
        - Emissions: ±10%
        - Annual km: ±25%
        - Age: ±10%
        """
        raw = self.raw_df.copy()
        numeric_cols = raw.select_dtypes(include=[np.number]).columns

        uncertainty = {
            "fuel_cost_per_km": 0.20,
            "maintenance_cost_per_year": 0.15,
            "co2_emission_gpkm": 0.10,
            "annual_km": 0.25,
            "vehicle_age": 0.10,
            "service_criticality": 0.10
        }

        for col, sigma in uncertainty.items():
            if col in numeric_cols:
                raw[col] *= (1 + self.rng.normal(0, sigma, len(raw)))

        raw[numeric_cols] = raw[numeric_cols].clip(lower=0)
        return raw, normalize(raw)

    def _perturb_feasibility(self):
        """
        Perturb feasibility constraints.
        
        - Budget: ±15%
        - Charging capacity: ±20%
        - Service level: ±10%
        """
        f = deepcopy(self.base_feas)
        f["budget"] *= (1 + self.rng.normal(0, 0.15))
        f["max_charging_load"] = max(
            1, int(f["max_charging_load"] * (1 + self.rng.normal(0, 0.2)))
        )
        f["min_service_level"] *= (1 + self.rng.normal(0, 0.1))
        return f

