import numpy as np
from typing import Dict, Tuple
from core.optimize import OptimizationEngine


class MarginalContributionEngine:
    """
    Computes per-objective marginal contribution of each vehicle
    via re-optimization with vehicle removed.
    
    OUTPUT: Dict[objective_name -> ndarray(N,)]
    
    This is critical for the projection layer!
    """

    def __init__(self, raw_df, norm_df, objectives, feasibility):
        self.raw = raw_df.reset_index(drop=True)
        self.norm = norm_df.reset_index(drop=True)
        self.objectives = objectives
        self.feas = feasibility
        self.N = len(raw_df)
        # objectives is now Dict[str, ndarray], so keys are objective names
        self.objective_names = list(objectives.keys())

    # -------------------------------------------------
    def baseline_solution(self) -> Tuple[np.ndarray, Dict[str, float]]:
        """
        Solve the baseline problem.
        
        Returns
        -------
        x_star : ndarray(N,)
        objective_values : Dict[str, float]
            Per-objective value at baseline
        """
        opt = OptimizationEngine(
            self.raw,
            self.norm,
            self.objectives,
            self.feas
        )
        x_star, base_objs = opt.solve()
        return x_star, base_objs

    # -------------------------------------------------
    def compute_marginal_contributions(self) -> Dict[str, np.ndarray]:
        """
        Compute per-objective marginal contribution.
        
        Returns
        -------
        marginals : Dict[objective_name -> ndarray(N,)]
            For each objective, array of marginal contributions
        """
        _, base_objs = self.baseline_solution()
        
        # Initialize output
        marginals = {obj_name: [] for obj_name in self.objective_names}
        
        for i in range(self.N):
            try:
                deltas = self._solve_without_vehicle(i, base_objs)
                for obj_name, delta in deltas.items():
                    marginals[obj_name].append(delta)
            except Exception:
                # If vehicle removal causes infeasibility, mark as critical
                for obj_name in marginals:
                    marginals[obj_name].append(np.inf)
        
        # Convert to numpy arrays
        marginals = {
            obj_name: np.array(values)
            for obj_name, values in marginals.items()
        }
        
        return marginals

    # -------------------------------------------------
    def _solve_without_vehicle(self, idx, base_objs) -> Dict[str, float]:
        """
        Remove vehicle idx and re-solve.
        Return per-objective marginal contributions.
        
        Parameters
        ----------
        idx : int
            Vehicle index to remove
        base_objs : Dict[str, float]
            Baseline objective values
        
        Returns
        -------
        marginals : Dict[str, float]
            Marginal contribution per objective
        """
        raw_mod = self.raw.drop(index=idx).reset_index(drop=True)
        norm_mod = self.norm.drop(index=idx).reset_index(drop=True)

        opt = OptimizationEngine(
            raw_mod,
            norm_mod,
            self.objectives,
            self.feas
        )

        _, new_objs = opt.solve()
        
        # Compute deltas per objective
        marginals = {}
        for obj_name in self.objective_names:
            marginals[obj_name] = new_objs.get(obj_name, np.inf) - base_objs.get(obj_name, 0)
        
        return marginals
