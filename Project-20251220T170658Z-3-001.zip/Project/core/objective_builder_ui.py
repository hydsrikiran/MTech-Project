#!/usr/bin/env python3
"""
Custom Objective Builder UI - Streamlit Component
Allows users to dynamically create objectives from 18 variables
"""

import streamlit as st
import pandas as pd
from core.custom_objectives import CustomObjectiveBuilder, ObjectiveTemplate
from core.variable_registry import VARIABLE_REGISTRY


def render_custom_objective_builder(norm_df: pd.DataFrame) -> dict:
    """
    Render UI for building custom objectives.
    
    Returns:
        Dict[objective_name -> ndarray(N,)]
    """
    
    st.header("🔧 Custom Objective Builder")
    
    st.write("""
    Build your own objectives by selecting variables and assigning weights.
    Instead of fixed objectives, compose what matters most to you.
    """)
    
    # Template selector
    st.subheader("📋 Quick Templates")
    col_template_selector = st.columns([1, 1, 1, 1, 1])
    
    template_choice = None
    with col_template_selector[0]:
        if st.button("💰 Cost-Focused"):
            template_choice = "cost"
            st.session_state.objective_template = "cost"
    with col_template_selector[1]:
        if st.button("🌍 Environment-Focused"):
            template_choice = "environment"
            st.session_state.objective_template = "environment"
    with col_template_selector[2]:
        if st.button("🔧 Reliability-Focused"):
            template_choice = "reliability"
            st.session_state.objective_template = "reliability"
    with col_template_selector[3]:
        if st.button("⚖️ Balanced"):
            template_choice = "balanced"
            st.session_state.objective_template = "balanced"
    with col_template_selector[4]:
        if st.button("🆕 Custom"):
            template_choice = "custom"
            st.session_state.objective_template = "custom"
    
    # Restore template choice from session state
    if "objective_template" not in st.session_state:
        st.session_state.objective_template = "balanced"
    
    template_choice = st.session_state.objective_template
    
    # Load template if selected
    template_config = {}
    if template_choice == "cost":
        template_config = ObjectiveTemplate.cost_focused()
    elif template_choice == "environment":
        template_config = ObjectiveTemplate.environment_focused()
    elif template_choice == "reliability":
        template_config = ObjectiveTemplate.reliability_focused()
    elif template_choice == "balanced":
        template_config = ObjectiveTemplate.all_balanced()
    
    # Initialize builder
    builder = CustomObjectiveBuilder(norm_df, VARIABLE_REGISTRY)
    
    # Apply template if any
    if template_config:
        for obj_name, config in template_config.items():
            builder.add_objective(
                name=obj_name,
                variables=config["variables"],
                weights=config["weights"],
                normalize=False
            )
    
    # Manual objective editor
    st.subheader("✏️ Manual Objective Editor")
    st.write("Add or modify objectives by selecting variables and weights:")
    
    # Get all available variables
    all_variables = builder.get_available_variables()
    
    # Number of custom objectives
    num_objectives = st.number_input(
        "Number of objectives",
        min_value=1,
        max_value=5,
        value=len(builder.list_objectives()) or 3,
        key="num_objectives"
    )
    
    # Create custom objectives
    custom_objectives = {}
    for i in range(num_objectives):
        with st.expander(f"Objective {i+1}", expanded=(i < 1)):
            col1, col2 = st.columns([1, 2])
            
            with col1:
                obj_name = st.text_input(
                    "Name",
                    value=builder.list_objectives()[i] if i < len(builder.list_objectives()) else f"Objective {i+1}",
                    key=f"obj_name_{i}"
                )
            
            with col2:
                selected_vars = st.multiselect(
                    "Variables to include",
                    options=all_variables,
                    default=(
                        builder.get_objective_config(builder.list_objectives()[i])["variables"]
                        if i < len(builder.list_objectives())
                        else []
                    ),
                    key=f"obj_vars_{i}"
                )
            
            # Weight assignment for selected variables
            if selected_vars:
                st.write("**Assign weights (will auto-normalize):**")
                weights = []
                cols = st.columns(len(selected_vars))
                
                for col, var in zip(cols, selected_vars):
                    with col:
                        w = st.number_input(
                            var,
                            min_value=0.0,
                            max_value=1.0,
                            value=1.0 / len(selected_vars),
                            step=0.05,
                            label_visibility="collapsed",
                            key=f"weight_{i}_{var}"
                        )
                        weights.append(w)
                
                # Add objective to builder
                if obj_name and selected_vars and weights:
                    builder.add_objective(
                        name=obj_name,
                        variables=selected_vars,
                        weights=weights,
                        normalize=True
                    )
                    custom_objectives[obj_name] = {
                        "variables": selected_vars,
                        "weights": weights
                    }
    
    # Display summary
    st.subheader("📊 Objective Summary")
    summary = builder.get_summary()
    if summary:
        for obj_name, details in summary.items():
            with st.container():
                col1, col2 = st.columns([2, 1])
                with col1:
                    st.write(f"**{obj_name}**")
                    st.caption(details["composition"])
                with col2:
                    st.metric("Variables", details["n_variables"])
    else:
        st.info("No objectives defined yet. Add variables above or select a template.")
    
    # Build objectives
    if custom_objectives or template_config:
        objectives = builder.build()
        return objectives
    else:
        return {}


if __name__ == "__main__":
    # Test the component
    import numpy as np
    
    # Create test data
    test_df = pd.DataFrame({
        'fuel_cost_per_km': np.random.uniform(0, 1, 10),
        'maintenance_cost_per_year': np.random.uniform(0, 1, 10),
        'capex_ev': np.random.uniform(0, 1, 10),
        'co2_emission_gpkm': np.random.uniform(0, 1, 10),
        'pollutants_index': np.random.uniform(0, 1, 10),
    })
    
    st.set_page_config(page_title="Objective Builder Test", layout="wide")
    objectives = render_custom_objective_builder(test_df)
    
    if objectives:
        st.success("✅ Objectives created successfully!")
        for obj_name, values in objectives.items():
            st.write(f"{obj_name}: mean={values.mean():.3f}, std={values.std():.3f}")
