# Custom Objective Builder Guide

## Overview

The **Custom Objective Builder** feature allows you to dynamically create objective functions from your 18+ variables instead of using pre-defined objectives. This gives you complete flexibility to focus on what matters most for your fleet electrification decisions.

## What You Can Do

### ✅ Build Custom Objectives
Select any combination of variables and assign weights to create objectives tailored to your priorities:

```
Cost Objective = 0.4 × fuel_cost + 0.3 × maintenance + 0.3 × capex
Environmental = 0.5 × emissions + 0.5 × pollutants + flexibility metrics
Reliability = 0.6 × uptime + 0.4 × durability
```

### ✅ Use Pre-Built Templates
Start with these templates and customize:
- **💰 Cost-Focused**: Acquisition + Operating costs
- **🌍 Environment-Focused**: Emissions + Compliance + Sustainability
- **🔧 Reliability-Focused**: Uptime + Durability + Asset quality
- **⚖️ Balanced**: Equal weight across all dimensions

### ✅ Dynamic Weight Adjustment
After optimization, adjust objective weights instantly to see how rankings change (no re-solve needed).

## How to Use

### Step 1: Upload Your Data
In the **Upload** section, select your fleet CSV with all 18+ variables:

```
vehicle_id, fuel_cost_per_km, maintenance_cost_per_year, capex_ev, ... (18 total)
V001, 6.2, 85000, 1200000, ...
V002, 5.8, 78000, 1150000, ...
```

### Step 2: Build Objectives (Tab 1)

**Option A: Use a Quick Template**
1. Click one of: 💰 Cost | 🌍 Environment | 🔧 Reliability | ⚖️ Balanced | 🆕 Custom
2. Each template loads pre-configured objectives
3. Modify in the "Customize Objectives" section if needed
4. Click **Save Objectives**

**Option B: Manual Build**
1. Select "Custom" or "🆕 Custom" option
2. For each objective:
   - **Name**: Give it a meaningful name (e.g., "Total Cost")
   - **Variables**: Select which variables to include
   - **Weights**: Assign importance to each variable
   - Auto-normalized to sum = 1.0

**Example: Build "Total Cost" Objective**
```
Objective Name: Total Cost
Variables Selected: capex_ev, fuel_cost_per_km, maintenance_cost_per_year
Weights: 0.4, 0.3, 0.3  →  Auto-normalized to [0.40, 0.30, 0.30]
```

### Step 3: Run Optimization (Tab 2)

1. **Your Objectives**: Verify the objectives you created
2. **Feasibility Constraints**: Set budget, service level, charging capacity
3. **Run Computation**: Click "▶️ RUN OPTIMIZATION & MONTE CARLO"
   - Solves MILP to find optimal vehicle set
   - Runs 50 Monte Carlo scenarios
   - Computes marginal contributions

### Step 4: Explore Results (Tab 3)

1. **Optimal Selection**: See which vehicles were selected and why
2. **Objective Values**: Compare performance across objectives
3. **Dynamic Ranking**: 
   - Adjust objective weights with sliders
   - Rankings update **instantly** (no re-computation needed)
   - Understand trade-offs between objectives

## Available Variables (18 Total)

### Economic (4)
- `fuel_cost_per_km`: INR/km, minimize
- `maintenance_cost_per_year`: INR/year, minimize
- `capex_ev`: INR, minimize (acquisition + infrastructure)
- `downtime_cost_per_day`: INR/day, minimize

### Environmental (3)
- `co2_emission_gpkm`: gCO2/km, minimize
- `pollutants_index`: 0-100 scale, minimize
- `compliance_liability`: INR, minimize

### Operational (3)
- `utilization_percent`: 0-100%, maximize
- `downtime_hours_annual`: hours/year, minimize
- `service_criticality`: 1-5 scale, context-dependent

### Asset Quality (3)
- `reliability_score`: 0-100%, maximize
- `remaining_useful_life`: years, maximize
- `vehicle_age`: years, minimize

### Infrastructure (2)
- `charging_availability`: 0/1 binary, maximize
- `grid_dependency`: 0-1, minimize

### Uncertainty Drivers (3)
- `fuel_price_volatility`: 0-1, minimize
- `policy_stability_score`: 0-100%, maximize
- Context-dependent indicators

## Example Workflows

### Workflow 1: Cost Minimization
```
Objective 1: Direct Costs
  Variables: capex_ev, fuel_cost_per_km, maintenance_cost_per_year
  Weights: 0.4, 0.3, 0.3

Objective 2: Operational Costs
  Variables: downtime_cost_per_day, downtime_hours_annual
  Weights: 0.5, 0.5

→ Run Optimization to minimize total cost
→ Explore how budget vs. reliability trade off
```

### Workflow 2: Environmental Compliance
```
Objective 1: Emissions
  Variables: co2_emission_gpkm, pollutants_index
  Weights: 0.6, 0.4

Objective 2: Regulatory Compliance
  Variables: compliance_liability
  Weights: 1.0

Objective 3: Sustainability
  Variables: vehicle_age, remaining_useful_life
  Weights: 0.3, 0.7

→ Run Optimization with emission caps
→ Adjust weights to see impact on selections
```

### Workflow 3: Reliability-First
```
Objective 1: Operational Reliability
  Variables: reliability_score, utilization_percent, downtime_hours_annual
  Weights: 0.4, 0.35, 0.25

Objective 2: Asset Longevity
  Variables: remaining_useful_life, vehicle_age
  Weights: 0.7, 0.3

→ Prioritize vehicles with longest uptime
→ Minimize unexpected downtime
```

## Key Features

### 🎯 Flexible Composition
- Any number of objectives (1-6)
- Any combination of variables
- Custom weights reflecting your priorities

### ⚡ Instant Exploration
- Change weights on Tab 3 → rankings update instantly
- No re-solver needed
- Explore 100s of scenarios in seconds

### 📊 Transparent Decisions
- See exactly which variables influence each objective
- Understand trade-offs between competing objectives
- Validate results against your priorities

### 🔄 Reproducible Results
- All configurations saved in session
- Export/import objective definitions
- Audit trail of what was optimized

## Tips & Best Practices

1. **Start with Templates**: Use pre-built templates as a baseline, then customize
2. **Balance Objectives**: Avoid dominant single variables; spread weights
3. **Use Meaningful Names**: "Total Cost" is clearer than "Obj1"
4. **Validate Weights**: Ensure they reflect relative importance
5. **Explore Trade-Offs**: Use Tab 3 sliders to understand compromises
6. **Document Choices**: Save your objective definitions for reproducibility

## Technical Details

### Objective Composition
Each objective is a weighted sum of normalized variables:

```
Objective_i = Σ(weight_j × normalized_variable_j) / Σ(weights)

where:
  - Variables are normalized to [0,1] scale
  - Weights are auto-normalized to sum = 1.0
  - Final values are clipped to [0,1]
```

### Constraint Handling
Feasibility constraints are applied during optimization:
- Budget limit
- Service level (availability)
- Charging capacity constraints

### Monte Carlo Robustness
For each of 50 scenarios:
1. Perturb vehicle data (±5% normally distributed)
2. Re-normalize
3. Re-compute objectives
4. Compute marginal contributions

This captures uncertainty in vehicle parameters.

## FAQ

**Q: How many objectives can I create?**
A: 1-6 objectives. Typically 2-4 works best for interpretability.

**Q: Can I mix variables that have opposite directions (minimize vs. maximize)?**
A: Yes! The engine automatically normalizes all variables to [0,1] scale, so any combination works.

**Q: What if I don't know what weights to use?**
A: Start with equal weights (1.0 for each variable), then adjust based on results.

**Q: How do I save my objective definitions?**
A: Currently displayed in Tab 1. Export feature coming soon.

**Q: What if an objective performs poorly?**
A: Use Tab 3 to reduce its weight and see impact. Or modify the objective definition and re-run.

## Support

For questions or issues:
1. Check the variable metadata: `variable_metadata.json`
2. Review the example workflows above
3. Use balanced template as reference

---

**Version**: 1.0 (Custom Objective Builder)  
**Last Updated**: December 2025  
**Framework**: HOSF (Hybrid Optimization-Simulation Framework)
