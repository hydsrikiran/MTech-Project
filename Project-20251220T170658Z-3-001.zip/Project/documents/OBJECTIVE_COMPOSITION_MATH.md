# Objective Composition Mathematics

**Using your real fleet variables — this is the core missing link**

## Executive Summary

Your dataset has 18 variables across 5 categories. Only 4 become objectives:

| Category | Role | Variables | Becomes Objective? |
|----------|------|-----------|-------------------|
| Economic | indicator | 4 variables | **YES** |
| Environmental | indicator + penalty | 3 variables | **YES** |
| Operational | indicator | 3 variables | **YES** |
| Asset | indicator | 3 variables | **YES** |
| **Infrastructure** | **constraint** | 2 variables | **NO** |
| **Risk** | **uncertainty_driver** | 2 variables | **NO** |

---

## 1. Economic Objective ($Z_{econ}$)

**Variables:**
- $f_i$ = fuel_cost_per_km
- $m_i$ = maintenance_cost_per_year
- $c_i$ = capex_ev
- $d_i$ = downtime_cost_per_day

**Normalization (per vehicle):**
$$
\hat{f}_i = \frac{f_i - \min(f)}{\max(f) - \min(f)}
$$

(Similarly for $\hat{m}_i$, $\hat{c}_i$, $\hat{d}_i$)

**Objective function:**
$$
Z_{econ}(i) = w_f \cdot \hat{f}_i + w_m \cdot \hat{m}_i + w_c \cdot \hat{c}_i + w_d \cdot \hat{d}_i
$$

**Default weights** (equal-weighted cost components):
- $w_f = 0.25$ (fuel dominates operating cost)
- $w_m = 0.25$ (maintenance is major expense)
- $w_c = 0.30$ (CAPEX is largest single cost)
- $w_d = 0.20$ (downtime cost is secondary)

**Policy modifier (Subsidy):**
$$
\hat{c}_i^{subsidy} = \hat{c}_i \times (1 - \text{subsidy\_fraction})
$$

Example: 30% subsidy → $\hat{c}_i^{0.3} = 0.7 \cdot \hat{c}_i$

---

## 2. Environmental Objective ($Z_{env}$)

**Variables:**
- $e_i$ = co2_emission_gpkm
- $p_i$ = pollutants_index (0-100)
- $\lambda_i$ = compliance_liability (policy-driven penalty)

**Normalization:**
$$
\hat{e}_i = \frac{e_i - \min(e)}{\max(e) - \min(e)}
\quad ; \quad
\hat{p}_i = \frac{p_i}{100}
$$

**Objective function:**
$$
Z_{env}(i) = w_e \cdot \hat{e}_i + w_p \cdot \hat{p}_i + \lambda \cdot \text{penalty}_i
$$

**Default weights:**
- $w_e = 0.60$ (CO2 is primary concern)
- $w_p = 0.40$ (pollutants matter for health)
- $\lambda = 1.0$ if policy active, else 0

**Policy modifier (Carbon Tax):**
$$
Z_{env}(i)^{tax} = Z_{env}(i) + \text{tax\_rate} \times e_i
$$

Example: 2 INR/gCO2 tax → adds cost proportional to emissions

---

## 3. Operational Objective ($Z_{ops}$)

**Variables:**
- $u_i$ = utilization_percent (maximize)
- $cr_i$ = service_criticality (maximize, scale 1-10)
- $dt_i$ = downtime_hours_annual (minimize)

**Transform maximization to minimization:**
$$
\hat{u}'_i = 1 - \frac{u_i}{100} \quad ; \quad
\hat{cr}'_i = 1 - \frac{cr_i}{10}
$$

**Normalization (minimize):**
$$
\hat{dt}_i = \frac{dt_i - \min(dt)}{\max(dt) - \min(dt)}
$$

**Objective function:**
$$
Z_{ops}(i) = w_u \cdot \hat{u}'_i + w_{cr} \cdot \hat{cr}'_i + w_{dt} \cdot \hat{dt}_i
$$

**Weights:**
- $w_u = 0.40$ (utilization is primary operational KPI)
- $w_{cr} = 0.30$ (criticality matters for continuity)
- $w_{dt} = 0.30$ (downtime is cost driver)

**Interpretation:**
- Lower $Z_{ops}$ → better operational performance
- Higher utilization + criticality + low downtime → optimal

---

## 4. Asset Health Objective ($Z_{asset}$)

**Variables:**
- $age_i$ = vehicle_age (years)
- $rul_i$ = remaining_useful_life (years)
- $rel_i$ = reliability_score (0-100)

**Normalization:**
$$
\hat{age}_i = \frac{age_i}{30} \quad ; \quad
\hat{rul}_i = \frac{rul_i}{30} \quad ; \quad
\hat{rel}_i = \frac{rel_i}{100}
$$

**Health Index** (higher = worse asset):
$$
H_i = w_{age} \cdot \hat{age}_i + w_{rul} \cdot (1 - \hat{rul}_i) + w_{rel} \cdot (1 - \hat{rel}_i)
$$

**Weights:**
- $w_{age} = 0.25$ (age penalty)
- $w_{rul} = 0.40$ (RUL is key longevity indicator)
- $w_{rel} = 0.35$ (reliability predicts failure)

**Objective:**
$$
Z_{asset}(i) = H_i
$$

**Interpretation:**
- Older, shorter-RUL, less-reliable → higher objective
- Lower objective → better asset quality

---

## 5. Infrastructure & Risk (NOT Objectives)

### Infrastructure Variables

- $charging\_availability$ → Used as **feasibility constraint**
  - Rule: IF EV_mandate=True THEN charging_availability ≥ threshold
  
- $grid\_dependency$ → Used as **feasibility constraint**
  - Rule: IF high_dependency AND sparse_grid THEN infeasible

### Risk Variables

- $fuel\_price\_volatility$ → Used for **scenario perturbation**
  - In Monte Carlo: $f_i^{scenario} = f_i \cdot (1 + \epsilon_i \cdot \sigma_i)$
  
- $policy\_stability\_score$ → Used for **scenario weighting**
  - In Monte Carlo: low stability → wider uncertainty bounds

---

## 6. Aggregated Objectives (Vector Form)

For all $N$ vehicles, the objective matrix:

$$
\mathbf{Z} = \begin{bmatrix}
Z_{econ}(1) & Z_{env}(1) & Z_{ops}(1) & Z_{asset}(1) \\
Z_{econ}(2) & Z_{env}(2) & Z_{ops}(2) & Z_{asset}(2) \\
\vdots & \vdots & \vdots & \vdots \\
Z_{econ}(N) & Z_{env}(N) & Z_{ops}(N) & Z_{asset}(N)
\end{bmatrix}_{N \times 4}
$$

Dimensions: **N vehicles × 4 objectives**

---

## 7. Dynamic Projected RPI (Without Re-optimization)

Once optimization is done and Monte Carlo runs with marginal contributions cached:

**Per-vehicle, per-objective contribution:**
$$
\text{contrib}_{i,k} = \text{marginal}_k(i)
$$

Where $marginal_k(i)$ is the change in RPI when vehicle $i$ is selected, per objective $k$.

**Projected RPI with user weights:**
$$
\text{RPI}_i^{projected} = \sum_{k=1}^{4} \theta_k \cdot \text{contrib}_{i,k}
$$

Where $\theta = [\theta_{econ}, \theta_{env}, \theta_{ops}, \theta_{asset}]$ are user preference sliders.

**Key Property:** No optimization rerun. Instant update.

---

## 8. Policy Modification Summary Table

| Policy | Affected Objective | Modification | Equation |
|--------|-----------------|--------------|----------|
| **Subsidy** | Economic | Reduce CAPEX weight | $\hat{c}_i \leftarrow (1-s) \hat{c}_i$ |
| **Carbon Tax** | Environmental | Add emissions cost | $Z_{env} + \tau \cdot e_i$ |
| **EV Mandate** | Feasibility | Constraint | $n_{EV} \geq N \times 0.3$ |
| **Emission Cap** | Environmental | Penalty if exceed | $\lambda \cdot \mathbb{1}[e_i > cap]$ |

---

## 9. Normalization Method

**Within-objective normalization:**

For objective $k$ across vehicles:

$$
\hat{Z}_k(i) = \frac{Z_k(i) - \min_j Z_k(j)}{\max_j Z_k(j) - \min_j Z_k(j)}
$$

Result: $\hat{Z}_k(i) \in [0, 1]$ for all $i$

**Why:** Enables fair comparison across different units (INR vs gCO2)

---

## 10. Mathematical Properties

### Linearity
All compositions are weighted sums → linear in normalized variables.

$$
Z_k = \sum_i w_{ki} \cdot \hat{var}_{ki}
$$

### Monotonicity
All weights non-negative → $\partial Z_k / \partial var_i$ has consistent sign.

### Boundedness
Normalized inputs $\in [0,1]$ → $Z_k \in [0, \max(w_{ki})]$

---

## 11. Numerical Example

**Two vehicles, Economic objective only:**

| Vehicle | fuel_cost | maint_cost | capex | downtime |
|---------|-----------|-----------|-------|----------|
| V001 | 12 INR/km | 30K INR/yr | 1.2M INR | 8K INR/day |
| V002 | 10 INR/km | 25K INR/yr | 900K INR | 5K INR/day |
| Min | 10 | 25K | 900K | 5K |
| Max | 12 | 30K | 1.2M | 8K |

**Normalize:**
$$
\hat{f}_1 = \frac{12-10}{12-10} = 1.0, \quad \hat{f}_2 = 0.0
$$

$$
\hat{m}_1 = \frac{30-25}{30-25} = 1.0, \quad \hat{m}_2 = 0.0
$$

$$
\hat{c}_1 = \frac{1.2M - 900K}{1.2M - 900K} = 1.0, \quad \hat{c}_2 = 0.0
$$

$$
\hat{d}_1 = \frac{8K - 5K}{8K - 5K} = 1.0, \quad \hat{d}_2 = 0.0
$$

**Compose (weights: 0.25, 0.25, 0.30, 0.20):**
$$
Z_{econ}(V001) = 0.25(1) + 0.25(1) + 0.30(1) + 0.20(1) = 1.00
$$

$$
Z_{econ}(V002) = 0.25(0) + 0.25(0) + 0.30(0) + 0.20(0) = 0.00
$$

**Interpretation:** V001 is expensive across all dimensions (worse). V002 is economical (better).

---

## 12. Integration with Optimization

**MILP Formulation:**

```text
Minimize: ∑_i x_i · Z_k(i)   for selected objective k

Subject to:
  x_i ∈ {0, 1}
  ∑_i x_i · cost_i ≤ budget
  ∑_i x_i · service_i ≥ min_service
  (other constraints)
```

Solver picks vehicles that minimize the chosen objective.

**Then Monte Carlo** perturbs inputs by 10-25% to generate 50 scenarios.

**Then Projection** reweights cached marginals for instant ranking.

---

## 13. Thesis-Ready Summary

**Theorem (Objective Composition):**

Given a heterogeneous variable space $V = \{v_1, ..., v_m\}$, partition variables by role:

$$
V = V_{ind} \cup V_{constr} \cup V_{uncert}
$$

Define objective $k$ as weighted aggregation over $V_{ind,k} \subseteq V_{ind}$:

$$
Z_k = \sum_{v \in V_{ind,k}} w_v \cdot \text{norm}(v)
$$

Then policy $P$ modifies objectives via:

$$
Z_k^P = f_P(Z_k)
$$

This enables instant re-ranking via:

$$
\text{RPI}_i^{\theta} = \sum_k \theta_k \cdot \text{marg}_{ik}
$$

Without re-optimization.

**Proof:** Linearity + precomputation of marginals.

---

## Patent Claim Language

> "A computer-implemented method for fleet optimization comprising: (1) partitioning variables into objective, constraint, and uncertainty-driver categories; (2) composing objectives via weighted aggregation of indicator variables; (3) applying policy-aware modifications without changing problem structure; (4) enabling instant re-projection of cached Monte Carlo marginals via user-controlled preference weights, eliminating repeated optimization calls."

