# System Architecture After OCE Integration

## Updated Data Flow

```
CSV Input
    |
    v
[Data Engine: load_and_prepare()]
    |---> raw_df
    |---> norm_df
    |
    v
[Objective Composition Engine (NEW)]
    Input: raw_df, norm_df, policy_state
    |
    |---> builds_objectives from variables
    |---> applies_policy_modifiers (subsidy, carbon tax)
    |---> objective_contributions (for projection)
    |
    Output: Dict[objective_name -> ndarray(N,)]
    |
    v
[Optimization Engine]
    Input: raw_df, norm_df, objectives, feasibility
    Output: x_star, objective_values
    |
    v
[Monte Carlo Engine]
    Input: raw_df, oce, feasibility, n_scenarios
    Output: Dict[objective_name -> ndarray(S, N)]
    |
    v
[Cache: Store Results]
    Cache: optimization_result, marginal_contributions, metadata
    |
    v
[Projection Layer]
    Input: cached marginals, user_weights
    |---> instant re-ranking (NO solver call)
    |---> get_summary_table(weights)
    |---> project_classifications(weights)
    |
    Output: ranked_df, rpi_scores
    |
    v
[UI: Visualization]
    - Rankings table
    - RPI chart
    - Sensitivity analysis
    - What-if scenarios
```

---

## File Structure

```
core/
  __init__.py
  
  variable_registry.py         [NEW] Variables, roles, categories
  objective_composer.py        [NEW] OCE - Composes objectives
  
  data.py                      [EXISTING] Load & normalize
  optimize.py                  [EXISTING] MILP solver
  montecarlo.py                [EXISTING] 50-scenario robustness
  marginal.py                  [EXISTING] Marginal contributions
  projection.py                [EXISTING] Instant re-ranking
  explainability.py            [EXISTING] Decision transparency
  cache.py                     [EXISTING] Result caching

app.py                         [NEEDS UPDATE] Use OCE instead of build_objectives
app_refactored.py              [NEEDS UPDATE] Two-mode UI with OCE
```

---

## Key Design Changes

### Before (Static Objectives)
```python
OBJECTIVES = {
    "Economic": {"variables": ["fuel_cost", "capex"], ...},
    "Environmental": {"variables": ["emissions"], ...}
}
```

### After (Dynamic, Policy-Aware)
```python
policy = PolicyState(
    subsidy_active=True,
    subsidy_fraction=0.30,
    carbon_tax=False
)

oce = ObjectiveCompositionEngine(raw_df, norm_df, policy)
objectives = oce.build_objectives()
objectives = oce.apply_policy_modifiers()
```

---

## What Changed vs What Stayed the Same

| Component | Status | Notes |
|-----------|--------|-------|
| OptimizationEngine | No change | Still takes objectives dict |
| MonteCarloEngine | **MINOR** | Takes `oce` instead of `objective_config` |
| ProjectionEngine | No change | Still works with marginals dict |
| ExplainabilityEngine | No change | Still works with contributions |
| Data loading | No change | `load_and_prepare()` unchanged |
| Caching | No change | `StateCache` unchanged |

---

## Variable Registry Roles (IMPORTANT)

Variables are classified into **roles** that determine how they're used:

```python
indicator          -> Contributes to objectives
policy_penalty     -> Modifier applied to objectives (e.g., compliance_liability)
constraint         -> NOT an objective (e.g., charging_availability)
uncertainty_driver -> NOT an objective (e.g., fuel_price_volatility)
```

---

## Objective Categories (Only These)

```python
OBJECTIVE_CATEGORIES = [
    "Economic",      # fuel, maintenance, capex, downtime
    "Environmental", # emissions, pollutants (+ penalties)
    "Operational",   # utilization, criticality, downtime
    "Asset"         # RUL, age, reliability
]
```

**NOT objectives:**
- Infrastructure (charging, grid)
- Risk (volatility, policy stability)

---

## Policy State (NEW)

```python
@dataclass
class PolicyState:
    EV_mandate: bool
    emission_cap_gpkm: float
    subsidy_active: bool
    subsidy_fraction: float
    carbon_tax: bool
    carbon_tax_per_gco2: float
    mandatory_replacement: bool
    region: str
    year: int
```

---

## OCE Public API

```python
class ObjectiveCompositionEngine:

    def __init__(self, raw_df, norm_df, policy_state):
        pass

    def build_objectives() -> Dict[str, ndarray]:
        """Compose objectives from variables"""
        
    def apply_policy_modifiers() -> Dict[str, ndarray]:
        """Apply policy-driven modifications"""
        
    def objective_contributions() -> Dict[str, ndarray]:
        """Get per-vehicle contributions (for projection)"""
        
    def get_summary() -> Dict[str, Dict]:
        """Statistics per objective"""
        
    def to_dataframe() -> DataFrame:
        """Export as DataFrame"""
```

---

## Why This Design

1. **Separation of Concerns**
   - Variables describe data
   - Objectives describe goals
   - Policies modify goals
   - Three layers, not mixed

2. **Extensibility**
   - Add variable → auto-included if in right category
   - Add policy → no code change needed
   - Add objective → create new category, implement compose method

3. **Dynamism**
   - Policy changes → instant objective recomposition
   - Weight changes → instant re-projection (no solver)
   - Feasibility changes → solver re-run

4. **Patent-Ready**
   - Clear innovation: policy-aware composition
   - Mathematical soundness: documented aggregation rules
   - Reproducibility: deterministic computation

---

## Next Steps

1. Update `app.py` to use OCE
2. Update `app_refactored.py` to use OCE
3. Test full workflow with sample data
4. Write unit tests for OCE
5. Create patent claims document

