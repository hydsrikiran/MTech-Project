# MILP SOLVER USAGE COMPARISON

## app_refactored.py (Policy-Based)
```
TAB 1 (RED): Run Decision Engine
├─ 1. OptimizationEngine.solve()
│   └─ Solve MILP ONCE for baseline
│      Time: ~0.1s
│      MILP Solves: 1
│
└─ 2. MonteCarloEngine.run() (50 scenarios)
   └─ For each scenario:
      ├─ Perturb data
      ├─ MarginalContributionEngine.compute_marginal_contributions()
      │  ├─ baseline_solution() → Solve MILP (1 solve)
      │  └─ For each of 10 vehicles:
      │     └─ _solve_without_vehicle(i) → Solve MILP (10 solves)
      │        Total per scenario: 11 MILP solves ❌ EXPENSIVE
      │
      Time per scenario: ~0.5-1.5s
      Total MC time: 30-60s
      MILP Solves: 1 + (50 × 11) = 551 total solves

TAB 2 (BLUE): Explore & Project
├─ NO NEW SOLVES (reuses cached marginals)
└─ Uses ProjectionEngine for instant ranking
```

## app_custom.py (Custom Objectives)
```
TAB 1: Build Objectives
├─ No solving needed
└─ Just UI for composing objectives

TAB 2 (RUN): Run Optimization & Analysis
├─ 1. OptimizationEngine.solve()
│   └─ Solve MILP ONCE for optimal selection
│      Time: ~0.1s
│      MILP Solves: 1
│
└─ 2. MonteCarloEngineCustom.run() (50 scenarios)
   └─ For each scenario:
      ├─ Perturb data
      ├─ builder.build(norm_df=perturbed_norm)
      │  └─ Just weighted sum of variables
      │     NO MILP SOLVING ✅ FAST
      │
      Time per scenario: ~0.014s
      Total MC time: 0.7s
      MILP Solves: 0 (no marginal computation needed)

TAB 3 (Results): Explore & Analyze
├─ NO NEW SOLVES (reuses cached objectives)
└─ Uses ProjectionEngine for instant ranking
```

## KEY DIFFERENCE

**WHY app_custom.py doesn't need 11 solves per scenario:**

app_refactored.py:
- Uses MarginalContributionEngine to compute "removal marginals"
- Asks: "If we remove vehicle i, how does objective value change?"
- This requires solving optimization 11 times per scenario
- Result: Deep understanding of vehicle contributions

app_custom.py:
- Uses objective values directly as "contributions"
- Reasoning: Custom objectives are simple weighted sums
  - Obj = 0.5×fuel_cost + 0.3×capex + 0.2×maintenance
  - Each vehicle's score IS its contribution
  - No need to compute "what if we remove this vehicle"
- Result: Fast Monte Carlo, still captures uncertainty via volatility

## WHEN YOU'D USE EACH

✅ Use app_refactored.py when:
  - Need detailed "removal" marginals
  - Have complex policy interactions
  - Can afford 30-60 second computation
  - Want to understand "critical" vehicles

✅ Use app_custom.py when:
  - Need fast feedback (1-2 seconds)
  - Using simple weighted-sum objectives
  - Want to explore many weight combinations
  - Don't need "removal" analysis
