# OCE Integration Guide

## Overview

The **Objective Composition Engine (OCE)** replaces manual objective configuration with intelligent, policy-aware composition from variables.

### Old Pattern (❌ DEPRECATED)
```python
objective_config = {
    "Economic": {
        "variables": ["fuel_cost", "capex"],
        "transforms": {"fuel_cost": "identity"}
    }
}
objectives = build_objectives(objective_config)
opt = OptimizationEngine(raw_df, norm_df, objectives)
```

### New Pattern (✅ NEW)
```python
policy_state = PolicyState(
    EV_mandate=False,
    subsidy_active=st.sidebar.checkbox("Subsidy"),
    carbon_tax=st.sidebar.checkbox("Carbon Tax")
)

oce = ObjectiveCompositionEngine(raw_df, norm_df, policy_state)
objectives = oce.build_objectives()
objectives = oce.apply_policy_modifiers()

opt = OptimizationEngine(raw_df, norm_df, objectives)
```

---

## Key Differences

| Aspect | Old | New |
|--------|-----|-----|
| **Input** | Manual dict config | Raw data + PolicyState |
| **Objectives** | Hard-coded per category | Composed from variables |
| **Policies** | Outside optimization | Policy-aware composition |
| **Extensibility** | Add new objective = code change | Add new variable = auto-included |
| **Validation** | Manual | Automatic via registry |

---

## Integration Steps

### Step 1: Import OCE
```python
from core.objective_composer import ObjectiveCompositionEngine, PolicyState
from core.variable_registry import VARIABLE_REGISTRY, OBJECTIVE_CATEGORIES
```

### Step 2: Create Policy State in Sidebar
```python
st.sidebar.subheader("Policy Configuration")

policy_state = PolicyState(
    EV_mandate=st.sidebar.checkbox("EV Mandate", False),
    subsidy_active=st.sidebar.checkbox("Subsidy Program", False),
    subsidy_fraction=st.sidebar.slider("Subsidy %", 0.0, 50.0, 0.0) / 100.0 if st.session_state.subsidy_active else 0.0,
    carbon_tax=st.sidebar.checkbox("Carbon Tax", False),
    carbon_tax_per_gco2=st.sidebar.number_input("Tax (INR/gCO2)", 0.0, 5.0, 0.0),
    emission_cap_gpkm=st.sidebar.number_input("Emission Cap (gCO2/km)", 50.0, 200.0, 100.0),
    region=st.sidebar.selectbox("Region", ["India", "Europe", "US"]),
    year=st.sidebar.number_input("Year", 2025, 2030, 2025)
)
```

### Step 3: Build Objectives
```python
oce = ObjectiveCompositionEngine(raw_df, norm_df, policy_state)
objectives = oce.build_objectives()
objectives = oce.apply_policy_modifiers()
```

### Step 4: Use with Optimizer
```python
opt = OptimizationEngine(raw_df, norm_df, objectives, feasibility)
x_star, objective_values = opt.solve()
```

### Step 5: Pass to Monte Carlo & Projection
```python
mc = MonteCarloEngine(raw_df, oce, feasibility, n_scenarios=50)
marginals = mc.run()

projection = ProjectionEngine(
    marginals,
    raw_df["vehicle_id"].tolist(),
    list(objectives.keys())
)

# User adjusts weights in BLUE tab
user_weights = {...}
ranked_df = projection.get_summary_table(user_weights)
```

---

## Variable Registry

All variables are defined in `core/variable_registry.py`:

```python
VARIABLE_REGISTRY = {
    "fuel_cost_per_km": {"category": "Economic", "role": "indicator", ...},
    "emissions": {"category": "Environmental", "role": "indicator", ...},
    "charging_availability": {"category": "Infrastructure", "role": "constraint", ...},
}
```

**Key roles:**
- `indicator` → contributes to objectives
- `constraint` → not an objective (Infrastructure, Risk)
- `policy_penalty` → applied as modifier (compliance_liability)
- `uncertainty_driver` → affects scenarios, not objectives

---

## Objective Categories (Only These Become Objectives)

```python
OBJECTIVE_CATEGORIES = [
    "Economic",       # fuel, maintenance, capex, downtime
    "Environmental",  # emissions, pollutants (+ policy penalties)
    "Operational",    # utilization, criticality, downtime
    "Asset"          # RUL, age, reliability
]
```

**NOT objectives (constraints/drivers):**
- Infrastructure (charging_availability, grid_dependency)
- Risk (fuel_price_volatility, policy_stability)

---

## Policy Conditioning (The Magic)

### Before
```
User sets weights → Projection reweights → Rankings update
```

### After
```
User changes policy (subsidy) 
→ OCE recomposes objectives with subsidy-adjusted CAPEX
→ Projection reweights with new objective values
→ Rankings update instantly
→ NO re-optimization
```

---

## Example: Full Workflow

```python
# 1. Load data
raw_df, norm_df = load_and_prepare("fleet_sample.csv")

# 2. Create policy state
policy = PolicyState(
    subsidy_active=True,
    subsidy_fraction=0.30,  # 30% subsidy on EV CAPEX
    carbon_tax=False
)

# 3. Compose objectives
oce = ObjectiveCompositionEngine(raw_df, norm_df, policy)
objectives = oce.build_objectives()
objectives = oce.apply_policy_modifiers()

# 4. Optimize
opt = OptimizationEngine(raw_df, norm_df, objectives)
x_star, obj_values = opt.solve()

# 5. Monte Carlo
mc = MonteCarloEngine(raw_df, oce, {feasibility}, 50)
marginals = mc.run()

# 6. Project with custom weights
projection = ProjectionEngine(marginals, vehicle_ids, list(objectives.keys()))

user_weights = {"Economic": 0.4, "Environmental": 0.3, "Operational": 0.2, "Asset": 0.1}
summary = projection.get_summary_table(user_weights)

print(summary)
```

---

## Testing OCE

```python
from core.objective_composer import ObjectiveCompositionEngine
from core.data import load_and_prepare

raw_df, norm_df = load_and_prepare("fleet_sample.csv")

oce = ObjectiveCompositionEngine(raw_df, norm_df)
objectives = oce.build_objectives()

print(oce.get_summary())
# Output:
# {
#   "Economic": {"min": 0.12, "max": 0.89, "mean": 0.52, "std": 0.18},
#   "Environmental": {...},
#   ...
# }

# Get contributions for projection
contributions = oce.objective_contributions()
# -> Dict[objective_name -> ndarray(N,)]
```

---

## Migration Checklist

- [ ] Remove import of `build_objectives` from `core.objectives`
- [ ] Add import of `ObjectiveCompositionEngine, PolicyState`
- [ ] Remove manual objective config dict
- [ ] Add `PolicyState` builder in sidebar
- [ ] Create OCE instance after data load
- [ ] Pass objectives from OCE to OptimizationEngine
- [ ] Pass OCE to MonteCarloEngine instead of objective_config
- [ ] Test with sample data
- [ ] Verify projection layer updates instantly when policy changes

---

## Q&A

**Q: What if I have custom variables not in the registry?**
A: Add them to `VARIABLE_REGISTRY` with appropriate role and category.

**Q: Can I change objective weights without re-running optimizer?**
A: Yes! Use ProjectionEngine with `user_weights` dict.

**Q: Can I change policy without re-running optimizer?**
A: Only if it's a modifier (subsidy, carbon_tax). Structure changes (new constraint) require re-run.

**Q: Does OCE replace Projection Layer?**
A: No. OCE composes objectives once. Projection instantly reweights cached marginals.

