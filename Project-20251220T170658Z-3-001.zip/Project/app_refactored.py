"""
HOSF — Hybrid Optimization–Simulation Framework
================================================

Patent-Level Decision Intelligence Platform

Architecture:
1. ✓ Data Engine (load, normalize, validate)
2. ✓ Optimization Engine (MILP solver)
3. ✓ Monte Carlo Engine (scenario-based robustness)
4. ✓ Projection Layer (instant re-ranking without recomputation)
5. ✓ Explainability Engine (decision transparency)

UI Modes:
- 🔴 Mode 1 (RED): Computation Control — Run optimization/MC
- 🔵 Mode 2 (BLUE): Exploration & Projection — Instant slider updates
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import time
import hashlib

from core.data import load_and_prepare
from core.objective_composer import ObjectiveCompositionEngine, PolicyState
from core.optimize import OptimizationEngine
from core.montecarlo import MonteCarloEngine
from core.projection import ProjectionEngine
from core.explainability import ExplainabilityEngine, SensitivityAnalysis
from core.cache import StateCache, SessionStateManager, hash_dict, hash_dataframe
from core.rpi import RPIEngine

# ============================================================================
# PAGE CONFIG
# ============================================================================
st.set_page_config(
    page_title="HOSF — Decision Intelligence",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("🔷 HOSF — Explainable Fleet Optimization")
st.caption(
    "Patent-level decision intelligence for electrification planning"
)

# ============================================================================
# SESSION STATE INITIALIZATION
# ============================================================================
if "state_manager" not in st.session_state:
    st.session_state.state_manager = SessionStateManager(st.session_state)

state_mgr = st.session_state.state_manager

# ============================================================================
# SIDEBAR: DATA UPLOAD & CONFIG
# ============================================================================
with st.sidebar:
    st.subheader("📊 Data & Configuration")
    
    # Upload CSV
    uploaded = st.file_uploader(
        "Upload Fleet CSV",
        type="csv",
        help="Required columns: vehicle_id, fuel_cost_per_km, maintenance_cost_per_year, etc."
    )
    
    if uploaded:
        raw_df, norm_df = load_and_prepare(uploaded)
        dataset_hash = hash_dataframe(raw_df)
        state_mgr.set_data(raw_df, norm_df, dataset_hash)
        st.success(f"✓ Loaded {len(raw_df)} vehicles")
    else:
        st.warning("⬅️ Upload CSV to begin")
        st.stop()
    
    # ====================================================================
    # POLICY CONFIGURATION (OCE)
    # ====================================================================
    st.sidebar.subheader("Policy Configuration")
    
    # Create checkboxes with unique keys
    ev_mandate = st.sidebar.checkbox("EV Mandate", False, key="policy_ev_mandate")
    subsidy_active = st.sidebar.checkbox("Subsidy Program", False, key="policy_subsidy_active")
    carbon_tax = st.sidebar.checkbox("Carbon Tax", False, key="policy_carbon_tax")
    
    # Create conditional inputs based on checkbox values
    subsidy_fraction = (st.sidebar.slider("Subsidy %", 0.0, 50.0, 0.0, key="policy_subsidy_fraction") / 100.0) if subsidy_active else 0.0
    carbon_tax_per_gco2 = st.sidebar.number_input("Tax (INR/gCO2)", 0.0, 5.0, 0.0, key="policy_carbon_tax_amount") if carbon_tax else 0.0
    
    policy_state = PolicyState(
        EV_mandate=ev_mandate,
        subsidy_active=subsidy_active,
        subsidy_fraction=subsidy_fraction,
        carbon_tax=carbon_tax,
        carbon_tax_per_gco2=carbon_tax_per_gco2,
        emission_cap_gpkm=st.sidebar.number_input("Emission Cap (gCO2/km)", 50.0, 200.0, 100.0, key="policy_emission_cap"),
        region=st.sidebar.selectbox("Region", ["India", "Europe", "US"], key="policy_region"),
        year=st.sidebar.number_input("Year", 2025, 2030, 2025, key="policy_year")
    )
    
    # ====================================================================
    # BUILD OBJECTIVES VIA OCE
    # ====================================================================
    oce = ObjectiveCompositionEngine(raw_df, norm_df, policy_state)
    objectives = oce.build_objectives()
    objectives = oce.apply_policy_modifiers()
    
    # Extract objective names for UI
    objective_names = list(objectives.keys())
    
    st.sidebar.subheader("Objective Preferences")
    
    objective_weights = {}
    for name in objective_names:
        weight = st.sidebar.slider(
            f"{name} Weight",
            0.0, 1.0, 0.25,
            step=0.05,
            label_visibility="collapsed"
        )
        objective_weights[name] = weight
    
    # Feasibility Configuration
    st.subheader("⚙️ Feasibility Constraints")
    
    # Show vehicle capex info
    total_fleet_cost = state_mgr.st_session.raw_df["capex_ev"].sum()
    avg_vehicle_cost = state_mgr.st_session.raw_df["capex_ev"].mean()
    min_vehicle_cost = state_mgr.st_session.raw_df["capex_ev"].min()
    max_vehicle_cost = state_mgr.st_session.raw_df["capex_ev"].max()
    
    with st.expander("💰 Budget Information", expanded=False):
        col_info1, col_info2, col_info3 = st.columns(3)
        with col_info1:
            st.metric("Min Vehicle Cost", f"₹{min_vehicle_cost:,.0f}")
        with col_info2:
            st.metric("Avg Vehicle Cost", f"₹{avg_vehicle_cost:,.0f}")
        with col_info3:
            st.metric("Max Vehicle Cost", f"₹{max_vehicle_cost:,.0f}")
        
        st.info(f"**Total Fleet Cost**: ₹{total_fleet_cost:,.0f} ({len(state_mgr.st_session.raw_df)} vehicles)")
        st.write("**Tip**: To select multiple vehicles, set budget ≥ sum of vehicle costs you want to select.")
    
    budget = st.number_input(
        "Total Budget (₹)",
        value=max(10_000_000, int(total_fleet_cost)),
        min_value=int(min_vehicle_cost),
        step=250_000,
        help=f"Minimum ₹{int(min_vehicle_cost):,} (1 vehicle) to ₹{int(total_fleet_cost):,} (all vehicles)"
    )
    
    # Show how many vehicles could fit
    vehicles_per_budget = int(budget / avg_vehicle_cost)
    st.caption(f"💡 Your budget can fit approximately {vehicles_per_budget} vehicles (at average cost)")
    
    min_service = st.slider(
        "Min Service Level",
        0.0, 30.0, 8.0,
        help="Higher = require more critical vehicles in selection"
    )
    
    max_charging = st.slider(
        "Max Charging Capacity",
        1, 200, 50,
        help="Total charging availability capacity (sum across selected vehicles)"
    )
    
    min_fleet_size = st.slider(
        "Minimum Fleet Size (vehicles to select)",
        1, len(state_mgr.st_session.raw_df), 3,
        help="Solver will select at least this many vehicles"
    )
    
    feasibility_config = {
        "budget": budget,
        "min_service_level": min_service,
        "max_charging_load": max_charging,
        "min_fleet_size": min_fleet_size,
    }
    
    state_mgr.set_config(feasibility_config, objectives)
    
    # Normalize weights
    weight_sum = sum(objective_weights.values())
    if weight_sum > 0:
        objective_weights = {k: v / weight_sum for k, v in objective_weights.items()}

# ============================================================================
# MAIN LAYOUT: TWO-MODE SYSTEM
# ============================================================================

# Mode selector tabs
mode_tab1, mode_tab2 = st.tabs(
    ["🔴 RUN DECISION ENGINE", "🔵 EXPLORE & PROJECT"]
)

# ============================================================================
# MODE 1: RED — COMPUTATION CONTROL
# ============================================================================
with mode_tab1:
    st.header("🔴 Decision Engine Computation")
    st.write(
        """
        Heavy lifting happens here. Runs once, then reuse across mode 2.
        
        - **Optimization**: Solves MILP to find best vehicle set under constraints
        - **Monte Carlo**: Simulates 50 scenarios with uncertain parameters
        - **Marginal Analysis**: Computes vehicle contribution per objective
        """
    )
    
    col_status, col_action = st.columns([2, 1])
    
    with col_status:
        # Show cache status
        cache_summary = state_mgr.get_cache().get_summary()
        st.info(f"Cache Status: {cache_summary}")
    
    with col_action:
        run_button = st.button(
            "▶️ RUN OPTIMIZATION & MONTE CARLO",
            width='stretch',
            key="run_computation"
        )
    
    if run_button:
        with st.spinner("⏳ Running optimization..."):
            try:
                start_time = time.time()
                
                # Optimize
                opt_engine = OptimizationEngine(
                    state_mgr.st_session.raw_df,
                    state_mgr.st_session.norm_df,
                    objectives,
                    feasibility_config
                )
                x_star, obj_values = opt_engine.solve()
                opt_time = time.time() - start_time
                
                st.success(f"✓ Optimization done in {opt_time:.2f}s")
                
                # Cache optimization
                state_mgr.get_cache().set_optimization_result(
                    x_star, "optimal", opt_time,
                    feasibility_config, objectives,
                    state_mgr.st_session.dataset_hash
                )
            except Exception as e:
                st.error(f"Optimization failed: {str(e)}")
                state_mgr.record_error(str(e))
                st.stop()
        
        with st.spinner("⏳ Running Monte Carlo (50 scenarios)..."):
            try:
                mc_start = time.time()
                
                # Monte Carlo
                mc_engine = MonteCarloEngine(
                    state_mgr.st_session.raw_df,
                    oce,
                    feasibility_config,
                    n_scenarios=50,
                    seed=42
                )
                marginals = mc_engine.run()
                mc_time = time.time() - mc_start
                
                st.success(f"✓ Monte Carlo done in {mc_time:.2f}s")
                
                # Cache Monte Carlo
                state_mgr.get_cache().set_marginal_contributions(
                    marginals, mc_time, 50
                )
                
                # Also store in session state for easy access
                st.session_state.marginals_cached = marginals
                st.session_state.vehicle_ids_cached = list(raw_df["vehicle_id"])
                
                # Show summary
                st.success("✅ All computation complete!")
                st.info("💡 Switch to 🔵 BLUE tab to explore results!")
                
            except Exception as e:
                st.error(f"Monte Carlo failed: {str(e)}")
                state_mgr.record_error(str(e))
    
    # Display computation details
    if state_mgr.get_cache().metadata:
        st.divider()
        st.subheader("📈 Computation Details")
        
        metadata = state_mgr.get_cache().metadata
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Dataset", f"{len(state_mgr.st_session.raw_df)} vehicles")
        with col2:
            st.metric("Optimization Time", f"{metadata.optimization_time:.2f}s" if metadata else "—")
        with col3:
            st.metric("MC Scenarios", f"{metadata.n_scenarios}" if metadata else "—")
        with col4:
            st.metric("MC Time", f"{metadata.monte_carlo_time:.2f}s" if metadata else "—")

# ============================================================================
# MODE 2: BLUE — EXPLORATION & PROJECTION
# ============================================================================
with mode_tab2:
    st.header("🔵 Dynamic Exploration & Projection")
    st.write(
        """
        All updates here are **instant** — no solver rerun needed!
        
        - Adjust objective weights → rankings update instantly
        - Explore scenarios → animation shows vehicle dynamics
        - View explanations → understand "why"
        """
    )
    
    # Check if computation has been run
    has_results = (
        state_mgr.get_cache().marginal_contributions is not None or
        st.session_state.get("marginals_cached") is not None
    )
    
    if not has_results:
        st.warning("⚠️ Run the RED tab first to compute results")
        st.stop()
    
    # Get cached results - try StateCache first, then session state
    marginals = None
    objectives = None
    vehicle_ids = None
    
    if state_mgr.get_cache().marginal_contributions is not None:
        marginals = state_mgr.get_cache().marginal_contributions
        objectives = state_mgr.get_cache().objectives
        vehicle_ids = state_mgr.st_session.raw_df["vehicle_id"].tolist()
    elif "marginals_cached" in st.session_state:
        marginals = st.session_state.marginals_cached
        vehicle_ids = st.session_state.get("vehicle_ids_cached", [])
        objectives = state_mgr.st_session.current_objectives
    
    # Fallback: must have marginals and objectives
    if marginals is None or objectives is None:
        st.warning("⚠️ Run the RED tab first to compute results")
        st.stop()
    
    # Initialize equal weights for all objectives
    objective_weights = {obj_name: 1.0 / len(objectives) for obj_name in objectives.keys()}
    
    projection_engine = ProjectionEngine(
        marginals,
        vehicle_ids,
        list(objectives.keys())
    )
    
    # ====================================================================
    # SECTION 1: DYNAMIC RANKING WITH WEIGHT ADJUSTMENT
    # ====================================================================
    st.subheader("📊 Dynamic Ranking (Instant Updates)")
    
    # Weight adjustment sliders (mode 2 specific)
    st.write("**Adjust weights in real-time to see rank changes:**")
    
    col_weights = st.columns(len(objective_weights))
    adjusted_weights = {}
    
    for col, (obj_name, base_weight) in zip(col_weights, objective_weights.items()):
        with col:
            adjusted_weights[obj_name] = st.slider(
                obj_name,
                0.0, 1.0,
                value=base_weight,
                step=0.05,
                label_visibility="collapsed",
                key=f"weight_{obj_name}"
            )
    
    # Normalize weights
    weight_sum = sum(adjusted_weights.values())
    if weight_sum > 0:
        adjusted_weights = {k: v / weight_sum for k, v in adjusted_weights.items()}
    
    # Compute projected rankings
    summary_df = projection_engine.get_summary_table(adjusted_weights)
    
    # Display ranking table
    st.dataframe(
        summary_df[["vehicle_id", "rank", "RPI", "Volatility", "Classification"]],
        width='stretch',
        height=400,
        column_config={
            "RPI": st.column_config.NumberColumn(format="%.1f", help="Ranking Preference Index (0-100)"),
            "Volatility": st.column_config.NumberColumn(format="%.1f", help="Uncertainty across scenarios (0-100)"),
        }
    )
    
    # ====================================================================
    # SECTION 2: VISUALIZATION
    # ====================================================================
    st.subheader("📈 Visualizations")
    
    col_chart1, col_chart2 = st.columns(2)
    
    with col_chart1:
        # RPI Bar Chart
        fig_rpi = px.bar(
            summary_df.head(10),
            x="vehicle_id",
            y="RPI",
            color="Classification",
            title="Top 10 Vehicles by RPI",
            labels={"RPI": "Replacement Priority Index"}
        )
        st.plotly_chart(fig_rpi, width='stretch')
    
    with col_chart2:
        # Volatility Scatter
        fig_scatter = px.scatter(
            summary_df,
            x="RPI",
            y="Volatility",
            color="Classification",
            size="rank",
            hover_data=["vehicle_id"],
            title="RPI vs Volatility",
            labels={
                "RPI": "Replacement Priority Index",
                "Volatility": "Decision Volatility"
            }
        )
        st.plotly_chart(fig_scatter, width='stretch')
    
    # ====================================================================
    # SECTION 3: SCENARIO ANIMATION
    # ====================================================================
    st.subheader("🎬 Scenario Explorer")
    
    # Get number of scenarios from marginals
    n_scenarios = next(iter(marginals.values())).shape[0]
    scenario_idx = st.slider(
        "Select Scenario (1-50)",
        0, n_scenarios - 1, 0
    )
    
    # Get weighted values for this scenario
    weighted_vals, scenario_ranking = projection_engine.project_scenario_slice(
        scenario_idx, adjusted_weights
    )
    
    scenario_df = pd.DataFrame({
        "vehicle_id": vehicle_ids,
        "marginal": weighted_vals
    }).sort_values("marginal", ascending=False).reset_index(drop=True)
    
    fig_scenario = px.bar(
        scenario_df.head(15),
        x="vehicle_id",
        y="marginal",
        title=f"Scenario {scenario_idx + 1}: Marginal Contributions",
        labels={"marginal": "Weighted Marginal Value"}
    )
    st.plotly_chart(fig_scenario, width='stretch')
    
    # ====================================================================
    # SECTION 4: EXPLAINABILITY
    # ====================================================================
    st.subheader("💡 Why This Ranking?")
    
    explanability_engine = ExplainabilityEngine(
        state_mgr.st_session.raw_df,
        projection_engine,
        vehicle_ids
    )
    
    # Select vehicle for explanation
    selected_vehicle = st.selectbox(
        "Select vehicle to explain",
        vehicle_ids
    )
    
    vehicle_idx = vehicle_ids.index(selected_vehicle)
    rank = summary_df[summary_df["vehicle_id"] == selected_vehicle]["rank"].values[0]
    classification = summary_df[summary_df["vehicle_id"] == selected_vehicle]["Classification"].values[0]
    
    explanation = explanability_engine.explain_vehicle_recommendation(
        vehicle_idx, adjusted_weights, int(rank), classification
    )
    
    col_exp1, col_exp2 = st.columns([2, 1])
    
    with col_exp1:
        st.markdown(f"### {selected_vehicle}")
        st.write(explanation["summary"])
        
        st.write("**Key Drivers:**")
        for driver in explanation["top_drivers"]:
            st.write(f"- {driver}")
    
    with col_exp2:
        st.metric("RPI", f"{explanation['rpi']:.3f}")
        st.metric("Volatility", f"{explanation['volatility']:.3f}")
        st.metric("Classification", explanation["classification"])
    
    # Contribution breakdown
    if explanation["contribution_breakdown"]:
        st.write("**Objective Contributions:**")
        contrib_df = pd.DataFrame(explanation["contribution_breakdown"])
        st.dataframe(
            contrib_df[["Objective", "Mean_Contribution", "Weight", "Weighted_Contribution"]],
            width='stretch'
        )
    
    # What-if scenarios
    if explanation["what_if_scenarios"]:
        st.write("**What-If Scenarios:**")
        for scenario in explanation["what_if_scenarios"]:
            st.info(
                f"{scenario['scenario']}: {scenario['direction']} ({scenario['change_percent']:.1f}%)"
            )
    
    # ====================================================================
    # SECTION 5: SENSITIVITY ANALYSIS
    # ====================================================================
    st.subheader("📊 Robustness Analysis")
    
    sensitivity = SensitivityAnalysis(projection_engine, vehicle_ids)
    stability_df = sensitivity.ranking_stability(adjusted_weights, n_samples=100)
    
    fig_stability = px.bar(
        stability_df.head(15),
        x="vehicle_id",
        y="stability_percent",
        title="Ranking Stability Across Weight Perturbations",
        labels={"stability_percent": "In Top-5 Frequency (%)"}
    )
    st.plotly_chart(fig_stability, width='stretch')
    
    # ====================================================================
    # SECTION 6: FLEET NARRATIVE
    # ====================================================================
    st.subheader("📋 Executive Summary")
    
    narrative = explanability_engine.generate_fleet_narrative(adjusted_weights, top_n=5)
    st.markdown(narrative)

# ============================================================================
# FOOTER
# ============================================================================
st.divider()
st.caption(
    "HOSF v1.0 | Patent-level decision intelligence for electrification planning"
)
