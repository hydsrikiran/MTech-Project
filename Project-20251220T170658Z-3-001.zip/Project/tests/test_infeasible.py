"""Test error message when budget is infeasible"""
from core.data import load_and_prepare
from core.custom_objectives import CustomObjectiveBuilder
from core.optimize import OptimizationEngine

raw, norm = load_and_prepare('fleet_sample.csv')

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])

objectives = builder.build()

# TOO TIGHT - should fail
feas = {
    'budget': 2_000_000,  # Less than cheapest 3 vehicles (₹3.39M)
    'service_level': 0.95,
    'charging_capacity': 50,
    'min_fleet_size': 3,
}

print("Testing with infeasible budget (₹2M)...\n")

try:
    opt = OptimizationEngine(raw, norm, objectives, feas)
    x_star, objs = opt.solve()
    print("✓ Solved!")
except Exception as e:
    print(f"Error caught:\n{e}")
