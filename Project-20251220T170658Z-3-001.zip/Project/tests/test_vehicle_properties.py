from core.data import load_and_prepare
import pandas as pd

raw, norm = load_and_prepare('fleet_sample.csv')

print("Columns in raw data:")
print(raw.columns.tolist())
print()

print("Vehicle costs and key properties:")
print()
for i in range(len(raw)):
    capex = raw.iloc[i].get('capex_ev', 'N/A')
    fuel = raw.iloc[i].get('fuel_cost_per_km', 'N/A')
    co2 = raw.iloc[i].get('co2_emission_gpkm', 'N/A')
    print(f"V{i:02d}: capex={capex:>12} fuel={fuel:>8} co2={co2:>8}")
