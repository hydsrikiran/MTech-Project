"""Test what MonteCarloEngineCustom actually does"""
import time
import numpy as np
from core.data import load_and_prepare
from core.custom_objectives import CustomObjectiveBuilder
from core.montecarlo_custom import MonteCarloEngineCustom

# Load data
raw, norm = load_and_prepare('fleet_sample.csv')

# Build objectives
builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])

objectives = builder.build()

# Feasibility
feas = {
    'budget': 12_190_000,
    'service_level': 0.95,
    'charging_capacity': 50,
    'min_fleet_size': 5,
}

print("=" * 60)
print("Testing MonteCarloEngineCustom")
print("=" * 60)

# Create MC engine
mc_engine = MonteCarloEngineCustom(raw, norm, builder, feas, n_scenarios=2)  # Just 2 for speed

print("\nStarting MC with 2 scenarios (should still involve solves)...")
start = time.time()
try:
    marginals = mc_engine.run()
    elapsed = time.time() - start
    print(f"\n✓ MC completed in {elapsed:.2f}s")
    print(f"\nMarginals keys: {list(marginals.keys())}")
    for obj_name, m in marginals.items():
        print(f"  {obj_name}: shape={m.shape}, min={np.min(m):.3f}, max={np.max(m):.3f}, any_zero={np.all(m==0)}")
        print(f"    Values: {m[0]}")  # Show first scenario
except Exception as e:
    elapsed = time.time() - start
    print(f"\n✗ MC failed in {elapsed:.2f}s")
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
