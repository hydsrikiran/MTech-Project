"""Verify: When we remove V00, what happens?"""
import numpy as np
from core.data import load_and_prepare
from core.custom_objectives import CustomObjectiveBuilder
from core.optimize import OptimizationEngine

raw, norm = load_and_prepare('fleet_sample.csv')

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])

objectives = builder.build()

feas = {
    'budget': 12_190_000,
    'service_level': 0.95,
    'charging_capacity': 50,
    'min_fleet_size': 5,
}

print("=" * 70)
print("VEHICLE REMOVAL SIMULATION")
print("=" * 70)

# BASELINE
print("\n1. BASELINE (all 10 vehicles available)")
opt_base = OptimizationEngine(raw, norm, objectives, feas)
x_base, obj_base = opt_base.solve()
selected_base = [i for i in range(10) if x_base[i] > 0.5]
print(f"  Selected: {selected_base}")
print(f"  Cost: {obj_base['Cost']:.6f}")
print(f"  Env: {obj_base['Environment']:.6f}")

# REMOVE V00
print("\n2. REMOVE V00 (9 vehicles available)")
raw_rem = raw.drop(index=0).reset_index(drop=True)
norm_rem = norm.drop(index=0).reset_index(drop=True)

opt_rem = OptimizationEngine(raw_rem, norm_rem, objectives, feas)
x_rem, obj_rem = opt_rem.solve()
# Adjust indices back to original
x_rem_full = np.zeros(10)
x_rem_full[1:] = x_rem
selected_rem = [i for i in range(10) if x_rem_full[i] > 0.5]
print(f"  Selected: {selected_rem}")
print(f"  Cost: {obj_rem['Cost']:.6f}")
print(f"  Env: {obj_rem['Environment']:.6f}")

print(f"\n3. MARGINAL CONTRIBUTION OF V00")
print(f"  Cost marginal: {obj_base['Cost'] - obj_rem['Cost']:.6f} (positive = important)")
print(f"  Env marginal: {obj_base['Environment'] - obj_rem['Environment']:.6f}")

print(f"\n4. FLEET COMPOSITION CHANGE")
baseline_set = set(selected_base)
removal_set = set(selected_rem)
print(f"  Dropped from baseline: {baseline_set - removal_set}")
print(f"  Added to new solution: {removal_set - baseline_set}")
print(f"  If they're different, solver found alternative fleet!")
