"""Find the feasible budget range for 3 vehicles"""
import numpy as np
from core.data import load_and_prepare
from core.custom_objectives import CustomObjectiveBuilder
from core.optimize import OptimizationEngine

raw, norm = load_and_prepare('fleet_sample.csv')

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])
builder.add_objective('Operations', ['maintenance_cost_per_year', 'downtime_cost_per_day'], [0.6, 0.4])
builder.add_objective('Asset Quality', ['reliability_score', 'remaining_useful_life'], [0.7, 0.3])

objectives = builder.build()

print("=" * 70)
print("FINDING FEASIBLE BUDGET RANGE FOR 3 VEHICLES")
print("=" * 70)
print()

# Get vehicle costs sorted
costs = sorted(raw['capex_ev'].values)
print(f"Vehicle costs (sorted): {[f'₹{c:,.0f}' for c in costs]}")
print()

# Minimum budget for any 3 vehicles
min_3_sum = sum(costs[:3])
print(f"Minimum for 3 cheapest: ₹{min_3_sum:,.0f}")

# Test budgets
test_budgets = [
    int(min_3_sum),
    int(min_3_sum * 1.1),
    int(min_3_sum * 1.2),
    int(min_3_sum * 1.3),
]

for test_budget in test_budgets:
    feas = {
        'budget': test_budget,
        'service_level': 0.95,
        'charging_capacity': 50,
        'min_fleet_size': 3,
    }
    
    try:
        opt = OptimizationEngine(raw, norm, objectives, feas)
        x_star, _ = opt.solve()
        selected = [i for i in range(10) if x_star[i] > 0.5]
        used_cost = raw.iloc[selected]['capex_ev'].sum()
        print(f"✓ Budget ₹{test_budget:,}: FEASIBLE - selected {selected}, cost ₹{used_cost:,.0f}")
    except Exception as e:
        error_msg = str(e).split('\n')[0]
        print(f"✗ Budget ₹{test_budget:,}: INFEASIBLE - {error_msg}")

print()
print("Recommendation: Use budget 20-30% above minimum for 3 vehicles")
recommended = int(min_3_sum * 1.25)
print(f"  Suggested: ₹{recommended:,}")
