from core.custom_objectives import CustomObjectiveBuilder
from core.data import load_and_prepare
from core.marginal import MarginalContributionEngine
import numpy as np

raw, norm = load_and_prepare('fleet_sample.csv')

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])

objectives = builder.build()

tight_feas = {
    'budget': 12_190_000,
    'min_fleet_size': 5,
    'min_service_level': 0.95,
    'max_charging_load': 50
}

print("Testing vehicle removals...")
print()

engine = MarginalContributionEngine(raw, norm, objectives, tight_feas)
baseline_x, baseline_objs = engine.baseline_solution()

print(f"BASELINE (all 5 vehicles)")
print(f"  Cost:        {baseline_objs['Cost']:.3f}")
print(f"  Environment: {baseline_objs['Environment']:.3f}")
print(f"  Vehicles: {[i for i in range(10) if baseline_x[i] > 0.5]}")
print()

# Try removing each vehicle
for v in range(10):
    if baseline_x[v] > 0.5:  # If in baseline
        # Test removing this vehicle
        from core.optimize import OptimizationEngine
        
        opt = OptimizationEngine(raw, norm, objectives, tight_feas)
        opt.add_exclusion_set([v])
        try:
            x_removed, objs_removed = opt.optimize()
            marginal = baseline_objs['Cost'] - objs_removed['Cost']
            vehicles_removed = [i for i in range(10) if x_removed[i] > 0.5]
            print(f"Remove V{v:02d}:")
            print(f"  Cost:        {objs_removed['Cost']:.3f} (marginal: {marginal:.3f})")
            print(f"  Vehicles: {vehicles_removed}")
        except Exception as e:
            print(f"Remove V{v:02d}: INFEASIBLE - {str(e)[:50]}")
print()
