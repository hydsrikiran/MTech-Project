#!/usr/bin/env python3
"""
Final verification test - complete OCE workflow with all 18 variables
"""

import pandas as pd
import json
from core.objective_composer import ObjectiveCompositionEngine, PolicyState
from core.validation import DatasetValidator
from core.optimize import OptimizationEngine
from core.montecarlo import MonteCarloEngine
from core.data import load_and_prepare

print("="*60)
print("FINAL VERIFICATION TEST")
print("="*60)

# Step 1: Load and validate data
print("\n[1/5] Loading fleet_sample.csv...")
try:
    raw_df, norm_df = load_and_prepare("fleet_sample.csv")
    print(f"  OK - {len(raw_df)} vehicles, {len(raw_df.columns)} variables")
except Exception as e:
    print(f"  FAIL - {e}")
    exit(1)

# Step 2: Validate
print("\n[2/5] Validating data...")
try:
    validator = DatasetValidator()
    result = validator.validate(raw_df)
    print(f"  OK - Status: {result.status}")
except Exception as e:
    print(f"  FAIL - {e}")
    exit(1)

# Step 3: Create OCE and build objectives
print("\n[3/5] Building objectives with OCE...")
try:
    policy = PolicyState(
        EV_mandate=True,
        subsidy_active=True,
        carbon_tax_per_gco2=0.05,
        emission_cap_gpkm=150,
        region='urban',
        year=2024
    )
    oce = ObjectiveCompositionEngine(raw_df, norm_df, policy)
    objectives = oce.build_objectives()
    print(f"  OK - {len(objectives)} objectives created")
    for obj_name, vals in objectives.items():
        print(f"      {obj_name}: mean={vals.mean():.3f}, std={vals.std():.3f}")
except Exception as e:
    print(f"  FAIL - {e}")
    import traceback
    traceback.print_exc()
    exit(1)

# Step 4: Optimize
print("\n[4/5] Running optimization...")
try:
    feasibility = {
        'budget_limit': 10000000,
        'service_level': 0.95,
        'charging_capacity': 100,
        'mandatory_replacement': False
    }
    opt_engine = OptimizationEngine(raw_df, norm_df, objectives, feasibility)
    x_star, obj_values = opt_engine.solve()
    selected_count = sum(x_star)
    print(f"  OK - Selected {int(selected_count)} vehicles")
    for obj_name, val in obj_values.items():
        print(f"      {obj_name}: {val:.4f}")
except Exception as e:
    print(f"  FAIL - {e}")
    import traceback
    traceback.print_exc()
    exit(1)

# Step 5: Monte Carlo
print("\n[5/5] Running Monte Carlo (5 scenarios)...")
try:
    mc_engine = MonteCarloEngine(raw_df, oce, feasibility, n_scenarios=5, seed=42)
    marginals = mc_engine.run()
    print(f"  OK - {len(marginals)} objectives with scenarios")
    for obj_name, vals in marginals.items():
        print(f"      {obj_name}: shape={vals.shape}")
except Exception as e:
    print(f"  FAIL - {e}")
    import traceback
    traceback.print_exc()
    exit(1)

print("\n" + "="*60)
print("ALL TESTS PASSED - SYSTEM READY")
print("="*60)
print("\nNext steps:")
print("1. Upload your fleet CSV to the Streamlit app")
print("2. Configure policy in the RED tab")
print("3. Click 'RUN OPTIMIZATION & MONTE CARLO'")
print("4. Switch to BLUE tab for interactive exploration")
print("\nStreamlit app: streamlit run app_refactored.py")
