from core.custom_objectives import CustomObjectiveBuilder
from core.data import load_and_prepare
from core.montecarlo_custom import MonteCarloEngineCustom
from core.projection import ProjectionEngine
import numpy as np

raw, norm = load_and_prepare('fleet_sample.csv')

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])
builder.add_objective('Operations', ['utilization_percent'], [1.0])
builder.add_objective('Asset Quality', ['reliability_score'], [1.0])

# Run MC
mc = MonteCarloEngineCustom(raw, norm, builder, {'budget': 10_000_000, 'min_fleet_size': 3}, n_scenarios=50)
marginals = mc.run()

print(f'Marginals keys: {list(marginals.keys())}')
print(f'Marginals shape: {marginals["Cost"].shape}')
print(f'Cost values (first vehicle, 5 scenarios): {marginals["Cost"][:5, 0]}')
print(f'Cost range: {marginals["Cost"].min():.3f} - {marginals["Cost"].max():.3f}')

# Create projection
vehicle_ids = raw['vehicle_id'].tolist()
projection = ProjectionEngine(marginals, vehicle_ids, list(builder.list_objectives()))

# Compute summary
weights = {obj: 1.0/len(builder.list_objectives()) for obj in builder.list_objectives()}
summary = projection.get_summary_table(weights)

print('\n=== SUMMARY TABLE ===')
print(summary.head(10))
print(f'\nRPI values (first 5): {summary["RPI"].head().tolist()}')
print(f'RPI range: {summary["RPI"].min():.1f} - {summary["RPI"].max():.1f}')
print(f'Volatility range: {summary["Volatility"].min():.1f} - {summary["Volatility"].max():.1f}')
