# QUICK START GUIDE — HOSF

## What is HOSF?

**HOSF** (Hybrid Optimization–Simulation Framework) is a decision intelligence system that helps you plan fleet electrification strategically.

It answers:
- ❓ Which vehicles should we replace first?
- ❓ How robust is this plan to cost changes?
- ❓ What if we prioritize environment over cost?
- ❓ Why is this vehicle in the top 10?

---

## 30-Second Setup

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Prepare Your Data
Create a CSV file with columns:
- `vehicle_id`: Unique identifier (e.g., "VH001")
- `fuel_cost_per_km`: Annual fuel cost per km
- `maintenance_cost_per_year`: Annual maintenance
- `capex_ev`: Capital cost of EV conversion
- `co2_emission_gpkm`: Current CO2 emissions
- `annual_km`: Annual kilometers driven
- `service_criticality`: 0-1 (how critical is this vehicle)
- `vehicle_age`: Years in service
- `charging_available`: 0-1 (charging infrastructure available)
- `mandatory_replacement`: 0 or 1 (replacement required?)
- `fuel_price_volatility`: 0-1 (price uncertainty)

**Example: `fleet_sample.csv`** is included in the repo.

### Step 3: Run the App
```bash
streamlit run app_refactored.py
```

Opens at `http://localhost:8501`

---

## The Two-Mode System

### 🔴 RED TAB: "RUN DECISION ENGINE"

**When**: You upload data, or want to update based on new information

**What to do**:
1. Upload CSV
2. Set objectives (Economic, Environmental, Service, Reliability)
3. Set constraints (Budget, Service Level, Charging)
4. Click "▶️ RUN OPTIMIZATION & MONTE CARLO"
5. Wait 20-40 seconds
6. See "✅ All computation complete!"

**Don't touch**: RED tab happens once per analysis

### 🔵 BLUE TAB: "EXPLORE & PROJECT"

**When**: You want to play with different scenarios (weights, what-ifs)

**What to do**:
1. Slide objective weights left/right (instant!)
2. Watch rankings change in real-time
3. Click on any vehicle to see "why"
4. Slide scenario selector to explore different futures

**Superpower**: Everything is instant — no waiting

---

## Example Workflow (5 minutes)

### Scenario: "We're planning EV conversion for next 2 years"

#### RED TAB (5 min)
1. Upload your fleet CSV
2. Set Budget = ₹5 crores
3. Set Service Level = 10 (out of 30)
4. Economic weight = 0.6, Environmental = 0.4
5. Click "RUN"
   - Optimization: 2 seconds ⏱️
   - Monte Carlo: 25 seconds ⏱️
6. See results

#### BLUE TAB (∞ exploration)
1. "We can spend more" → slide Budget higher → rankings update instantly
2. "Environment matters more" → slide Environmental weight to 0.7 → rankings change
3. Click on vehicle #5 → see "why is it ranked 5th?"
   - Breakdowns: 60% fuel cost, 30% maintenance, 10% emissions
   - What-if: "If only emissions mattered, it'd rank #2"
4. Watch scenario animation → "In 40% of market conditions, this vehicle is top-3"

**Done!** Share the visualization with team.

---

## Understanding the Output

### Rankings Table

| vehicle_id | rank | RPI | Volatility | Classification |
|-----------|------|-----|-----------|-----------------|
| VH001 | 1 | 0.87 | 0.12 | High-Priority Robust |
| VH002 | 2 | 0.81 | 0.08 | High-Priority Robust |
| VH035 | 47 | 0.12 | 0.35 | Low-Priority Sensitive |

**RPI** (Replacement Priority Index): How much value replacing this vehicle creates (0-1)
- 0.8+ → Strong candidate
- 0.5-0.8 → Consider
- <0.5 → Lower priority

**Volatility**: How much this decision changes in different scenarios
- Low (<0.15) → Robust decision, safe to act
- High (>0.25) → Decision sensitive to market changes, requires monitoring

**Classification**:
- **High-Priority Robust**: Replace first ✅
- **High-Priority Sensitive**: Replace first but monitor conditions
- **Medium-Priority**: Replace in phase 2-3
- **Low-Priority Robust**: Replace later, safe timing
- **Low-Priority Sensitive**: Flexible, depends on conditions

---

## Key Charts

### Bar Chart: Top 10 Vehicles by RPI
"Who should we replace first?"
- Colored by classification
- Higher bar = higher priority

### Scatter: RPI vs Volatility
"Which decisions are safe?"
- Top-left = replace first (high priority, low risk)
- Bottom-right = risky (low priority, high uncertainty)
- Bubble size = rank position

### Scenario Animation
"What could happen?"
- Slide selector 1-50
- See how priorities shift across market conditions

---

## Vehicle Explanation Example

**Vehicle VH012: Truck Fleet Manager**

```
Summary:
Rank #3: High replacement priority driven by Fuel Cost. 
Strong potential benefit (RPI: 0.83).

Key Drivers:
- Fuel Cost (60%)
- Service Criticality (25%)
- Emissions (15%)

What-If Scenarios:
- "If only Fuel Cost mattered" ↑ Improves (+8%)
- "If only Emissions mattered" ↓ Worsens (-12%)
```

**How to read**: 
- This vehicle is #3 priority
- Mainly because fuel costs are high (60% of its value)
- Also important because it serves critical routes (service 25%)
- Less about emissions (15%)
- If fuel prices drop, this vehicle becomes less attractive

---

## Common Questions

### Q: Why does vehicle X rank higher after I change weights?

**A**: Because the objectives it excels in now have higher weight. Use the "Contribution Breakdown" to see.

### Q: What's "Volatility"?

**A**: Imagine 50 possible futures (market prices, technology costs, policy changes). Volatility = "How much does this vehicle's ranking bounce around?" Low volatility = safe bet.

### Q: What's the difference between the two tabs?

**A**: 
- RED = brain (computation, thinking hard)
- BLUE = exploration (instant, interactive)

RED is slow but thorough. BLUE is fast because it reuses RED's work.

### Q: How do I use this for decision-making?

**Step 1**: Run RED tab once
**Step 2**: Explore BLUE tab with stakeholders (budget, priorities, etc.)
**Step 3**: Use explanations to justify choices
**Step 4**: Export results to share with team

### Q: Can I change the data and re-run?

**A**: Yes! Upload new CSV → RED tab → click RUN → BLUE tab updates.

### Q: What if my CSV is missing columns?

**A**: App will tell you which columns are missing. See ARCHITECTURE.md for full list.

---

## Tips & Tricks

### 💡 Tip 1: Start Conservative
- Low budget first → see who's essential
- Then increase budget → see phase 2 candidates

### 💡 Tip 2: Test Sensitivity
- Set all weights equal (0.25 each)
- Gradually increase one weight
- See which vehicles flip priorities

### 💡 Tip 3: Robustness Check
- Look at "Volatility" chart
- High volatility vehicles need contingency plans

### 💡 Tip 4: Stakeholder Alignment
- Run BLUE tab with team
- Let each person adjust weights
- Show how it changes rankings
- Builds consensus

### 💡 Tip 5: Export for Reports
- Copy-paste charts into PowerPoint
- Include ranking table
- Add vehicle explanations

---

## Technical Details (If You Care)

### How does HOSF work?

1. **Optimization Phase** (RED tab)
   - Solves a math problem: "Which vehicles give max value under budget?"
   - Uses Mixed-Integer Linear Programming (MILP)
   - Considers all constraints

2. **Uncertainty Phase** (RED tab)
   - Runs 50 simulations with random market changes
   - Measures how stable each vehicle's ranking is
   - Computes value (marginal contribution) for each vehicle

3. **Projection Phase** (BLUE tab)
   - Takes cached results from steps 1-2
   - Reweights vehicles based on your preferences
   - Updates rankings instantly

**Why is this smart?** 
- Steps 1-2 are slow (25-40 sec)
- Step 3 is instant (<0.1 sec)
- Users only run 1-2 once, then explore many times

### What solver is used?

GLPK (GNU Linear Programming Kit)
- Free & open-source
- Good for fleets up to ~100 vehicles
- For larger fleets, upgrade to Gurobi/CPLEX

### What's a "marginal contribution"?

Vehicle's value = fleet benefit with it − fleet benefit without it

Example:
- With vehicle VH001: Can serve 90% of routes
- Without vehicle VH001: Can serve 80% of routes
- Marginal value = 10%

---

## Architecture Overview (Visual)

```
┌─────────────────────────────────────┐
│   📊 Your Fleet Data (CSV)          │
└────────────┬────────────────────────┘
             │
             ▼
    ┌────────────────────┐
    │ 🔴 RED TAB: Compute│
    │ - Optimize         │
    │ - Monte Carlo      │
    │ - Marginals        │
    └────────┬───────────┘
             │
             ▼ (Cache)
    ┌────────────────────┐
    │ 💾 Cached Results  │
    │ (Reusable)         │
    └────────┬───────────┘
             │
             ▼
    ┌────────────────────┐
    │ 🔵 BLUE TAB: Use   │
    │ - Instant ranking  │
    │ - What-if analysis │
    │ - Explanations     │
    └────────────────────┘
             │
             ▼
    ┌────────────────────┐
    │ 📈 Visualizations  │
    │ & Reports          │
    └────────────────────┘
```

---

## Troubleshooting

### Issue: "Upload CSV to begin"
**Solution**: Make sure you selected a .csv file

### Issue: "Missing required columns"
**Solution**: Check your CSV has all columns listed in ARCHITECTURE.md

### Issue: "Solver timeout"
**Solution**: Reduce fleet size or increase timeout in code

### Issue: BLUE tab shows old data
**Solution**: Go back to RED tab and run again

### Issue: Charts look weird
**Solution**: Check for NaN (missing) values in your data

---

## Next Steps

1. ✅ Download and install
2. ✅ Upload `fleet_sample.csv` to test
3. ✅ Click "RUN OPTIMIZATION"
4. ✅ Explore BLUE tab
5. ✅ Upload your real fleet data
6. ✅ Use for planning!

---

## Support & Documentation

- **Quick Start**: This file
- **Architecture**: `ARCHITECTURE.md` (technical deep-dive)
- **Example Data**: `fleet_sample.csv`
- **Code**: `app_refactored.py` (commented)

---

## Citation

If you use HOSF for research or publications:

```
HOSF: Hybrid Optimization–Simulation Framework for Fleet Electrification Planning
M.Tech Research Project, [Year]
```

---

**Happy planning! 🚗🔋**
