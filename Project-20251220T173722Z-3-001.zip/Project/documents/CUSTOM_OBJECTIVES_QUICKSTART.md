# Quick Reference: Custom Objective Builder

## Launch the App
```bash
streamlit run app_custom.py
```

## Three Tabs

### 🔧 Tab 1: Build Objectives
- Click a template (💰 Cost | 🌍 Environment | 🔧 Reliability | ⚖️ Balanced | 🆕 Custom)
- Customize by selecting variables and assigning weights
- Click "Save Objectives"

### 🚀 Tab 2: Run Optimization
- Set feasibility constraints (budget, service level, etc.)
- Click "RUN OPTIMIZATION & MONTE CARLO"
- Wait for computation to complete

### 📊 Tab 3: Results & Analysis
- View optimal vehicle selection
- Adjust objective weights with sliders
- See rankings update **instantly** (no re-computation)

---

## 18 Variables Available

| Category | Variables | Count |
|----------|-----------|-------|
| **Economic** | fuel_cost_per_km, maintenance_cost_per_year, capex_ev, downtime_cost_per_day | 4 |
| **Environmental** | co2_emission_gpkm, pollutants_index, compliance_liability | 3 |
| **Operational** | utilization_percent, downtime_hours_annual, service_criticality | 3 |
| **Asset** | reliability_score, remaining_useful_life, vehicle_age | 3 |
| **Infrastructure** | charging_availability, grid_dependency | 2 |
| **Uncertainty** | fuel_price_volatility, policy_stability_score | 2 |

---

## Example: Build "Total Cost" Objective

1. **Tab 1 → Custom**
2. **Objective 1:**
   - Name: `Total Cost`
   - Variables: `capex_ev`, `fuel_cost_per_km`, `maintenance_cost_per_year`
   - Weights: `0.4`, `0.3`, `0.3`
3. **Objective 2:**
   - Name: `Environment`
   - Variables: `co2_emission_gpkm`, `pollutants_index`
   - Weights: `0.5`, `0.5`
4. **Save Objectives**
5. **Tab 2 → Run Optimization**
6. **Tab 3 → Explore Rankings**

---

## Key Differences from Original App

| Feature | Original (app_refactored.py) | Custom (app_custom.py) |
|---------|-----|-----|
| Objectives | 4 Fixed (Economic, Environmental, Operational, Asset) | **Unlimited Custom** |
| Variable Selection | Pre-determined | **User-selected** |
| Weight Assignment | High-level objective weights | **Per-variable weights** |
| Flexibility | Limited | **Maximum** |
| Complexity | Lower | **Higher** |

---

## Templates Explained

### 💰 Cost-Focused
- **Acquisition Cost**: `capex_ev` (100%)
- **Operating Cost**: `fuel_cost` (40%) + `maintenance` (35%) + `downtime` (25%)

### 🌍 Environment-Focused
- **Emissions**: `co2` (50%) + `pollutants` (50%)
- **Compliance**: `liability` (100%)

### 🔧 Reliability-Focused
- **Uptime**: `reliability` (60%) + `utilization` (40%)
- **Durability**: `remaining_life` (70%) + `age` (30%)

### ⚖️ Balanced
- 4 objectives (Cost, Environment, Operations, Assets)
- Each variable equally weighted within objective
- Fair representation across all dimensions

---

## Computation Steps

### Optimization (2-5 seconds)
1. Runs MILP solver
2. Finds optimal vehicle selection
3. Computes objective values
4. Reports total cost & metrics

### Monte Carlo (30-60 seconds)
1. Runs 50 perturbation scenarios
2. Each scenario: ±5% normal perturbation
3. Re-computes objectives each time
4. Stores marginal contributions

### Results (Instant)
- Rankings update instantly when you adjust weights
- No re-solve needed
- Powered by projection engine

---

## Tips

✅ **DO:**
- Start with a template
- Use 2-4 objectives for clarity
- Adjust weights in Tab 3 to explore
- Use meaningful names
- Run full 50 scenarios for robustness

❌ **DON'T:**
- Create too many variables per objective (>5)
- Make weights too imbalanced (one dominating)
- Skip Monte Carlo (robustness check)
- Assume Tab 3 rankings are final (explore more)

---

## Comparison: Static vs. Dynamic

**Static (Original):**
```
Economic = 0.25×fuel_cost + 0.25×maintenance + 0.30×capex + 0.20×downtime
Environmental = 0.60×emissions + 0.40×pollutants
Operational = 0.40×utilization + 0.30×downtime + 0.30×service
Asset = 0.25×reliability + 0.40×life + 0.35×age
```

**Dynamic (Custom):**
```
You define:
  Objective 1 = ?
  Objective 2 = ?
  ... (1-6 objectives)
  
Choose any variables, any weights!
```

---

**Quick Start:** Load CSV → Click ⚖️ Balanced → Run → Explore! 🚀
