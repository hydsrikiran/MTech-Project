# Zero Marginals Problem: Root Cause & Solution

## Issue Summary
User was seeing **all 0 values** for RPI and Volatility, even after upgrading to research-grade MC with full marginal computation (18.1 seconds for 50 scenarios).

## Root Cause
**The optimization problem was DEGENERATE:**
- With loose constraints (large budget relative to vehicle selection), the solver finds **multiple EQUALLY GOOD solutions**
- When a vehicle is removed, the solver substitutes with another vehicle that achieves the **SAME objective score**
- Therefore: marginal contribution = baseline_score - new_score = 0 for ALL vehicles

### Example
- **Baseline fleet:** V01, V04, V08 (cost = 1.43, env = 1.21)
- **Remove V01:** Solver picks V02, V05, V07 (cost = 1.43, env = 1.21) ← IDENTICAL!
- **Marginal of V01:** 1.43 - 1.43 = 0.0

This is mathematically correct but unhelpful for fleet optimization.

## Solution
**Tighten the budget constraint** to force a unique optimal solution where vehicle removal DOES degrade performance.

### Budget Guide for 10-Vehicle Fleet

| Fleet Size | Feasible Budget | Marginals Status |
|-----------|-----------------|------------------|
| 2 vehicles | ₹2.3-2.6M | ✓ Non-zero |
| 3 vehicles | ₹3.3-3.8M | ✓ Non-zero |
| 5 vehicles | ₹5.5-6.5M | ✓ Non-zero |
| 10 vehicles | ₹11M+ | ✗ All zero (degenerate) |

### Implementation in app_custom.py
- **New default budget:** `3.0 × avg_vehicle_cost` ≈ ₹3.66M for fleet_sample.csv
- **This selects ~3 vehicles** with **tight constraints** → meaningful marginals
- **Budget Info section** now explains the relationship
- **Error handling** improved to explain infeasibility reasons

### Error Handling Improvements
When budget is too tight and solver fails, user now sees:
```
No optimal solution found (termination: infeasible). 
Problem may be infeasible with current constraints. Try:
1. Increase budget (currently ₹2,000,000)
2. Reduce min_fleet_size (currently 3)
3. Relax other constraints
```

## How Marginals Work
With **tight budget**, removing a selected vehicle:
1. Forces solver to pick from remaining vehicles
2. New solution has **worse** objective value (can't fit same performance in tighter constraint)
3. marginal = degradation → meaningful signal about vehicle importance

## Files Modified
1. **core/optimize.py** - Added solver status checks and helpful error messages
2. **app_custom.py** - Updated budget default (3.0× avg cost) and added explanation

## Testing
- ✓ ₹3.66M budget: Successfully selects 3 vehicles with meaningful marginals
- ✓ ₹2.6M budget: Shows non-zero marginals for 2-vehicle fleet
- ✓ Error handling: Clear messages when infeasible

## User Action Required
**Try the updated app now!** Default budget is now ₹3.66M which should:
1. ✓ Run optimization successfully (will solve in <1 second)
2. ✓ Run MC with 50 scenarios (will take ~18-20 seconds)
3. ✓ Display meaningful RPI values (not all 0s)
4. ✓ Show diversity in Volatility across vehicles
