# Comprehensive Fleet Data Template for HOSF

## CSV Column Requirements

Your fleet CSV should include all relevant columns from these categories:

### Required Identifiers
- `vehicle_id` (string): Unique vehicle identifier (e.g., "VH001", "TRUCK_42")

### Economic Objective Variables
- `fuel_cost_per_km` (float): Annual fuel cost per kilometer (₹/km)
- `maintenance_cost_per_year` (float): Annual maintenance cost (₹/year)
- `capex_ev` (float): Capital cost for EV conversion (₹)
- `downtime_cost_per_day` (float): Cost of vehicle unavailability (₹/day)

### Environmental Objective Variables
- `co2_emission_gpkm` (float): CO2 emissions (grams per km)
- `pollutants_index` (float): Air pollutant index (0-1 scale or custom)
- `compliance_liability` (float): Regulatory non-compliance risk (₹ or 0-1 scale)

### Operational Objective Variables
- `utilization_percent` (float): Vehicle utilization rate (0-100 percent)
- `service_criticality` (float): Importance to operations (0-30 or 0-1 scale)
- `downtime_hours_annual` (float): Expected downtime hours per year

### Asset Health Objective Variables
- `vehicle_age` (float): Years in service
- `remaining_useful_life` (float): Estimated RUL in years
- `reliability_score` (float): Reliability rating (0-1 or 0-100 scale)

### Infrastructure Readiness Variables
- `charging_availability` (float): Charging infrastructure availability (0-1)
- `grid_dependency` (float): Dependency on grid (0-1, where 0=independent)

### Risk Mitigation Variables
- `fuel_price_volatility` (float): Historical fuel price volatility (0-1 or percent)
- `policy_stability_score` (float): Policy environment stability (0-1)

### Policy Control Variables
- `mandatory_replacement` (binary): 1 if vehicle must be replaced, 0 otherwise
- `policy_mandate_level` (float): Compliance mandate strength (0-1)

---

## Example CSV (Minimal Valid Format)

```csv
vehicle_id,fuel_cost_per_km,maintenance_cost_per_year,capex_ev,downtime_cost_per_day,co2_emission_gpkm,pollutants_index,compliance_liability,utilization_percent,service_criticality,downtime_hours_annual,vehicle_age,remaining_useful_life,reliability_score,charging_availability,grid_dependency,fuel_price_volatility,policy_stability_score,mandatory_replacement,policy_mandate_level
VH001,25.5,150000,500000,5000,450,0.6,10000,85,15,120,8,3,0.7,0.9,0.2,0.15,0.8,0,0
VH002,22.0,120000,450000,4000,380,0.5,8000,90,20,80,5,7,0.85,0.95,0.1,0.12,0.85,0,0
VH003,35.0,200000,600000,8000,520,0.7,15000,70,10,200,12,1,0.5,0.5,0.8,0.25,0.6,1,1
...
```

---

## How HOSF Handles Multiple Variables

### 1. Automatic Normalization
Each variable is normalized to [0, 1] independently:
```
normalized_value = (value - min) / (max - min)
```

This ensures:
- Variables with different scales don't dominate
- A fuel cost of ₹50/km has same weight as a CO2 of 500 g/km (if both objectives equally weighted)

### 2. Objective Aggregation
Multiple variables within an objective are automatically aggregated:
```
Economic_Score = mean(fuel_cost_per_km, maintenance_cost_per_year, capex_ev, downtime_cost_per_day)
Environmental_Score = mean(co2_emission_gpkm, pollutants_index, compliance_liability)
...
```

### 3. Dynamic Weighting
You control the importance of each objective via sliders:
- Economic: 50%
- Environmental: 30%
- Operational: 15%
- Asset_Health: 5%
- etc.

**Projected_RPI = Σ_k w_k × normalized_score_k**

### 4. Scenario-Based Robustness
Monte Carlo adds realistic uncertainty:
```
For each scenario s:
  - Perturb each variable (e.g., fuel cost ±20%)
  - Recompute rankings
  - Measure volatility: std(ranking_across_scenarios)
```

---

## Adding Custom Variables

### Step 1: Add Column to CSV
Include any new variable in your data (e.g., `battery_cost_per_kwh`)

### Step 2: Add to Objectives Dictionary
Edit `core/objectives_extended.py`:

```python
"Economic_TCO": {
    "variables": [
        "fuel_cost_per_km",
        "maintenance_cost_per_year",
        "capex_ev",
        "downtime_cost_per_day",
        "battery_cost_per_kwh"  # New!
    ],
    "display_name": "Total Cost of Ownership",
}
```

### Step 3: Run
No code changes needed! System automatically:
- Loads the new column
- Normalizes it
- Includes it in objective computation
- Shows in visualizations

---

## Data Validation Checklist

Before uploading CSV:

- [ ] All columns use correct names (snake_case, lowercase)
- [ ] No missing values (fill with 0 or mean if appropriate)
- [ ] Numeric values only (no text in data columns)
- [ ] vehicle_id is unique
- [ ] Reasonable value ranges:
  - Percentages: 0-100
  - Scores: 0-1
  - Costs: non-negative
  - Age: non-negative integers

---

## Policy as Control Instruments

HOSF supports policy controls through:

### Hard Constraints (Must be included)
```python
# In feasibility_config
feasibility = {
    "budget": 50_000_000,  # Hard budget limit
    "min_service_level": 8,  # Must serve critical vehicles
    "max_charging_load": 50,  # Infrastructure capacity
    "mandatory_replacement": [vehicles_with_1]  # Auto-included
}
```

### Soft Objectives (Weighted preference)
```python
# In OBJECTIVES
"Policy_Alignment": {
    "variables": [
        "policy_mandate_level",
        "compliance_liability"
    ]
}
```

### Policy State Encoding
You can encode temporal/regional policy variations:
```csv
vehicle_id,policy_state,regional_incentive,temporal_period
VH001,2025_Q1,high_incentive,early_adopter
VH002,2025_Q2,medium_incentive,standard
VH003,2026_Q1,low_incentive,late_stage
```

Then add these as objectives or constraints.

---

## Example: Complete Fleet Assessment

### Scenario
Fleet of 50 buses across 3 regions
- Region A: High charging infrastructure (0.9), stable policy (0.85)
- Region B: Medium charging (0.6), volatile policy (0.5)
- Region C: Low charging (0.2), uncertain policy (0.3)

### CSV Structure
```csv
vehicle_id,region,location_charging_availability,location_policy_stability,
fuel_cost_per_km,maintenance_cost_per_year,co2_emission_gpkm,...
BUS_A001,A,0.9,0.85,25,150000,450,...
BUS_A002,A,0.9,0.85,26,155000,460,...
...
BUS_B001,B,0.6,0.5,22,120000,380,...
...
BUS_C001,C,0.2,0.3,20,100000,350,...
```

### HOSF Analysis
Run with different weights:
- **Scenario 1** (Environmental): High weight on emissions → prefer BUS_B, BUS_C (newer, cleaner)
- **Scenario 2** (Infrastructure-Ready): High weight on charging → prefer BUS_A (best infrastructure)
- **Scenario 3** (Economic): High weight on costs → prefer BUS_C (lowest cost, but risky due to policy)

See how rankings shift → understand trade-offs

---

## Tips for Data Quality

1. **Scale variables appropriately**
   - Don't mix ₹ (50M) with percentages (85%)
   - HOSF normalizes, but makes sense to pre-normalize for interpretability

2. **Handle missing data**
   - Fill with mean/median of column, or
   - Use 0 if "not applicable", or
   - Drop row if too many missing values

3. **Outliers**
   - Check for unrealistic values (e.g., age = 999)
   - Consider capping or log-transforming extreme values

4. **Temporal data**
   - Include period/region columns
   - Can add as objectives or constraints

5. **Validation**
   - Sum should equal 100% for percentages
   - Costs should be non-negative
   - Age should be <lifecycle

---

## Questions?

For custom variables or domain-specific scenarios, refer to:
- `ARCHITECTURE.md` — Technical details
- `core/objectives_extended.py` — Objective definitions
- `core/data.py` — Data processing logic
