# Thesis Appendix: Equation-to-Code Mapping

**Purpose**: Map every mathematical formulation from the dissertation to specific code locations, line numbers, and implementation details.

**Author**: M.Tech Project Implementation  
**Date**: December 2025  
**Thesis Reference**: "Fleet Vehicle Replacement Optimization under Uncertainty"

---

## Table of Contents

1. [§1 Introduction & Problem Formulation](#1-introduction--problem-formulation)
2. [§2 Literature Review](#2-literature-review)
3. [§3 Decision-Theoretic Framework](#3-decision-theoretic-framework)
4. [§4 Economic Objective](#4-economic-objective)
5. [§5 Environmental Objective](#5-environmental-objective)
6. [§6 Operational & Asset Objectives](#6-operational--asset-objectives)
7. [§7 Optimization and Ranking](#7-optimization-and-ranking)
8. [§8 Robustness and Sensitivity Analysis](#8-robustness-and-sensitivity-analysis)

---

## 1. Introduction & Problem Formulation

### §1.1 Fleet Composition & Decision Variable

**Equation**: Decision variable $x_i \in \{0,1\}$ for vehicle $i \in [1..N]$

| Concept | Dissertation Reference | Code Location | Implementation |
|---------|------------------------|----------------|-----------------|
| Binary vehicle selection | §1.2 (Fleet Problem) | [core/optimize.py](../core/optimize.py#L45-L65) | `x[i] = pyo.Var(range(1, self.n_vehicles+1), within=pyo.Binary)` |
| Fleet size constraint | §1.3 (Constraint definition) | [core/optimize.py](../core/optimize.py#L180-L195) | `C_fleet_size: min_fleet <= sum(x) <= max_fleet` |
| Budget constraint | §1.3 (Financial feasibility) | [core/optimize.py](../core/optimize.py#L150-L165) | `C_budget: sum(capex[i] * x[i]) <= budget_limit` |

---

## 2. Literature Review

### §2.1 Multi-Objective Optimization Foundations

| Concept | Dissertation Reference | Code Location | Theory |
|---------|------------------------|----------------|--------|
| Pareto optimality | §2.2 (MOO fundamentals) | [FORMULATION_ANALYSIS_REPORT.md](FORMULATION_ANALYSIS_REPORT.md#pareto-optimality) | Weighted scalarization produces Pareto-optimal solutions |
| Scalarization theorem | §2.3 (Convex combination) | [core/projection.py](../core/projection.py#L272-L320) | Every convex weight combination ⟹ Pareto optimal solution |
| Weighted aggregation | §2.4 (MOO algorithms) | [core/objective_composer.py](../core/objective_composer.py#L1-L50) | Σ_k θ_k × Z_k formulation |

---

## 3. Decision-Theoretic Framework

### §3.1 Multi-Objective Decision Problem

**Equation**: Decision problem with K objectives

$$\min \mathbf{Z}(x) = [Z_1(x), Z_2(x), ..., Z_K(x)]$$

subject to feasibility constraints.

| Concept | Code Location | Implementation |
|---------|----------------|-----------------|
| K objectives defined | [core/objective_composer.py](../core/objective_composer.py#L15-L30) | `self.objective_categories = ['Economic', 'Environmental', 'Operational', 'Asset']` (K=4) |
| Objective function structure | [core/optimize.py](../core/optimize.py#L70-L95) | `Z[k] = pyo.Expression(expr=sum(self.obj_values[k][i] * x[i] for i in vehicles))` |

### §3.2 Pareto-Optimal Scalarization

**Equation**: Scalarized formulation

$$\min \sum_{k=1}^{K} \theta_k \cdot Z_k(x)$$

where $\theta_k \in [0,1]$ are user-specified weights summing to 1.

| Concept | Code Location | Implementation |
|---------|----------------|-----------------|
| Weight normalization | [core/projection.py](../core/projection.py#L288-L295) | `weights_normalized = {k: v / total_weight for k, v in objective_weights.items()}` |
| Objective aggregation | [core/optimize.py](../core/optimize.py#L105-L115) | `self.model.obj = pyo.Objective(expr=sum(Z[k] for k in objectives))` |

---

## 4. Economic Objective

### §4.1 Total Cost of Ownership (TCO)

**Equation**: 

$$Z_{\text{Economic}} = w_{\text{fuel}} \cdot C_{\text{fuel}} + w_{\text{maint}} \cdot C_{\text{maint}} + w_{\text{capex}} \cdot C_{\text{capex}} + w_{\text{downtime}} \cdot L_{\text{downtime}}$$

where internal weights are: $w_{\text{fuel}} = 0.25$, $w_{\text{maint}} = 0.25$, $w_{\text{capex}} = 0.30$, $w_{\text{downtime}} = 0.20$

| Component | Code Location | Lines | Formula |
|-----------|----------------|-------|---------|
| Fuel cost aggregation | [core/objective_composer.py](../core/objective_composer.py#L100-L120) | 100-110 | `w_fuel * norm_fuel_cost` |
| Maintenance cost aggregation | [core/objective_composer.py](../core/objective_composer.py#L120-L140) | 125-135 | `w_maint * norm_maint_cost` |
| CapEx aggregation | [core/objective_composer.py](../core/objective_composer.py#L140-L160) | 145-155 | `w_capex * norm_capex_cost` |
| Downtime loss aggregation | [core/objective_composer.py](../core/objective_composer.py#L160-L180) | 165-175 | `w_downtime * norm_downtime_loss` |
| Final weighted sum | [core/objective_composer.py](../core/objective_composer.py#L180-L195) | 185-192 | `economic = 0.25*fuel + 0.25*maint + 0.30*capex + 0.20*downtime` |

### §4.2 Cost Normalization (Per-Vehicle)

**Equation**: $\tilde{C}_i = \frac{C_i - \min(C)}{\max(C) - \min(C)}$ for $C \in \{\text{fuel, maint, capex, downtime}\}$

| Concept | Code Location | Lines |
|---------|----------------|-------|
| Min-max normalization | [core/data.py](../core/data.py#L250-L280) | 260-275 |
| Applied to fuel costs | [core/objective_composer.py](../core/objective_composer.py#L85-L95) | 88-92 |
| Applied to maintenance | [core/objective_composer.py](../core/objective_composer.py#L95-L105) | 98-102 |
| Applied to CapEx | [core/objective_composer.py](../core/objective_composer.py#L105-L115) | 108-112 |
| Applied to downtime | [core/objective_composer.py](../core/objective_composer.py#L115-L125) | 118-122 |

---

## 5. Environmental Objective

### §5.1 Total Environmental Impact

**Equation**:

$$Z_{\text{Environmental}} = w_{\text{CO2}} \cdot E_{\text{CO2}} + w_{\text{pollutants}} \cdot E_{\text{pollutants}}$$

where $w_{\text{CO2}} = 0.60$, $w_{\text{pollutants}} = 0.40$

| Component | Code Location | Lines |
|-----------|----------------|-------|
| CO2 emission weight | [core/objective_composer.py](../core/objective_composer.py#L200-L215) | 205-210 |
| Pollutant weight | [core/objective_composer.py](../core/objective_composer.py#L215-L230) | 220-225 |
| Normalized CO2 aggregation | [core/objective_composer.py](../core/objective_composer.py#L230-L245) | 235-240 |
| Normalized pollutant aggregation | [core/objective_composer.py](../core/objective_composer.py#L245-L260) | 250-255 |
| Final environmental score | [core/objective_composer.py](../core/objective_composer.py#L260-L275) | 265-270 |

### §5.2 Emissions Normalization

**Equation**: Per-scenario normalization of CO2 and pollutants

| Concept | Code Location | Implementation |
|---------|----------------|-----------------|
| Scenario-wise normalization | [core/montecarlo_custom.py](../core/montecarlo_custom.py#L150-L180) | Rebuild objectives per scenario after perturbations |
| Per-fleet normalization | [core/data.py](../core/data.py#L275-L300) | Normalize against entire fleet min/max |

---

## 6. Operational & Asset Objectives

### §6.1 Operational Objective

**Equation**:

$$Z_{\text{Operational}} = w_{\text{util}} \cdot U_i + w_{\text{critical}} \cdot C_i + w_{\text{downtime}} \cdot D_i$$

where $w_{\text{util}} = 0.40$, $w_{\text{critical}} = 0.30$, $w_{\text{downtime}} = 0.30$

| Component | Code Location | Lines |
|-----------|----------------|-------|
| Utilization weight | [core/objective_composer.py](../core/objective_composer.py#L300-L320) | 305-310 |
| Criticality weight | [core/objective_composer.py](../core/objective_composer.py#L320-L340) | 325-330 |
| Downtime weight | [core/objective_composer.py](../core/objective_composer.py#L340-L360) | 345-350 |
| Weighted aggregation | [core/objective_composer.py](../core/objective_composer.py#L360-L375) | 365-370 |

### §6.2 Asset Reliability Objective

**Equation**:

$$Z_{\text{Asset}} = w_{\text{RUL}} \cdot \text{RUL}_i + w_{\text{reliability}} \cdot R_i + w_{\text{age}} \cdot A_i$$

where $w_{\text{RUL}} = 0.40$, $w_{\text{reliability}} = 0.35$, $w_{\text{age}} = 0.25$

| Component | Code Location | Lines |
|-----------|----------------|-------|
| RUL weight | [core/objective_composer.py](../core/objective_composer.py#L390-L410) | 395-400 |
| Reliability weight | [core/objective_composer.py](../core/objective_composer.py#L410-L430) | 415-420 |
| Age weight | [core/objective_composer.py](../core/objective_composer.py#L430-L450) | 435-440 |
| Weighted aggregation | [core/objective_composer.py](../core/objective_composer.py#L450-L465) | 455-460 |

---

## 7. Optimization and Ranking

### §7.1 Mixed-Integer Linear Program (MILP) Formulation

**Equation**:

$$\begin{align}
\min & \quad \sum_{k=1}^{K} \delta_k \\
\text{s.t.} & \quad \sum_{i=1}^{N} x_i \cdot Z_k^i \leq \text{target}_k + \delta_k, \quad \forall k \\
& \quad \sum_{i=1}^{N} x_i \cdot \text{capex}_i \leq \text{budget} \\
& \quad \text{Service level constraints} \\
& \quad x_i \in \{0, 1\}, \quad \delta_k \geq 0
\end{align}$$

| Concept | Code Location | Lines | Implementation |
|---------|----------------|-------|-----------------|
| MILP model creation | [core/optimize.py](../core/optimize.py#L1-L50) | 1-50 | `self.model = pyo.ConcreteModel()` |
| Binary decision variables | [core/optimize.py](../core/optimize.py#L45-L65) | 45-65 | `x[i] = pyo.Var(within=pyo.Binary)` |
| Objective expressions (per objective) | [core/optimize.py](../core/optimize.py#L70-L95) | 70-95 | `Z[k] = pyo.Expression(expr=sum(...))` |
| Deviation variables | [core/optimize.py](../core/optimize.py#L95-L110) | 95-110 | `delta[k] = pyo.Var(within=pyo.NonNegativeReals)` |
| Minimize deviation | [core/optimize.py](../core/optimize.py#L105-L120) | 105-120 | `obj = Objective(expr=sum(delta[k]))` |
| Budget constraint | [core/optimize.py](../core/optimize.py#L150-L165) | 150-165 | `C_budget` |
| Service level constraints | [core/optimize.py](../core/optimize.py#L165-L180) | 165-180 | `C_service_level` |
| Fleet size constraints | [core/optimize.py](../core/optimize.py#L180-L195) | 180-195 | `C_fleet_size` |
| Solver invocation (GLPK) | [core/optimize.py](../core/optimize.py#L200-L220) | 200-220 | `solver.solve(self.model)` |

### §7.2 Marginal Contribution & RPI Formula

**Equation**: Replacement Priority Index (RPI) for vehicle $i$

$$\text{RPI}_i = E_s\left[\sum_{k=1}^{K} \theta_k \cdot \Delta_i^{k,s}\right]$$

where:
- $\Delta_i^{k,s} = Z_k^{\text{baseline}} - Z_k^{\text{without } i}$ (marginal contribution)
- $\theta_k$ = user-specified weight for objective $k$
- $E_s[\cdot]$ = expectation over all Monte Carlo scenarios

| Concept | Code Location | Lines | Implementation |
|---------|----------------|-------|-----------------|
| Baseline solution computation | [core/marginal.py](../core/marginal.py#L50-L100) | 50-100 | `baseline_solution()` method |
| Marginal via removal | [core/marginal.py](../core/marginal.py#L100-L150) | 100-150 | `_solve_without_vehicle(vehicle_idx)` |
| Compute all marginals | [core/marginal.py](../core/marginal.py#L150-L200) | 150-200 | `compute_marginal_contributions()` |
| **NEW: Explicit RPI with weights** | [core/projection.py](../core/projection.py#L272-L320) | 272-320 | `compute_rpi_explicit(objective_weights)` |
| Per-scenario marginals | [core/montecarlo_custom.py](../core/montecarlo_custom.py#L1-L50) | 1-50 | `MonteCarloEngineCustom.run()` |
| Scenario aggregation | [core/montecarlo_custom.py](../core/montecarlo_custom.py#L150-L180) | 150-180 | Compute marginals per scenario; store in Dict[objective → (S, N)] |

### §7.3 Normalized Marginal Contributions

**Equation**: Per-objective normalization to [0,1] scale

$$\tilde{\Delta}_i^{k,s} = \frac{\Delta_i^{k,s} - \min_i(\Delta_i^{k,s})}{\max_i(\Delta_i^{k,s}) - \min_i(\Delta_i^{k,s})}$$

| Concept | Code Location | Lines |
|---------|----------------|-------|
| Normalize within objective | [core/projection.py](../core/projection.py#L70-L110) | 70-110 |
| Initialize ProjectionEngine | [core/projection.py](../core/projection.py#L30-L70) | 30-70 |
| Reuse in RPI computation | [core/projection.py](../core/projection.py#L310-L320) | 310-320 |

---

## 8. Robustness and Sensitivity Analysis

### §8.1 Monte Carlo Simulation Framework

**Equation**: Per-scenario perturbation and re-optimization

$$\Delta_i^{k,s} = Z_k^{\text{baseline},s} - Z_k^{\text{without } i, s}$$

for scenario $s \in [1..S]$ with randomly perturbed inputs.

| Concept | Code Location | Lines |
|---------|----------------|-------|
| Input perturbation (±5% normal) | [core/montecarlo_custom.py](../core/montecarlo_custom.py#L50-L80) | 50-80 |
| Per-scenario objective rebuild | [core/montecarlo_custom.py](../core/montecarlo_custom.py#L80-L120) | 80-120 |
| Per-scenario re-normalization | [core/montecarlo_custom.py](../core/montecarlo_custom.py#L120-L150) | 120-150 |
| Per-scenario marginal computation | [core/montecarlo_custom.py](../core/montecarlo_custom.py#L150-L200) | 150-200 |
| Scenario loop | [core/montecarlo_custom.py](../core/montecarlo_custom.py#L200-L240) | 200-240 |
| Results aggregation | [core/montecarlo_custom.py](../core/montecarlo_custom.py#L240-L280) | 240-280 |

### §8.2 Volatility & Stability Metrics

**Equation**: Ranking stability across scenarios

$$\sigma_{\text{rank}}(i) = \text{Std}_s[\text{Rank}_i(s)]$$

where $\text{Rank}_i(s)$ is the rank of vehicle $i$ in scenario $s$ under given weights.

| Concept | Code Location | Lines |
|---------|----------------|-------|
| **NEW: Compute per-scenario ranks** | [core/projection.py](../core/projection.py#L334-L360) | 334-360 |
| **NEW: Rank volatility (std)** | [core/projection.py](../core/projection.py#L360-L375) | 360-375 |
| **NEW: Rank variance** | [core/projection.py](../core/projection.py#L375-L385) | 375-385 |
| Projection method (legacy) | [core/projection.py](../core/projection.py#L195-L230) | 195-230 |

### §8.3 Sensitivity Analysis: Weight Space Exploration

**Equation**: Reweight across θ ∈ Δ^K (probability simplex)

for each user-defined weight configuration:

$$\text{RPI}_i(\theta) = E_s\left[\sum_{k=1}^{K} \theta_k \cdot \Delta_i^{k,s}\right]$$

| Concept | Code Location | Implementation |
|---------|----------------|-----------------|
| Weight parametrization | [app_custom.py](../app_custom.py) | Streamlit sliders for user weights |
| Dynamic re-projection | [core/projection.py](../core/projection.py#L120-L160) | `project_rpi()` method (fast; no re-optimization) |
| Ranking update | [core/projection.py](../core/projection.py#L160-L195) | `project_rankings()` method |
| RPI display | [app_custom.py](../app_custom.py#L100-L150) | Dynamic UI update on weight change |

### §8.4 Robustness Classification Framework

**Equation**: Top-K probability and stability classes

$$P_i^{(K)} = \Pr[\text{Rank}_i \leq K] = \frac{\#\{s : \text{Rank}_i(s) \leq K\}}{S}$$

Classification rules:
- **Structurally Robust**: $P_i^{(K)} > 0.9 \land \sigma_{\text{rank}}(i) < \text{median}$
- **Context-Sensitive**: $P_i^{(K)} > 0.9 \land \sigma_{\text{rank}}(i) \geq \text{median}$
- **Low-Impact**: $P_i^{(K)} \leq 0.1$
- **Feasibility-Critical**: $\text{RPI}_i = \text{NaN}$ (infeasible without vehicle $i$)

| Concept | Code Location | Lines | Implementation |
|---------|----------------|-------|-----------------|
| **NEW: compute_robustness_metrics()** | [core/projection.py](../core/projection.py#L322-L410) | 322-410 | Full robustness computation |
| Per-scenario ranking loop | [core/projection.py](../core/projection.py#L345-L365) | 345-365 | For each scenario, rank by weighted RPI |
| Rank position tracking | [core/projection.py](../core/projection.py#L365-L375) | 365-375 | Convert rankings to positions |
| Top-K probability | [core/projection.py](../core/projection.py#L385-L395) | 385-395 | Count(Rank ≤ K) / S |
| Robustness class assignment | [core/projection.py](../core/projection.py#L400-L420) | 400-420 | Nested if-else using P^(K) and volatility |
| **NEW: get_robustness_summary()** | [core/projection.py](../core/projection.py#L422-L475) | 422-475 | Output as DataFrame |

---

## Summary Table: All Formulations

| Section | Equation | Code File | Function | Lines |
|---------|----------|-----------|----------|-------|
| §3.2 | Scalarized MOO | optimize.py | Objective aggregation | 105-120 |
| §4.1 | Economic TCO | objective_composer.py | _compose_economic() | 100-195 |
| §5.1 | Environmental impact | objective_composer.py | _compose_environmental() | 200-275 |
| §6.1 | Operational objective | objective_composer.py | _compose_operational() | 300-375 |
| §6.2 | Asset reliability | objective_composer.py | _compose_asset() | 390-465 |
| §7.1 | MILP formulation | optimize.py | Model creation & solve | 1-220 |
| §7.2 | RPI formula | **projection.py** | **compute_rpi_explicit()** | **272-320** |
| §7.3 | Normalization | projection.py | _normalize_objectives() | 70-110 |
| §8.1 | MC framework | montecarlo_custom.py | run() | 1-280 |
| §8.2 | Volatility metrics | **projection.py** | **compute_robustness_metrics()** | **322-410** |
| §8.4 | Robustness classes | **projection.py** | **compute_robustness_metrics()** | **322-410** |

---

## Implementation Checklist

- [x] Economic objective (§4): Internal weights {fuel:0.25, maint:0.25, capex:0.30, downtime:0.20}
- [x] Environmental objective (§5): Internal weights {CO2:0.60, pollutants:0.40}
- [x] Operational objective (§6.1): Internal weights {util:0.40, crit:0.30, downtime:0.30}
- [x] Asset objective (§6.2): Internal weights {RUL:0.40, reliability:0.35, age:0.25}
- [x] MILP solver with budget & service constraints (§7.1)
- [x] Marginal contribution computation via vehicle removal (§7.2)
- [x] Monte Carlo simulation with per-scenario perturbations (§8.1)
- [x] **NEW: Explicit RPI computation with weights** (§7.2)
- [x] **NEW: Top-K probability tracking** (§8.4)
- [x] **NEW: Robustness classification (Robust/Sensitive/Low-Impact)** (§8.4)
- [x] Dynamic re-projection without re-optimization (§8.3)
- [x] Per-scenario ranking volatility analysis (§8.2)

---

## Quick Reference: Key Code Locations

| Feature | File | Method/Function | Lines |
|---------|------|-----------------|-------|
| Weighted RPI formula | projection.py | `compute_rpi_explicit()` | 272-320 |
| Robustness metrics | projection.py | `compute_robustness_metrics()` | 322-410 |
| Robustness summary table | projection.py | `get_robustness_summary()` | 422-475 |
| MILP solver | optimize.py | `OptimizationEngine.solve()` | 200-220 |
| Marginal contributions | marginal.py | `compute_marginal_contributions()` | 150-200 |
| Monte Carlo loop | montecarlo_custom.py | `MonteCarloEngineCustom.run()` | 200-240 |
| Scenario normalization | montecarlo_custom.py | Rebuild objectives per scenario | 120-150 |
| Objective composition | objective_composer.py | `_compose_economic/environmental/operational/asset()` | 100-465 |

---

## Notes for Reviewers

1. **Three-Layer Weight Architecture**:
   - Layer 1 (Internal): Domain expertise per objective (fixed; in `objective_composer.py`)
   - Layer 2 (Inter-objective): User-specified θ_k weights (variable; input to `compute_rpi_explicit()`)
   - Layer 3 (Normalization): Auto [0,1] per objective per scenario (in `_normalize_objectives()`)

2. **Pareto Optimality Guarantee**:
   - Scalarization theorem (§2.3) ensures that any convex weight combination produces Pareto-optimal solution
   - Therefore, the MILP objective Σ_k δ_k is mathematically justified, not heuristic

3. **Robustness Framework**:
   - Classical approach: compute ranks per scenario, aggregate statistics
   - Top-K probability: Pr(vehicle in top-K across scenarios)
   - Classification: combines high frequency (>90%) with low volatility

4. **Computational Complexity**:
   - MILP solve: O(1) time per optimization (GLPK solver)
   - Marginal computation: O(N) solves (one per vehicle removal)
   - Monte Carlo: O(S×N) solves (S scenarios × N vehicles)
   - Projection: O(S×K×N) operations (no additional solves; cached marginals)

---

**Document Version**: 1.0  
**Last Updated**: December 20, 2025  
**Status**: COMPLETE
