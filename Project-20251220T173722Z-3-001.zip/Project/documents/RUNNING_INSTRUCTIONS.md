# Running HOSF — Step by Step

## 🚀 First Time Setup (5 minutes)

### Step 1: Open Terminal
```bash
cd "g:\My Drive\M.Tech-Project\Project"
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

**What gets installed**:
- streamlit (UI framework)
- pyomo (optimization modeling)
- glpk (solver)
- pandas, numpy (data processing)
- plotly (charts)

**Time**: 2-3 minutes (first time only)

### Step 3: Start the App
```bash
streamlit run app_refactored.py
```

**Expected output**:
```
  You can now view your Streamlit app in your browser.

  Local URL: http://localhost:8501
  Network URL: http://192.168.x.x:8501
```

**Browser opens automatically** → navigate to `http://localhost:8501`

---

## 📖 Running the System

### 🔴 RED TAB: Computation Mode

**Purpose**: Run expensive optimization + Monte Carlo (do this once, then reuse)

**Steps**:

1. **Upload Fleet Data**
   - Click "Browse files"
   - Select `fleet_sample.csv` (or your fleet CSV)
   - System validates columns automatically

2. **Configure Objectives** (Sidebar)
   ```
   ☑ Economic (weight: 0.5)
   ☑ Environmental (weight: 0.3)
   ☑ Service (weight: 0.2)
   ☐ Reliability
   ```
   - Check/uncheck objectives
   - Adjust weight sliders
   - Weights auto-normalize

3. **Set Constraints** (Sidebar)
   ```
   Total Budget: ₹10,000,000
   Min Service Level: 8.0
   Max Charging Capacity: 50
   ```

4. **Run Computation**
   - Click purple button: "▶️ RUN OPTIMIZATION & MONTE CARLO"
   - See progress:
     ```
     ⏳ Running optimization...
     ✓ Optimization done in 2.34s
     ⏳ Running Monte Carlo (50 scenarios)...
     ✓ Monte Carlo done in 23.45s
     ✅ All computation complete!
     ```

5. **Review Results**
   - Computation time display
   - Dataset size (# vehicles)
   - Solver status
   - Ready for BLUE tab

### 🔵 BLUE TAB: Exploration Mode

**Purpose**: Interactive what-if analysis (instant updates!)

**Sub-section 1: Dynamic Ranking**
- Sliders for objective weights
- Adjust weights → rankings update instantly
- View ranking table:
  ```
  vehicle_id | rank | RPI  | Volatility | Classification
  VH001      | 1    | 0.87 | 0.12       | High-Priority Robust
  VH002      | 2    | 0.81 | 0.08       | High-Priority Robust
  ...
  ```

**Sub-section 2: Visualizations**
- **Left chart**: Top 10 vehicles by RPI (bar chart)
- **Right chart**: RPI vs Volatility (scatter plot)
  - Hover to see vehicle details
  - Color = classification

**Sub-section 3: Scenario Explorer**
- Slider: Select scenario 1-50
- Chart shows marginal values for that scenario
- Watch how rankings shift across scenarios

**Sub-section 4: Vehicle Explanation**
- Dropdown: Select any vehicle
- See:
  - Why it's ranked where it is
  - Which objectives drive its value
  - What-if scenarios (how would it rank if weights changed?)
  - Percentages for each objective

**Sub-section 5: Robustness Analysis**
- Bar chart: Ranking stability across 100 weight perturbations
- Shows which decisions are safe vs risky

**Sub-section 6: Executive Summary**
- Auto-generated narrative:
  - Fleet size
  - Critical vehicles
  - High-priority vehicles
  - Key insights
  - Implementation strategy

---

## 🎮 Interactive Workflow Example

### Scenario: "We want to prioritize environment more"

1. **In BLUE tab**, find "Economic" slider
2. Drag from 0.5 → 0.3
3. Find "Environmental" slider
4. Drag from 0.3 → 0.6
5. **Watch**: Rankings update instantly ✨
6. Notice: Some vehicles move up, others move down
7. **Why?** Because environmental attributes now have higher weight
8. Click on vehicle #3 to see breakdown
9. See: "If only Environmental mattered, you'd rank #1"

---

## ⚠️ Troubleshooting

### Issue: "Upload CSV to begin"
**Cause**: No file uploaded yet
**Solution**: Click "Browse files" and select a CSV

### Issue: "Missing required columns"
**Cause**: CSV doesn't have all required fields
**Solution**: 
- Check QUICKSTART.md for column list
- Or use provided `fleet_sample.csv`

### Issue: Charts show "No data"
**Cause**: Haven't run RED tab yet
**Solution**: Go to RED tab, click "RUN OPTIMIZATION & MONTE CARLO"

### Issue: "Solver timeout" error
**Cause**: Fleet too large for GLPK (>100 vehicles)
**Solution**: 
- Use smaller subset, or
- Upgrade to Gurobi/CPLEX solver

### Issue: App runs slow on BLUE tab
**Cause**: Old data cached, or many vehicles
**Solution**: 
- Refresh browser (Cmd+R or Ctrl+R)
- Use smaller fleet for testing

### Issue: Can't find app at localhost:8501
**Cause**: Port already in use
**Solution**: 
```bash
# Kill existing Streamlit process, or
streamlit run app_refactored.py --server.port 8502
```

---

## 📊 Sample Workflow (Start to Finish)

### Time: ~2 minutes (after setup)

```
START
  ↓
[RED TAB]
  ├─ Upload: fleet_sample.csv (✓)
  ├─ Configure: Economic 0.5, Environmental 0.3, Service 0.2 (✓)
  ├─ Constraints: Budget ₹10M, Service 8, Charging 50 (✓)
  ├─ Click: "RUN OPTIMIZATION & MONTE CARLO" (⏳ 30s)
  └─ Results: ✅ Complete!
       ↓
[BLUE TAB]
  ├─ View: Ranking table (vehicles 1-20)
  ├─ Interact: Adjust "Economic" weight 0.5 → 0.3
  │  → Rankings change instantly ✨
  ├─ Visualize: RPI vs Volatility scatter
  ├─ Explore: Select scenario 25, see different ranking
  ├─ Explain: Click "VH010", see why it's ranked #5
  │  • Fuel cost: 60%
  │  • Maintenance: 25%
  │  • Emissions: 15%
  ├─ Analyze: View "Robustness" chart
  │  → See which vehicles have stable vs risky rankings
  └─ Read: Executive summary
       ↓
DONE! Ready to present findings
```

---

## 🔄 Repeating Analysis

### Change fleet data?
1. Upload new CSV (RED tab)
2. System auto-clears old computation
3. Click "RUN" again
4. Explore with BLUE tab

### Change objectives/constraints?
1. Adjust in sidebar
2. Click "RUN" again (uses new config)
3. Explore with BLUE tab

### Same data, just explore more?
1. Go to BLUE tab
2. Adjust weights
3. No need to re-run RED tab ✨

---

## 📸 Expected UI Layout

### RED TAB
```
┌─────────────────────────────────────────┐
│ 🔴 Decision Engine Computation          │
├─────────────────────────────────────────┤
│ Description of what happens             │
├─────────────────────────────────────────┤
│ Cache Status: ...                       │
│ [▶️ RUN OPTIMIZATION & MONTE CARLO]    │
├─────────────────────────────────────────┤
│ ⏳ Running optimization...              │
│ ✓ Optimization done in 2.34s            │
│ ⏳ Running Monte Carlo (50 scenarios)... │
│ ✓ Monte Carlo done in 23.45s            │
│ ✅ All computation complete!            │
├─────────────────────────────────────────┤
│ Computation Details                     │
│ Dataset: 50 vehicles                    │
│ Opt Time: 2.34s                         │
│ MC Scenarios: 50                        │
│ MC Time: 23.45s                         │
└─────────────────────────────────────────┘
```

### BLUE TAB (Part 1 - Ranking)
```
┌─────────────────────────────────────────┐
│ 🔵 Dynamic Exploration & Projection     │
├─────────────────────────────────────────┤
│ Adjust weights in real-time:            │
│ Economic: [===●====] 0.4                │
│ Environmental: [======●===] 0.6         │
│ Service: [==●=======] 0.0               │
├─────────────────────────────────────────┤
│ Ranking Table                           │
│ vehicle_id | rank | RPI | Vol | Class  │
│ VH001      | 1    | 0.87| 0.12| High   │
│ VH002      | 2    | 0.81| 0.08| High   │
│ ...        | ...  | ... | ... | ...    │
│ [More rows, scroll to see all]          │
└─────────────────────────────────────────┘
```

### BLUE TAB (Part 2 - Visualizations & Explanations)
```
┌──────────────────────┬──────────────────┐
│ [RPI Bar Chart]      │ [Scatter: RPI    │
│ (Top 10 vehicles)    │  vs Volatility]  │
│                      │                  │
│ VH001 |██████████    │ ●●●  ●           │
│ VH002 |█████████     │   ●●●●           │
│ ...   |...           │     ●●●●●        │
└──────────────────────┴──────────────────┘

Scenario Explorer
Select: [Scenario 1 ▼] (slider to 50)
[Scenario Bar Chart - Top 15 vehicles]

Vehicle Explanation
Select: [VH010 ▼]
📊 VH010
Summary: Rank #5, High-Priority Robust, RPI: 0.75
Drivers: Fuel Cost (60%), Service (25%), Emissions (15%)
What-if:
  - If only Fuel Cost: Improves ↑ 12%
  - If only Emissions: Worsens ↓ 8%

Contribution Breakdown:
Objective | Mean | Weight | Weighted
Fuel      | 0.8  | 0.4    | 0.32
Service   | 0.6  | 0.3    | 0.18
Environ   | 0.4  | 0.3    | 0.12
```

---

## 💡 Tips for Best Results

### Tip 1: Start with defaults
- Run RED tab with default values first
- Understand baseline ranking
- Then explore variations

### Tip 2: Use BLUE tab for stakeholder demos
- Show how changing weights changes rankings
- Helps build consensus
- Everyone understands the trade-offs

### Tip 3: Look at volatility
- Low volatility = safe decision
- High volatility = risky, monitor closely
- Plan contingencies for risky vehicles

### Tip 4: Check "what-if" scenarios
- Helps explain why each vehicle ranks where it does
- Builds confidence in recommendations

### Tip 5: Export findings
- Copy ranking table to Excel
- Screenshot charts for reports
- Share executive summary

---

## 🔐 Data Privacy

⚠️ **Important**: 
- Data is processed locally (no cloud upload)
- Results not logged anywhere
- Sensitive fleet information stays on your computer
- Safe for proprietary data

---

## ❌ Common Mistakes (& How to Avoid)

### Mistake 1: "Why doesn't anything happen when I move sliders?"
- ✅ Fix: Make sure you ran RED tab first
- ✅ Check: "Cache Status" shows results available

### Mistake 2: "I changed budget but ranks didn't update"
- ✅ Fix: Budget is a constraint (affects optimization)
- ✅ Need to: Re-run RED tab to see impact

### Mistake 3: "Weights don't seem to matter"
- ✅ Note: BLUE tab reweights using cached results
- ✅ For new targets/constraints: Use RED tab

### Mistake 4: "Chart is empty or shows old data"
- ✅ Fix: Refresh browser (Ctrl+R)
- ✅ Or: Restart Streamlit (Ctrl+C, re-run command)

---

## 📞 Getting Help

### For errors or issues:
1. Check the error message (often descriptive)
2. Review QUICKSTART.md
3. Check ARCHITECTURE.md for technical details
4. See IMPLEMENTATION_CHECKLIST.md for debugging tips

### For interpretation questions:
1. Hover over charts (tooltips appear)
2. Read the vehicle explanations (why is this vehicle ranked?)
3. Review QUICKSTART.md "Understanding the Output" section

---

## 🎯 You're Ready!

1. ✅ Dependencies installed
2. ✅ App running locally
3. ✅ Data uploaded
4. ✅ Know RED vs BLUE workflow
5. ✅ Ready to explore!

**Start with RED tab → run optimization → move to BLUE tab → explore!**

Happy analyzing! 🚀
