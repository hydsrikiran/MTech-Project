#!/usr/bin/env python3
"""
HOSF with Custom Objective Builder
===================================
Allows users to define their own objectives from 18+ variables
instead of using pre-defined objectives.
"""

import streamlit as st
import pandas as pd
import numpy as np
import time
import plotly.express as px

from core.data import load_and_prepare
from core.custom_objectives import CustomObjectiveBuilder, ObjectiveTemplate
from core.variable_registry import VARIABLE_REGISTRY
from core.optimize import OptimizationEngine
from core.montecarlo_custom import MonteCarloEngineCustom
from core.projection import ProjectionEngine
from core.cache import StateCache, SessionStateManager, hash_dataframe

# ============================================================================
# PAGE CONFIG
# ============================================================================
st.set_page_config(
    page_title="HOSF — Custom Objectives",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("🔷 HOSF — Custom Objective Builder")
st.caption("Build your own objectives from 18+ variables • Patent-level decision intelligence")

# ============================================================================
# SESSION STATE
# ============================================================================
if "state_manager" not in st.session_state:
    st.session_state.state_manager = SessionStateManager(st.session_state)

state_mgr = st.session_state.state_manager

# ============================================================================
# SIDEBAR: DATA UPLOAD
# ============================================================================
with st.sidebar:
    st.subheader("📊 Data Upload")
    
    uploaded = st.file_uploader("Upload Fleet CSV", type="csv")
    
    if uploaded:
        raw_df, norm_df = load_and_prepare(uploaded)
        dataset_hash = hash_dataframe(raw_df)
        state_mgr.set_data(raw_df, norm_df, dataset_hash)
        st.success(f"✓ Loaded {len(raw_df)} vehicles, {len(raw_df.columns)} variables")
    else:
        st.info("Upload a CSV file to begin")
        st.stop()

# ============================================================================
# MAIN TABS
# ============================================================================
tab_builder, tab_compute, tab_results = st.tabs(
    ["🔧 Build Objectives", "🚀 Run Optimization", "📊 Results & Analysis"]
)

# ============================================================================
# TAB 1: OBJECTIVE BUILDER
# ============================================================================
with tab_builder:
    st.header("🔧 Custom Objective Builder")
    
    st.write("""
    Define objectives by selecting variables and assigning weights.
    Build exactly what you need - no predefined constraints.
    """)
    
    # Initialize builder
    builder = CustomObjectiveBuilder(norm_df, VARIABLE_REGISTRY)
    
    # Template selection
    st.subheader("Quick Start Templates")
    
    col_templates = st.columns(5)
    
    selected_template = None
    with col_templates[0]:
        if st.button("💰 Cost", width='stretch'):
            selected_template = "cost"
            st.session_state.selected_template = "cost"
    with col_templates[1]:
        if st.button("🌍 Environment", width='stretch'):
            selected_template = "environment"
            st.session_state.selected_template = "environment"
    with col_templates[2]:
        if st.button("🔧 Reliability", width='stretch'):
            selected_template = "reliability"
            st.session_state.selected_template = "reliability"
    with col_templates[3]:
        if st.button("⚖️ Balanced", width='stretch'):
            selected_template = "balanced"
            st.session_state.selected_template = "balanced"
    with col_templates[4]:
        if st.button("🆕 Custom", width='stretch'):
            selected_template = "custom"
            st.session_state.selected_template = "custom"
    
    # Restore from session
    if "selected_template" in st.session_state:
        selected_template = st.session_state.selected_template
    
    # Apply template
    template_config = {}
    if selected_template == "cost":
        template_config = ObjectiveTemplate.cost_focused()
        st.info("💰 Cost-focused: Acquisition + Operating costs")
    elif selected_template == "environment":
        template_config = ObjectiveTemplate.environment_focused()
        st.info("🌍 Environment-focused: Emissions + Compliance")
    elif selected_template == "reliability":
        template_config = ObjectiveTemplate.reliability_focused()
        st.info("🔧 Reliability-focused: Uptime + Durability")
    elif selected_template == "balanced":
        template_config = ObjectiveTemplate.all_balanced()
        st.info("⚖️ Balanced: All dimensions equally weighted")
    
    # Add template objectives to builder
    for obj_name, config in template_config.items():
        builder.add_objective(
            name=obj_name,
            variables=config["variables"],
            weights=config["weights"],
            normalize=False
        )
    
    # Manual editor
    st.subheader("✏️ Customize Objectives")
    
    all_variables = builder.get_available_variables()
    
    # Number of objectives
    num_objectives = st.number_input(
        "Number of objectives to define",
        min_value=1, max_value=6,
        value=max(1, len(template_config)),
        key="n_objectives"
    )
    
    # Create objective editors
    custom_configs = {}
    
    for i in range(num_objectives):
        with st.expander(f"📍 Objective {i+1}", expanded=(i == 0)):
            col1, col2 = st.columns([1, 2])
            
            # Objective name
            with col1:
                obj_name = st.text_input(
                    "Objective Name",
                    value=list(template_config.keys())[i] if i < len(template_config) else f"Objective {i+1}",
                    key=f"obj_name_{i}"
                )
            
            # Variable selection
            with col2:
                default_vars = []
                if i < len(template_config):
                    default_vars = list(template_config.values())[i]["variables"]
                
                selected_variables = st.multiselect(
                    "Select variables",
                    options=all_variables,
                    default=default_vars,
                    key=f"obj_vars_{i}",
                    help="Choose which variables to include in this objective"
                )
            
            # Weight assignment
            if selected_variables:
                st.write("**Variable Weights** (automatically normalized):")
                
                cols = st.columns(len(selected_variables))
                weights = []
                
                for col, var in zip(cols, selected_variables):
                    with col:
                        # Get default weight from template if available
                        default_weight = 1.0 / len(selected_variables)
                        if i < len(template_config):
                            template_vars = list(template_config.values())[i]["variables"]
                            template_weights = list(template_config.values())[i]["weights"]
                            if var in template_vars:
                                idx = template_vars.index(var)
                                default_weight = template_weights[idx]
                        
                        weight = st.number_input(
                            var,
                            min_value=0.0, max_value=1.0,
                            value=default_weight,
                            step=0.05,
                            label_visibility="collapsed",
                            key=f"weight_{i}_{var}"
                        )
                        weights.append(weight)
                
                # Store configuration
                if obj_name and selected_variables and weights:
                    custom_configs[obj_name] = {
                        "variables": selected_variables,
                        "weights": weights
                    }
    
    # Display summary
    st.subheader("📋 Objective Summary")
    
    all_configs = {**template_config, **custom_configs}
    
    if all_configs:
        summary_data = []
        for obj_name, config in all_configs.items():
            vars_str = ", ".join(config["variables"][:3])
            if len(config["variables"]) > 3:
                vars_str += f", +{len(config['variables'])-3}"
            summary_data.append({
                "Objective": obj_name,
                "Variables": len(config["variables"]),
                "Composition": vars_str
            })
        
        st.dataframe(summary_data, width='stretch', hide_index=True)
    else:
        st.warning("⚠️ Select a template or define custom objectives above")
        st.stop()
    
    # Build and save objectives
    if st.button("✅ Save Objectives", type="primary", width='stretch'):
        for obj_name, config in custom_configs.items():
            builder.add_objective(
                name=obj_name,
                variables=config["variables"],
                weights=config["weights"],
                normalize=True
            )
        
        # Build objectives
        objectives = builder.build()
        
        # Store in session state
        st.session_state.objectives = objectives
        st.session_state.objectives_config = builder.to_dict()
        st.session_state.builder = builder
        
        st.success(f"✅ Created {len(objectives)} objectives!")
        
        for obj_name, values in objectives.items():
            st.caption(f"{obj_name}: min={values.min():.3f}, mean={values.mean():.3f}, max={values.max():.3f}")

# ============================================================================
# TAB 2: RUN OPTIMIZATION
# ============================================================================
with tab_compute:
    st.header("🚀 Run Optimization & Analysis")
    
    if "objectives" not in st.session_state:
        st.warning("⚠️ Define objectives in the first tab first")
        st.stop()
    
    objectives = st.session_state.objectives
    builder = st.session_state.builder
    
    st.subheader("Your Objectives")
    st.write(f"**{len(objectives)} objectives defined:**")
    for obj_name in objectives.keys():
        st.caption(f"• {obj_name}")
    
    # Feasibility constraints
    st.subheader("⚙️ Feasibility Constraints")
    
    # Show vehicle capex info
    total_fleet_cost = state_mgr.st_session.raw_df["capex_ev"].sum()
    avg_vehicle_cost = state_mgr.st_session.raw_df["capex_ev"].mean()
    min_vehicle_cost = state_mgr.st_session.raw_df["capex_ev"].min()
    max_vehicle_cost = state_mgr.st_session.raw_df["capex_ev"].max()
    
    with st.expander("💰 Budget Information", expanded=False):
        col_info1, col_info2, col_info3 = st.columns(3)
        with col_info1:
            st.metric("Min Vehicle Cost", f"₹{min_vehicle_cost:,.0f}")
        with col_info2:
            st.metric("Avg Vehicle Cost", f"₹{avg_vehicle_cost:,.0f}")
        with col_info3:
            st.metric("Max Vehicle Cost", f"₹{max_vehicle_cost:,.0f}")
        
        st.info(f"**Total Fleet Cost**: ₹{total_fleet_cost:,.0f} ({len(state_mgr.st_session.raw_df)} vehicles)")
        st.write("**Tip**: To see meaningful vehicle differentiation (non-zero RPI), budget should be tight:")
        st.write("• For 2 vehicles: budget ~₹2.3-2.6M (forces hard choice)")
        st.write("• For 3 vehicles: budget ~₹3.3-3.8M (creates differentiation)")
        st.write("• For 5+ vehicles: budget ~₹5-6.5M (marginals more likely)")
        st.write("• **Loose budget** (₹12M+) = degenerate (zero marginals for all vehicles)")
    
    col1, col2, col3 = st.columns(3)
    with col1:
        # Smart default: 3.0x average vehicle cost = minimum for 3 vehicles + small cushion
        # This provides tight constraints for meaningful marginals without being infeasible
        suggested_budget = int(avg_vehicle_cost * 3.0)
        budget = st.number_input(
            "Budget (₹)", 
            value=suggested_budget,
            min_value=int(min_vehicle_cost),
            step=500_000,
            help=f"Tighter budget → meaningful RPI. Min ₹{int(min_vehicle_cost):,}, Try ₹{suggested_budget:,}-₹{int(avg_vehicle_cost*4):,}"
        )
    with col2:
        service_level = st.slider("Service Level", 0.0, 1.0, 0.95, help="Higher = more critical vehicles")
    with col3:
        charging_capacity = st.number_input("Charging Capacity", value=100, help="Total capacity across fleet")
    
    # Show how many vehicles could fit
    vehicles_per_budget = int(budget / avg_vehicle_cost)
    st.caption(f"💡 Your budget can fit approximately {vehicles_per_budget} vehicles (at average cost)")
    
    min_fleet_size = st.slider(
        "Minimum Fleet Size (vehicles to select)",
        1, len(state_mgr.st_session.raw_df), 3,
        help="Solver will select at least this many vehicles"
    )
    
    # Warn if min_fleet_size is too high for budget
    max_feasible = max(1, int(budget / avg_vehicle_cost))
    if min_fleet_size > max_feasible:
        st.warning(
            f"⚠️ **Infeasibility Risk**: Requesting {min_fleet_size} vehicles with ₹{budget:,} budget. "
            f"Budget can only support ~{max_feasible} vehicles. Reduce min_fleet_size to {max_feasible} or increase budget."
        )
    
    feasibility_config = {
        "budget": budget,
        "service_level": service_level,
        "charging_capacity": charging_capacity,
        "min_fleet_size": min_fleet_size,
    }
    
    # Run computation
    if st.button("▶️ RUN OPTIMIZATION & MONTE CARLO", type="primary", width='stretch'):
        import time
        start_time = time.time()
        
        with st.spinner("⏳ Running optimization..."):
            try:
                st.write("DEBUG: Creating optimization engine...")
                st.write(f"  - Objectives: {list(objectives.keys())}")
                st.write(f"  - Budget: ₹{feasibility_config['budget']:,}")
                st.write(f"  - Min fleet size: {feasibility_config['min_fleet_size']}")
                
                opt_engine = OptimizationEngine(
                    state_mgr.st_session.raw_df,
                    state_mgr.st_session.norm_df,
                    objectives,
                    feasibility_config
                )
                
                st.write("DEBUG: Solving optimization...")
                x_star, obj_values = opt_engine.solve()
                
                opt_time = time.time() - start_time
                st.success(f"✓ Optimization complete! ({opt_time:.1f}s)")
                
                col_opt1, col_opt2, col_opt3 = st.columns(3)
                with col_opt1:
                    st.metric("Vehicles Selected", int(sum(x_star)))
                with col_opt2:
                    st.metric("Solution Status", "Optimal")
                with col_opt3:
                    budget_used = state_mgr.st_session.raw_df.iloc[np.where(x_star)[0]]['capex_ev'].sum() if sum(x_star) > 0 else 0
                    st.metric("Budget Used", f"₹{budget_used:,.0f}")
                
                # Store in session
                st.session_state.x_star = x_star
                st.session_state.opt_values = obj_values
                
            except Exception as e:
                error_msg = str(e)
                st.error(f"❌ Optimization failed")
                st.error(error_msg)
                if "infeasible" in error_msg.lower():
                    st.info(
                        "**How to fix:**\n"
                        "1. **Increase Budget** - More money = more vehicle options\n"
                        "2. **Reduce Min Fleet Size** - Fewer vehicles needed\n"
                        "3. **Relax Other Constraints** - Lower service level or charging requirements"
                    )
                import traceback
                with st.expander("📋 Full error trace (for debugging)"):
                    st.code(traceback.format_exc())
                st.stop()
        
        with st.spinner("⏳ Running Monte Carlo (50 scenarios)..."):
            mc_start = time.time()
            try:
                st.write("DEBUG: Creating MC engine...")
                st.write("⚠️ RESEARCH-GRADE MODE: Computing full marginals via vehicle removal")
                st.write("Expected time: 30-60 seconds (all formulas + marginal computations)")
                
                mc_engine = MonteCarloEngineCustom(
                    state_mgr.st_session.raw_df,
                    state_mgr.st_session.norm_df,
                    builder,
                    feasibility_config,
                    n_scenarios=50,
                    seed=42
                )
                
                st.write("DEBUG: Running 50 scenarios with FULL SOLVER...(this will take a moment)")
                marginals = mc_engine.run()
                
                mc_time = time.time() - mc_start
                st.success(f"✓ Monte Carlo complete! ({mc_time:.1f}s)")
                
                st.write(f"DEBUG: Marginals shape: {marginals[list(marginals.keys())[0]].shape}")
                
                st.session_state.marginals = marginals
                st.session_state.vehicle_ids = state_mgr.st_session.raw_df["vehicle_id"].tolist()
                st.session_state.objectives_for_projection = objectives
                
                st.info("💡 Switch to the Results tab to explore")
                
            except Exception as e:
                st.error(f"❌ Monte Carlo failed: {str(e)}")
                import traceback
                st.write("Full error trace:")
                st.write(traceback.format_exc())

# ============================================================================
# TAB 3: RESULTS & ANALYSIS
# ============================================================================
with tab_results:
    st.header("📊 Results & Analysis")
    
    if "objectives" not in st.session_state:
        st.warning("⚠️ Run computation in the previous tab first")
        st.stop()
    
    if "marginals" not in st.session_state:
        st.warning("⚠️ No computation results yet")
        st.stop()
    
    objectives = st.session_state.objectives_for_projection
    marginals = st.session_state.marginals
    vehicle_ids = st.session_state.vehicle_ids
    x_star = st.session_state.x_star
    opt_values = st.session_state.opt_values
    
    # ====================================================================
    # SECTION 1: OPTIMAL SELECTION SUMMARY
    # ====================================================================
    st.subheader("🎯 Optimal Vehicle Selection")
    
    selected_vehicles = int(sum(x_star))
    budget_used = state_mgr.st_session.raw_df.iloc[np.where(x_star)[0]]['capex_ev'].sum() if selected_vehicles > 0 else 0
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Selected Vehicles", selected_vehicles)
    with col2:
        st.metric("Objective Count", len(objectives))
    with col3:
        st.metric("Scenarios (MC)", 50)
    with col4:
        st.metric("Variables", len(state_mgr.st_session.raw_df.columns) - 1)
    
    # ====================================================================
    # SECTION 1.5: OBJECTIVE VALUES
    # ====================================================================
    st.subheader("📈 Optimal Objective Values")
    
    obj_df = pd.DataFrame({
        "Objective": list(opt_values.keys()),
        "Value": list(opt_values.values())
    })
    
    col_chart1, col_chart2 = st.columns(2)
    
    with col_chart1:
        fig_obj = px.bar(
            obj_df,
            x="Objective",
            y="Value",
            title="Optimized Objective Values",
            labels={"Value": "Objective Value"}
        )
        st.plotly_chart(fig_obj, width='stretch')
    
    with col_chart2:
        st.write("**Objective Contributions to Optimization**")
        st.dataframe(obj_df, width='stretch', hide_index=True)
    
    # ====================================================================
    # SECTION 2: DYNAMIC RANKING WITH WEIGHT ADJUSTMENT
    # ====================================================================
    st.subheader("📊 Dynamic Ranking (Instant Updates)")
    
    st.write("**Adjust weights in real-time to see rank changes:**")
    
    col_weights = st.columns(len(objectives))
    adjusted_weights = {}
    
    for col, obj_name in zip(col_weights, objectives.keys()):
        with col:
            adjusted_weights[obj_name] = st.slider(
                obj_name,
                0.0, 1.0, 1.0/len(objectives),
                step=0.05,
                key=f"weight_{obj_name}"
            )
    
    # Normalize weights
    weight_sum = sum(adjusted_weights.values())
    if weight_sum > 0:
        adjusted_weights = {k: v/weight_sum for k, v in adjusted_weights.items()}
    
    # Projection
    try:
        projection_engine = ProjectionEngine(
            marginals,
            vehicle_ids,
            list(objectives.keys())
        )
        
        summary_df = projection_engine.get_summary_table(adjusted_weights)
        
        st.dataframe(
            summary_df[["vehicle_id", "rank", "RPI", "Volatility", "Classification"]],
            width='stretch',
            hide_index=True,
            column_config={
                "RPI": st.column_config.NumberColumn(format="%.1f", help="Ranking Preference Index (0-100)"),
                "Volatility": st.column_config.NumberColumn(format="%.1f", help="Uncertainty across scenarios (0-100)"),
            }
        )
        
        st.success("✅ Dynamic rankings updated (instant recalculation)")
        
        # ====================================================================
        # SECTION 3: VISUALIZATIONS
        # ====================================================================
        st.subheader("📈 Visualizations")
        
        col_chart1, col_chart2 = st.columns(2)
        
        with col_chart1:
            # RPI Bar Chart
            fig_rpi = px.bar(
                summary_df.head(10),
                x="vehicle_id",
                y="RPI",
                color="Classification",
                title="Top 10 Vehicles by RPI",
                labels={"RPI": "Ranking Preference Index (0-100)"}
            )
            st.plotly_chart(fig_rpi, width='stretch')
        
        with col_chart2:
            # Volatility Scatter
            fig_scatter = px.scatter(
                summary_df,
                x="RPI",
                y="Volatility",
                color="Classification",
                size="rank",
                hover_data=["vehicle_id"],
                title="RPI vs Volatility",
                labels={"RPI": "Ranking Preference Index (0-100)", "Volatility": "Uncertainty (0-100)"}
            )
            st.plotly_chart(fig_scatter, width='stretch')
        
        # Distribution charts
        col_chart3, col_chart4 = st.columns(2)
        
        with col_chart3:
            fig_rpi_dist = px.histogram(
                summary_df,
                x="RPI",
                color="Classification",
                title="RPI Distribution",
                nbins=20,
                labels={"RPI": "Ranking Preference Index (0-100)"}
            )
            st.plotly_chart(fig_rpi_dist, width='stretch')
        
        with col_chart4:
            fig_vol_dist = px.histogram(
                summary_df,
                x="Volatility",
                color="Classification",
                title="Volatility Distribution",
                nbins=20,
                labels={"Volatility": "Uncertainty (0-100)"}
            )
            st.plotly_chart(fig_vol_dist, width='stretch')
        
        # ====================================================================
        # SECTION 4: CLASSIFICATION BREAKDOWN
        # ====================================================================
        st.subheader("🏷️ Classification Breakdown")
        
        class_counts = summary_df["Classification"].value_counts().reset_index()
        class_counts.columns = ["Classification", "Count"]
        
        fig_class = px.pie(
            class_counts,
            names="Classification",
            values="Count",
            title="Vehicle Classification Distribution",
            hole=0.3
        )
        st.plotly_chart(fig_class, width='stretch')
        
        # Show selected vehicles' details
        selected_indices = np.where(x_star)[0]
        if len(selected_indices) > 0:
            st.subheader("🚗 Selected Vehicles Details")
            selected_df = summary_df[summary_df["vehicle_id"].isin(
                [vehicle_ids[i] for i in selected_indices]
            )].sort_values("rank")
            
            st.dataframe(
                selected_df[["vehicle_id", "rank", "RPI", "Volatility", "Classification"]],
                width='stretch',
                hide_index=True,
                column_config={
                    "RPI": st.column_config.NumberColumn(format="%.1f"),
                    "Volatility": st.column_config.NumberColumn(format="%.1f"),
                }
            )
        
    except Exception as e:
        st.error(f"❌ Projection failed: {str(e)}")
        import traceback
        st.write("**Debug Info:**")
        st.write(traceback.format_exc())

