"""
Objective Composition Engine (OCE)

Converts heterogeneous variables into interpretable, policy-aware objectives.
Objectives are NOT variables - they are latent constructs composed from variables.

Key Design Principles:
1. Variables ≠ Objectives
2. Objectives are policy-conditioned
3. Objective composition changes do NOT require re-optimization (cached)
4. Policies control objectives, they are not objectives themselves

Patent-Grade Contribution:
"Objectives are composed from indicator variables through a policy-conditioned 
aggregation layer, enabling dynamic preference projection without repeated optimization."
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import warnings

from core.variable_registry import (
    VARIABLE_REGISTRY,
    OBJECTIVE_CATEGORIES,
    DEFAULT_POLICY_STATE,
    get_variables_by_category,
    is_objective_variable,
)


@dataclass
class PolicyState:
    """Encapsulates policy configuration for objective composition."""
    EV_mandate: bool = False
    emission_cap_gpkm: float = 100.0
    subsidy_active: bool = False
    subsidy_fraction: float = 0.0
    carbon_tax: bool = False
    carbon_tax_per_gco2: float = 0.0
    mandatory_replacement: bool = False
    region: str = "India"
    year: int = 2025

    @classmethod
    def from_dict(cls, d: dict):
        """Create from dictionary."""
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class ObjectiveCompositionEngine:
    """
    Composes objectives from variables in a policy-aware manner.
    
    Responsibilities:
    1. Accept raw + normalized data
    2. Accept policy state
    3. Build objective expressions (weighted aggregations)
    4. Output objective values per vehicle
    5. Output objective-wise marginal contributions
    
    Key Invariant:
    - Running OCE multiple times with same data/policy → same result
    - Changing weights/policy → instant re-projection (no solver call)
    """

    def __init__(
        self,
        raw_df: pd.DataFrame,
        norm_df: pd.DataFrame,
        policy_state: Optional[Dict | PolicyState] = None,
    ):
        """
        Initialize OCE.
        
        Args:
            raw_df: Raw vehicle data (original scale)
            norm_df: Normalized vehicle data [0,1] scale
            policy_state: Policy configuration dict or PolicyState object
        """
        self.raw_df = raw_df
        self.norm_df = norm_df

        if policy_state is None:
            policy_state = DEFAULT_POLICY_STATE.copy()

        if isinstance(policy_state, dict):
            self.policy_state = PolicyState.from_dict(policy_state)
        else:
            self.policy_state = policy_state

        self.n_vehicles = len(raw_df)
        self._validate_data()
        self._objective_values = None
        self._contributions = None

    def _validate_data(self):
        """Validate that required columns exist."""
        required_cols = set(VARIABLE_REGISTRY.keys())
        available_cols = set(self.raw_df.columns)
        missing = required_cols - available_cols

        if missing:
            warnings.warn(
                f"Missing variables: {missing}. Will skip these in composition.",
                UserWarning,
            )

    def build_objectives(self) -> Dict[str, np.ndarray]:
        """
        Build all objectives by composing variables according to policy.
        
        Returns:
            Dict[objective_name → ndarray(N,)] of objective values per vehicle
            
        Examples:
            {
              "Economic": array([0.45, 0.52, ...]),
              "Environmental": array([0.30, 0.28, ...]),
              "Operational": array([0.60, 0.65, ...]),
              "Asset": array([0.50, 0.55, ...])
            }
        """
        objectives = {}

        for category in OBJECTIVE_CATEGORIES:
            obj_value = self._compose_objective(category)
            if obj_value is not None:
                objectives[category] = obj_value

        self._objective_values = objectives
        return objectives

    def apply_policy_modifiers(self) -> Dict[str, np.ndarray]:
        """
        Apply policy-driven modifications to objectives.
        
        Modifies in-place: subsidies → lower economic cost, carbon tax → higher environmental cost.
        
        Returns:
            Modified objective values (policy-conditioned)
        """
        if self._objective_values is None:
            self.build_objectives()

        modified = self._objective_values.copy()

        # ====================================================================
        # SUBSIDY RULE: Reduces effective CAPEX for EVs
        # ====================================================================
        if self.policy_state.subsidy_active and self.policy_state.subsidy_fraction > 0:
            if "capex_ev" in self.norm_df.columns:
                subsidy_reduction = self.norm_df["capex_ev"] * (
                    1 - self.policy_state.subsidy_fraction
                )
                # Recompute economic objective with reduced capex
                if "Economic" in modified:
                    economic_vars = get_variables_by_category("Economic")
                    aggregated = self._aggregate_variables(
                        ["fuel_cost_per_km", "maintenance_cost_per_year", "downtime_cost_per_day"],
                        weights=None,
                    )
                    capex_weight = 0.25  # Economic weighting
                    capex_reduced = self.norm_df["capex_ev"] * (1 - self.policy_state.subsidy_fraction)
                    modified["Economic"] = (
                        0.75 * aggregated + 0.25 * capex_reduced
                    )

        # ====================================================================
        # CARBON TAX RULE: Increases effective emission cost
        # ====================================================================
        if self.policy_state.carbon_tax and self.policy_state.carbon_tax_per_gco2 > 0:
            if "co2_emission_gpkm" in self.norm_df.columns and "Environmental" in modified:
                # Carbon tax impact (higher emissions → higher cost)
                co2_impact = (
                    self.norm_df["co2_emission_gpkm"]
                    * self.policy_state.carbon_tax_per_gco2
                    / 100.0
                )
                modified["Environmental"] = 0.7 * modified["Environmental"] + 0.3 * co2_impact

        return modified

    def objective_contributions(self) -> Dict[str, np.ndarray]:
        """
        Decompose each objective into per-vehicle contributions.
        
        Returns:
            Dict[objective_name → ndarray(N,)] normalized contributions [0,1]
            
        This is the **key output** for the Projection Layer.
        """
        if self._contributions is None:
            objectives = self.apply_policy_modifiers()
            
            # Normalize each objective to [0,1]
            normalized_contributions = {}
            for obj_name, obj_values in objectives.items():
                min_val = np.min(obj_values)
                max_val = np.max(obj_values)
                if max_val > min_val:
                    norm_contrib = (obj_values - min_val) / (max_val - min_val)
                else:
                    norm_contrib = np.zeros_like(obj_values)
                normalized_contributions[obj_name] = norm_contrib

            self._contributions = normalized_contributions

        return self._contributions

    # ========================================================================
    # PRIVATE METHODS: Objective Composition Logic
    # ========================================================================

    def _compose_objective(self, category: str) -> Optional[np.ndarray]:
        """
        Compose a single objective from its constituent variables.
        
        Args:
            category: One of "Economic", "Environmental", "Operational", "Asset"
            
        Returns:
            ndarray(N,) of objective values, or None if variables not available
        """
        category_vars = get_variables_by_category(category)
        
        # Filter to variables actually in dataframe
        available_vars = [v for v in category_vars.keys() if v in self.norm_df.columns]
        
        if not available_vars:
            return None

        if category == "Economic":
            return self._compose_economic(available_vars)
        elif category == "Environmental":
            return self._compose_environmental(available_vars)
        elif category == "Operational":
            return self._compose_operational(available_vars)
        elif category == "Asset":
            return self._compose_asset(available_vars)
        else:
            return None

    def _compose_economic(self, variables: List[str]) -> np.ndarray:
        """
        Economic objective: weighted mean of cost components.
        
        Weights: ~equal emphasis on fuel, maintenance, CAPEX, downtime
        """
        weights = {
            "fuel_cost_per_km": 0.25,
            "maintenance_cost_per_year": 0.25,
            "capex_ev": 0.30,
            "downtime_cost_per_day": 0.20,
        }
        return self._aggregate_variables(variables, weights)

    def _compose_environmental(self, variables: List[str]) -> np.ndarray:
        """
        Environmental objective: primary emissions + pollutant index.
        
        Weights: ~60% emissions, 40% pollutants
        """
        weights = {
            "co2_emission_gpkm": 0.60,
            "pollutants_index": 0.40,
            "compliance_liability": 0.00,  # Applied as modifier, not in base
        }
        return self._aggregate_variables(variables, weights)

    def _compose_operational(self, variables: List[str]) -> np.ndarray:
        """
        Operational objective: utilization weighted, downtime penalized.
        
        Weights: +utilization, -downtime, +criticality
        """
        result = np.zeros(self.n_vehicles)

        if "utilization_percent" in variables:
            util = self.norm_df["utilization_percent"].values
            result += 0.40 * util  # Positive contribution

        if "service_criticality" in variables:
            crit = self.norm_df["service_criticality"].values / 10.0  # Scale to [0,1]
            result += 0.30 * crit

        if "downtime_hours_annual" in variables:
            downtime = self.norm_df["downtime_hours_annual"].values
            result += 0.30 * (1 - downtime)  # Penalty for downtime

        return result

    def _compose_asset(self, variables: List[str]) -> np.ndarray:
        """
        Asset objective: RUL-centric with age penalty.
        
        Weights: +RUL, -age, +reliability
        """
        result = np.zeros(self.n_vehicles)

        if "remaining_useful_life" in variables:
            rul = self.norm_df["remaining_useful_life"].values
            result += 0.40 * rul

        if "reliability_score" in variables:
            rel = self.norm_df["reliability_score"].values / 100.0  # Scale to [0,1]
            result += 0.35 * rel

        if "vehicle_age" in variables:
            age = self.norm_df["vehicle_age"].values
            result += 0.25 * (1 - age)  # Penalty for older vehicles

        return result

    def _aggregate_variables(
        self, variables: List[str], weights: Optional[Dict[str, float]] = None
    ) -> np.ndarray:
        """
        Aggregate variables using specified weights.
        
        Args:
            variables: List of variable names
            weights: Dict[variable → weight], or None for equal weights
            
        Returns:
            ndarray(N,) aggregated values
        """
        if not variables:
            return np.zeros(self.n_vehicles)

        if weights is None:
            weights = {v: 1.0 / len(variables) for v in variables}

        result = np.zeros(self.n_vehicles)
        total_weight = 0.0

        for var in variables:
            if var in self.norm_df.columns and var in weights:
                result += weights[var] * self.norm_df[var].values
                total_weight += weights[var]

        if total_weight > 0:
            result /= total_weight

        return result

    # ========================================================================
    # PUBLIC API: Query methods
    # ========================================================================

    def get_summary(self) -> Dict[str, Dict[str, float]]:
        """
        Get summary statistics of all objectives.
        
        Returns:
            {objective_name: {min, max, mean, std}}
        """
        objectives = self.build_objectives()
        summary = {}

        for obj_name, obj_values in objectives.items():
            summary[obj_name] = {
                "min": float(np.min(obj_values)),
                "max": float(np.max(obj_values)),
                "mean": float(np.mean(obj_values)),
                "std": float(np.std(obj_values)),
            }

        return summary

    def to_dataframe(self) -> pd.DataFrame:
        """
        Export objective values as DataFrame.
        
        Returns:
            DataFrame with objective columns
        """
        objectives = self.build_objectives()
        result_df = self.raw_df[[col for col in self.raw_df.columns if col in ["vehicle_id", "vehicle_type"]]]

        for obj_name, obj_values in objectives.items():
            result_df[obj_name] = obj_values

        return result_df


# ============================================================================
# UTILITY FUNCTION
# ============================================================================

def compose_objectives(
    raw_df: pd.DataFrame,
    norm_df: pd.DataFrame,
    policy_state: Optional[Dict] = None,
) -> Tuple[Dict[str, np.ndarray], ObjectiveCompositionEngine]:
    """
    Convenience function: compose objectives and return both values + engine.
    
    Args:
        raw_df: Raw vehicle data
        norm_df: Normalized vehicle data
        policy_state: Policy configuration
        
    Returns:
        (objectives_dict, engine)
    """
    engine = ObjectiveCompositionEngine(raw_df, norm_df, policy_state)
    objectives = engine.build_objectives()
    objectives = engine.apply_policy_modifiers()
    return objectives, engine
