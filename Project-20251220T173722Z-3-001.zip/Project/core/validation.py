"""
Dataset Validation Rules

Ensures that datasets are decision-safe, model-safe, and research-valid
before any optimization or Monte Carlo runs.

Validation outcomes:
- PASS: Safe to proceed
- WARN: Proceed with caution (log warnings)
- FAIL: Block optimization (critical errors)
"""

import pandas as pd
import numpy as np
import json
from typing import Dict, List, Tuple, Optional
from pathlib import Path


class ValidationResult:
    """Encapsulates validation outcome."""
    
    def __init__(self, status: str, messages: List[str] = None):
        """
        Args:
            status: "PASS", "WARN", or "FAIL"
            messages: List of human-readable messages
        """
        self.status = status
        self.messages = messages or []
    
    def add_message(self, msg: str):
        self.messages.append(msg)
    
    def __str__(self):
        return f"[{self.status}] {'; '.join(self.messages)}"
    
    def is_pass(self) -> bool:
        return self.status == "PASS"
    
    def is_fail(self) -> bool:
        return self.status == "FAIL"


class DatasetValidator:
    """
    Multi-stage validator for fleet datasets.
    
    Stages:
    1. Schema validation (columns, types, uniqueness)
    2. Semantic validation (ranges, nulls)
    3. Completeness (critical variables)
    4. Cross-variable consistency
    5. Policy compatibility
    """
    
    def __init__(self, metadata_path: str = None):
        """
        Initialize validator.
        
        Args:
            metadata_path: Path to variable_metadata.json (auto-loads if provided)
        """
        self.metadata = {}
        if metadata_path:
            self.load_metadata(metadata_path)
    
    def load_metadata(self, path: str):
        """Load variable metadata from JSON."""
        with open(path, 'r') as f:
            self.metadata = json.load(f)
    
    def validate(self, df: pd.DataFrame, policy_state: Optional[Dict] = None) -> ValidationResult:
        """
        Run all validation stages.
        
        Args:
            df: DataFrame to validate
            policy_state: Optional PolicyState for policy-specific checks
            
        Returns:
            ValidationResult with status and messages
        """
        result = ValidationResult("PASS")
        
        # Stage 1: Schema
        schema_result = self.validate_schema(df)
        if schema_result.is_fail():
            return schema_result
        if not schema_result.is_pass():
            result.messages.extend(schema_result.messages)
            result.status = "WARN"
        
        # Stage 2: Semantic
        semantic_result = self.validate_semantic(df)
        if semantic_result.is_fail():
            return semantic_result
        if not semantic_result.is_pass():
            result.messages.extend(semantic_result.messages)
            result.status = "WARN"
        
        # Stage 3: Completeness
        completeness_result = self.validate_completeness(df)
        if completeness_result.is_fail():
            return completeness_result
        if not completeness_result.is_pass():
            result.messages.extend(completeness_result.messages)
            result.status = "WARN"
        
        # Stage 4: Consistency
        consistency_result = self.validate_consistency(df)
        if not consistency_result.is_pass():
            result.messages.extend(consistency_result.messages)
            result.status = "WARN"
        
        # Stage 5: Policy compatibility
        if policy_state:
            policy_result = self.validate_policy_compatibility(df, policy_state)
            if not policy_result.is_pass():
                result.messages.extend(policy_result.messages)
                result.status = "WARN"
        
        return result
    
    def validate_schema(self, df: pd.DataFrame) -> ValidationResult:
        """
        Stage 1: Schema Validation
        
        Checks:
        - vehicle_id column exists
        - vehicle_id is unique
        - Expected column types
        """
        result = ValidationResult("PASS")
        
        # Check vehicle_id exists
        if "vehicle_id" not in df.columns:
            result.status = "FAIL"
            result.add_message("Missing required column: vehicle_id")
            return result
        
        # Check uniqueness
        if not df["vehicle_id"].is_unique:
            result.status = "FAIL"
            duplicates = df["vehicle_id"].duplicated().sum()
            result.add_message(f"vehicle_id is not unique ({duplicates} duplicates)")
            return result
        
        # Check no rows
        if len(df) == 0:
            result.status = "FAIL"
            result.add_message("DataFrame is empty")
            return result
        
        return result
    
    def validate_semantic(self, df: pd.DataFrame) -> ValidationResult:
        """
        Stage 2: Semantic Validation
        
        Checks per-variable:
        - Value ranges
        - Type correctness
        - Cost variables ≥ 0
        - Percentage variables in [0,100]
        - Probability/reliability in [0,1]
        """
        result = ValidationResult("PASS")
        
        if not self.metadata:
            return result  # Skip if no metadata
        
        for var_name, var_meta in self.metadata.items():
            if var_name not in df.columns:
                continue
            
            col = df[var_name]
            
            # Check numeric
            if not pd.api.types.is_numeric_dtype(col):
                result.status = "WARN"
                result.add_message(f"{var_name} is not numeric (found {col.dtype})")
                continue
            
            # Check range if specified
            valid_range = var_meta.get("valid_range")
            if valid_range:
                min_val, max_val = valid_range
                
                if min_val is not None:
                    if (col < min_val).any():
                        result.status = "WARN"
                        violating = (col < min_val).sum()
                        result.add_message(
                            f"{var_name}: {violating} values below minimum {min_val}"
                        )
                
                if max_val is not None:
                    if (col > max_val).any():
                        result.status = "WARN"
                        violating = (col > max_val).sum()
                        result.add_message(
                            f"{var_name}: {violating} values above maximum {max_val}"
                        )
        
        return result
    
    def validate_completeness(self, df: pd.DataFrame) -> ValidationResult:
        """
        Stage 3: Completeness Check
        
        Critical variables must not be null.
        """
        result = ValidationResult("PASS")
        
        if not self.metadata:
            return result
        
        critical_vars = [
            var for var, meta in self.metadata.items()
            if meta.get("critical", False)
        ]
        
        for var in critical_vars:
            if var not in df.columns:
                result.status = "FAIL"
                result.add_message(f"Critical variable missing: {var}")
                return result
            
            if df[var].isna().any():
                nulls = df[var].isna().sum()
                result.status = "FAIL"
                result.add_message(
                    f"Critical variable {var} has {nulls} null values"
                )
                return result
        
        # Non-critical may have nulls (will be imputed)
        non_critical_with_nulls = [
            (var, df[var].isna().sum())
            for var in df.columns
            if var in self.metadata and not self.metadata[var].get("critical")
            and df[var].isna().any()
        ]
        
        for var, null_count in non_critical_with_nulls:
            result.status = "WARN"
            result.add_message(
                f"Non-critical variable {var} has {null_count} nulls (will be imputed)"
            )
        
        return result
    
    def validate_consistency(self, df: pd.DataFrame) -> ValidationResult:
        """
        Stage 4: Cross-Variable Consistency
        
        Checks:
        - vehicle_age <= (age + RUL)
        - downtime_hours <= 8760
        - High utilization + high downtime is flagged
        """
        result = ValidationResult("PASS")
        
        # Age + RUL consistency
        if "vehicle_age" in df.columns and "remaining_useful_life" in df.columns:
            total_life = df["vehicle_age"] + df["remaining_useful_life"]
            if (total_life > 30).any():
                over_lifetime = (total_life > 30).sum()
                result.status = "WARN"
                result.add_message(
                    f"Age + RUL > 30 years for {over_lifetime} vehicles (unusual)"
                )
        
        # Downtime sanity check
        if "downtime_hours_annual" in df.columns:
            max_hours = 8760
            if (df["downtime_hours_annual"] > max_hours).any():
                impossible = (df["downtime_hours_annual"] > max_hours).sum()
                result.status = "FAIL"
                result.add_message(
                    f"downtime_hours_annual > 8760 for {impossible} vehicles (impossible)"
                )
                return result
        
        # Utilization + downtime pattern
        if "utilization_percent" in df.columns and "downtime_hours_annual" in df.columns:
            high_util = df["utilization_percent"] > 80
            high_downtime = df["downtime_hours_annual"] > 500
            if (high_util & high_downtime).any():
                suspicious = (high_util & high_downtime).sum()
                result.status = "WARN"
                result.add_message(
                    f"High utilization + high downtime for {suspicious} vehicles (check data quality)"
                )
        
        return result
    
    def validate_policy_compatibility(
        self, df: pd.DataFrame, policy_state: Dict
    ) -> ValidationResult:
        """
        Stage 5: Policy Compatibility
        
        Checks:
        - If EV_mandate=True, requires charging_availability
        - If emission_cap set, requires emissions data
        """
        result = ValidationResult("PASS")
        
        # EV mandate check
        if policy_state.get("EV_mandate"):
            if "charging_availability" not in df.columns:
                result.status = "WARN"
                result.add_message(
                    "EV mandate active but charging_availability not in dataset"
                )
        
        # Emission cap check
        if policy_state.get("emission_cap_gpkm"):
            if "co2_emission_gpkm" not in df.columns:
                result.status = "WARN"
                result.add_message(
                    "Emission cap set but co2_emission_gpkm not in dataset"
                )
        
        # Carbon tax check
        if policy_state.get("carbon_tax"):
            if "co2_emission_gpkm" not in df.columns:
                result.status = "WARN"
                result.add_message(
                    "Carbon tax active but co2_emission_gpkm not in dataset"
                )
        
        return result
    
    # ========================================================================
    # Summary and Reporting
    # ========================================================================
    
    def validation_summary(self, df: pd.DataFrame) -> Dict:
        """Get summary of dataset quality."""
        return {
            "n_vehicles": len(df),
            "n_variables": len(df.columns),
            "n_nulls": int(df.isna().sum().sum()),
            "completeness_pct": float(
                100 * (1 - df.isna().sum().sum() / (len(df) * len(df.columns)))
            ),
            "columns": list(df.columns),
        }


# ============================================================================
# Convenience Functions
# ============================================================================

def validate_fleet_data(
    df: pd.DataFrame,
    metadata_path: Optional[str] = None,
    policy_state: Optional[Dict] = None,
) -> Tuple[bool, str]:
    """
    Quick validation wrapper.
    
    Args:
        df: Fleet DataFrame
        metadata_path: Path to variable_metadata.json
        policy_state: Optional policy configuration
        
    Returns:
        (is_valid: bool, message: str)
    """
    validator = DatasetValidator(metadata_path)
    result = validator.validate(df, policy_state)
    return result.is_pass(), str(result)
