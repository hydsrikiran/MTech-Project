from pyomo.environ import Constraint, Binary, Var, NonNegativeReals

class FeasibilityEngine:
    """
    Builds hard feasibility constraints C_j(x) <= 0
    """

    def __init__(self, model, raw_df, config):
        """
        model   : Pyomo model
        raw_df  : original (non-normalized) dataframe
        config  : feasibility configuration from UI / config
        """
        self.model = model
        self.df = raw_df
        self.config = config
        self.N = len(raw_df)

        self._declare_variables()
        self._build_constraints()

    # -------------------------------
    # Decision variables
    # -------------------------------

    def _declare_variables(self):
        self.model.x = Var(
            range(self.N),
            domain=Binary
        )

    # -------------------------------
    # Constraint builder
    # -------------------------------

    def _build_constraints(self):
        self._budget_constraint()
        self._service_constraint()
        self._infrastructure_constraint()
        self._mandatory_constraint()

    # -------------------------------
    # C1: Budget constraint
    # -------------------------------

    def _budget_constraint(self):
        B = self.config["budget"]

        capex = self.df["capex_ev"].values

        self.model.budget_constraint = Constraint(
            expr=sum(capex[i] * self.model.x[i] for i in range(self.N)) <= B
        )

    # -------------------------------
    # C2: Service continuity constraint
    # -------------------------------

    def _service_constraint(self):
        min_service = self.config["min_service_level"]

        service = self.df["service_criticality"].values

        self.model.service_constraint = Constraint(
            expr=sum(service[i] * self.model.x[i] for i in range(self.N)) >= min_service
        )

    # -------------------------------
    # C3: Infrastructure (charging) constraint
    # -------------------------------

    def _infrastructure_constraint(self):
        max_charging_load = self.config["max_charging_load"]

        charging = self.df["charging_available"].values

        self.model.infra_constraint = Constraint(
            expr=sum(charging[i] * self.model.x[i] for i in range(self.N)) <= max_charging_load
        )

    # -------------------------------
    # C4: Mandatory replacement constraint
    # -------------------------------

    def _mandatory_constraint(self):
        mandatory = self.df["mandatory_replacement"].values

        def mandatory_rule(m, i):
            if mandatory[i] == 1:
                return m.x[i] == 1
            return Constraint.Skip

        self.model.mandatory_constraint = Constraint(
            range(self.N),
            rule=mandatory_rule
        )
