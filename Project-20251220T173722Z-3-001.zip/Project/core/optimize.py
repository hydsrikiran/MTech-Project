import pyomo.environ as pyo
import numpy as np
from typing import Dict, List, Tuple


class OptimizationEngine:
    """
    MILP Optimization Engine.
    
    Solves: minimize sum(Z_k(x)) for k in objectives
    
    Subject to: Feasibility constraints (budget, service level, etc.)
    
    Accepts: objectives as Dict[str, ndarray(N,)] from ObjectiveCompositionEngine
    
    Returns:
    - x_star: Binary decision vector
    - objective_values: Dict[objective_name -> value]
    """
    
    def __init__(self, raw_df, norm_df, objectives: Dict[str, np.ndarray], feasibility):
        """
        Initialize optimizer.
        
        Args:
            raw_df: Raw vehicle data
            norm_df: Normalized vehicle data [0,1]
            objectives: Dict[objective_name -> ndarray(N,)] from OCE
            feasibility: Dict with constraints (budget, service_level, etc.)
        """
        self.raw = raw_df
        self.norm = norm_df
        self.objectives = objectives  # Dict[str, ndarray]
        self.feas = feasibility
        self.N = len(raw_df)
        self.objective_names = list(objectives.keys())

    def solve(self) -> Tuple[List[float], Dict[str, float]]:
        """
        Solve the optimization problem.
        
        Returns
        -------
        x_star : List[float]
            Binary decision vector (0 or 1 for each vehicle)
        objective_values : Dict[str, float]
            Per-objective values at solution
        """
        m = pyo.ConcreteModel()

        # ---------------- Sets ----------------
        m.I = pyo.RangeSet(0, self.N - 1)
        m.K = pyo.RangeSet(0, len(self.objective_names) - 1)

        # ---------------- Variables ----------------
        m.x = pyo.Var(m.I, domain=pyo.Binary)

        # ---------------- Objective Expressions (per-objective values) ----------------
        # Map objective indices to values
        def Z_rule(m, k):
            """Sum of normalized objective k over selected vehicles"""
            obj_name = self.objective_names[k]
            obj_values = self.objectives[obj_name]  # ndarray(N,)
            return sum(obj_values[i] * m.x[i] for i in m.I)

        m.Z = pyo.Expression(m.K, rule=Z_rule)

        # Store reference for later evaluation
        self._m_Z = m.Z

        # ---------------- Objective (Minimize sum of objectives) ----------------
        m.obj = pyo.Objective(
            expr=sum(m.Z[k] for k in m.K),
            sense=pyo.minimize
        )
        # Store for later
        self._m_obj = m.obj

        # ---------------- Feasibility Constraints ----------------
        # Budget (if capex_ev exists in data)
        if "capex_ev" in self.raw.columns:
            m.budget = pyo.Constraint(
                expr=sum(self.raw["capex_ev"].iloc[i] * m.x[i] for i in m.I)
                <= self.feas.get("budget", float('inf'))
            )

        # Service level (if service_criticality exists)
        if "service_criticality" in self.raw.columns:
            m.service = pyo.Constraint(
                expr=sum(self.raw["service_criticality"].iloc[i] * m.x[i] for i in m.I)
                >= self.feas.get("min_service_level", 0)
            )

        # Charging (if charging_availability exists)
        if "charging_availability" in self.raw.columns:
            m.charging = pyo.Constraint(
                expr=sum(self.raw["charging_availability"].iloc[i] * m.x[i] for i in m.I)
                <= self.feas.get("max_charging_load", float('inf'))
            )

        # Mandatory replacements (if column exists)
        if "mandatory_replacement" in self.raw.columns:
            for i in m.I:
                if self.raw["mandatory_replacement"].iloc[i] > 0:
                    m.add_component(
                        f"mandatory_{i}",
                        pyo.Constraint(expr=m.x[i] == 1)
                    )

        # Minimum fleet size (select at least N vehicles)
        min_fleet_size = self.feas.get("min_fleet_size", 1)
        m.min_fleet = pyo.Constraint(expr=sum(m.x[i] for i in m.I) >= min_fleet_size)

        # ---------------- Solve ----------------
        solver = pyo.SolverFactory("glpk")
        results = solver.solve(m, tee=False)

        # Check solver status
        if results.solver.status != pyo.SolverStatus.ok:
            raise RuntimeError(f"Solver failed: {results.solver.status}")
        if results.solver.termination_condition != pyo.TerminationCondition.optimal:
            raise RuntimeError(
                f"No optimal solution found (termination: {results.solver.termination_condition}). "
                f"Problem may be infeasible with current constraints. Try: "
                f"1. Increase budget (currently ₹{self.feas.get('budget', 0):,.0f}), "
                f"2. Reduce min_fleet_size (currently {self.feas.get('min_fleet_size', 1)}), "
                f"3. Relax other constraints"
            )

        # Extract solution
        x_star = [pyo.value(m.x[i]) for i in m.I]
        
        # Extract per-objective values
        objective_values = {}
        for k in m.K:
            obj_name = self.objective_names[k]
            objective_values[obj_name] = pyo.value(m.Z[k])
        
        return x_star, objective_values

