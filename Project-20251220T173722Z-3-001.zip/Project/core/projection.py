"""
PROJECTION LAYER — Dynamic Re-Ranking Without Re-Optimization
================================================================

This module implements the critical "dynamic" component:
- Reweight RPI based on user objective preferences
- Project scenario outputs under new weights
- Enable instant UI updates without solver rerun
- Compute robustness metrics (top-K probability, stability classification)

Mathematical basis (Dissertation §7.2, §8.4):

RPI_i = E_s[ ∑_k θ_k × normalized(Δ_i^{k,s}) ]

where:
  Δ_i^{k,s} = marginal contribution of vehicle i to objective k in scenario s
  θ_k = user-specified weight for objective k
  E_s = expectation over all Monte Carlo scenarios S

Robustness metrics (§8.4):
  P_i^(K) = Pr(Rank_i ≤ K)  [Probability of being in top K across scenarios]
  Classification = hierarchical clustering based on RPI and volatility
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional


class ProjectionEngine:
    """
    Projects cached Monte Carlo outputs under new objective weights.
    
    Allows instant ranking updates when targets/weights change WITHOUT
    re-running optimization or Monte Carlo.
    
    Mathematical basis:
    
    Projected_RPI_i = Σ_k ( w_k × normalized_marginal_contribution_ik )
    
    where:
        w_k = user-specified weight for objective k
        marginal_contribution_ik = marginal value of vehicle i under objective k
    """
    
    def __init__(
        self,
        scenario_marginals: np.ndarray,
        vehicle_ids: List[str],
        objective_names: List[str]
    ):
        """
        Parameters
        ----------
        scenario_marginals : dict
            {objective_name: ndarray(S, N)}
            S = number of scenarios
            N = number of vehicles
        vehicle_ids : List[str]
        objective_names : List[str]
        """
        self.scenario_marginals = scenario_marginals  # Dict[str, ndarray(S, N)]
        self.vehicle_ids = vehicle_ids
        self.objective_names = objective_names
        self.S, self.N = next(iter(scenario_marginals.values())).shape
        
        # Normalize each objective's marginals for fair weighting
        self._normalized_marginals = self._normalize_objectives()
    
    def _normalize_objectives(self) -> Dict[str, np.ndarray]:
        """
        Normalize marginals within each objective to [0, 1] scale.
        
        This ensures that objective weights are truly comparable and
        small/large absolute values don't dominate the weighting.
        """
        normalized = {}
        
        for obj_name, marginals in self.scenario_marginals.items():
            # Shape: (S, N)
            flat = marginals.flatten()
            finite = flat[np.isfinite(flat)]
            
            if len(finite) > 0:
                min_val = np.min(finite)
                max_val = np.max(finite)
                
                if max_val > min_val:
                    normalized[obj_name] = (marginals - min_val) / (max_val - min_val)
                else:
                    normalized[obj_name] = np.zeros_like(marginals)
            else:
                normalized[obj_name] = np.zeros_like(marginals)
        
        return normalized
    
    def project_rpi(self, objective_weights: Dict[str, float]) -> np.ndarray:
        """
        Compute weighted RPI under new objective preferences.
        
        Parameters
        ----------
        objective_weights : Dict[str, float]
            e.g., {'Economic': 0.5, 'Environmental': 0.3, 'Service': 0.2}
        
        Returns
        -------
        projected_rpi : ndarray(N,)
            Weighted mean marginal contribution across objectives
        """
        # Normalize weights
        total_weight = sum(objective_weights.values())
        if total_weight == 0:
            total_weight = 1.0
        
        weighted_marginals = np.zeros((self.S, self.N))
        
        for obj_name, weight in objective_weights.items():
            if obj_name in self._normalized_marginals:
                norm_weight = weight / total_weight
                weighted_marginals += norm_weight * self._normalized_marginals[obj_name]
        
        # Compute mean across scenarios
        projected_rpi = np.mean(weighted_marginals, axis=0)
        
        return projected_rpi
    
    def project_rankings(
        self,
        objective_weights: Dict[str, float]
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Compute projected rankings under new weights.
        
        Returns
        -------
        ranked_indices : ndarray(N,)
            Indices sorted by RPI (descending)
        projected_rpi : ndarray(N,)
            Projected RPI values
        """
        projected_rpi = self.project_rpi(objective_weights)
        ranked_indices = np.argsort(-projected_rpi)  # descending
        
        return ranked_indices, projected_rpi
    
    def project_volatility(self, objective_weights: Dict[str, float]) -> np.ndarray:
        """
        Compute volatility of projected RPI across scenarios.
        """
        weighted_marginals = np.zeros((self.S, self.N))
        
        total_weight = sum(objective_weights.values())
        if total_weight == 0:
            total_weight = 1.0
        
        for obj_name, weight in objective_weights.items():
            if obj_name in self._normalized_marginals:
                norm_weight = weight / total_weight
                weighted_marginals += norm_weight * self._normalized_marginals[obj_name]
        
        volatility = np.std(weighted_marginals, axis=0)
        return volatility
    
    def project_classification(
        self,
        objective_weights: Dict[str, float]
    ) -> List[str]:
        """
        Classify vehicles under new weights using percentile-based approach.
        
        Categories:
        - High-Priority Robust (RPI ≥ 75th, Vol ≤ 50th)
        - High-Priority Sensitive (RPI ≥ 75th, Vol > 50th)
        - Medium-Priority (25th < RPI < 75th)
        - Low-Priority Robust (RPI ≤ 25th, Vol ≤ 50th)
        - Low-Priority Sensitive (RPI ≤ 25th, Vol > 50th)
        - Feasibility-Critical (inf values)
        """
        rpi = self.project_rpi(objective_weights)
        vol = self.project_volatility(objective_weights)
        
        # Percentile-based thresholds (relative, not absolute)
        finite_rpi = rpi[np.isfinite(rpi)]
        finite_vol = vol[np.isfinite(vol)]
        
        if len(finite_rpi) > 0:
            rpi_q75 = np.percentile(finite_rpi, 75)
            rpi_q25 = np.percentile(finite_rpi, 25)
        else:
            rpi_q75 = 0
            rpi_q25 = 0
        
        if len(finite_vol) > 0:
            vol_q50 = np.percentile(finite_vol, 50)
        else:
            vol_q50 = 0
        
        labels = []
        for i in range(self.N):
            if np.isinf(rpi[i]):
                labels.append("Feasibility-Critical")
            elif rpi[i] >= rpi_q75 and vol[i] <= vol_q50:
                labels.append("High-Priority Robust")
            elif rpi[i] >= rpi_q75 and vol[i] > vol_q50:
                labels.append("High-Priority Sensitive")
            elif rpi[i] <= rpi_q25 and vol[i] <= vol_q50:
                labels.append("Low-Priority Robust")
            elif rpi[i] <= rpi_q25 and vol[i] > vol_q50:
                labels.append("Low-Priority Sensitive")
            else:
                labels.append("Medium-Priority")
        
        return labels
    
    def project_scenario_slice(
        self,
        scenario_idx: int,
        objective_weights: Dict[str, float]
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Get weighted marginal values for a specific scenario.
        
        Returns
        -------
        values : ndarray(N,)
            Weighted marginal values for that scenario
        ranked_indices : ndarray(N,)
            Ranking within that scenario
        """
        total_weight = sum(objective_weights.values())
        if total_weight == 0:
            total_weight = 1.0
        
        weighted = np.zeros(self.N)
        for obj_name, weight in objective_weights.items():
            if obj_name in self._normalized_marginals:
                norm_weight = weight / total_weight
                weighted += norm_weight * self._normalized_marginals[obj_name][scenario_idx]
        
        ranked_indices = np.argsort(-weighted)
        return weighted, ranked_indices
    
    def get_summary_table(
        self,
        objective_weights: Dict[str, float]
    ) -> pd.DataFrame:
        """
        Generate a summary table with projected metrics.
        """
        rpi = self.project_rpi(objective_weights)
        vol = self.project_volatility(objective_weights)
        labels = self.project_classification(objective_weights)
        rankings, _ = self.project_rankings(objective_weights)
        
        # Get rank position for each vehicle
        rank_pos = np.zeros(self.N, dtype=int)
        for rank, idx in enumerate(rankings):
            rank_pos[idx] = rank + 1
        
        # Scale RPI and Volatility to 0-100 for readability
        rpi_scaled = np.maximum(0, np.minimum(100, rpi * 100))
        vol_scaled = np.maximum(0, np.minimum(100, vol * 100))
        
        df = pd.DataFrame({
            "vehicle_id": self.vehicle_ids,
            "rank": rank_pos,
            "RPI": np.round(rpi_scaled, 1),
            "Volatility": np.round(vol_scaled, 1),
            "Classification": labels
        })
        
        return df.sort_values("rank").reset_index(drop=True)
    
    def get_contribution_breakdown(
        self,
        vehicle_idx: int,
        objective_weights: Dict[str, float]
    ) -> pd.DataFrame:
        """
        Show how each objective contributes to this vehicle's RPI.
        
        Useful for explainability.
        """
        data = []
        
        for obj_name in self.objective_names:
            if obj_name in self._normalized_marginals:
                marginal = self._normalized_marginals[obj_name][:, vehicle_idx]
                mean_contrib = np.mean(marginal)
                weight = objective_weights.get(obj_name, 0.0)
                
                total_weight = sum(objective_weights.values())
                if total_weight == 0:
                    total_weight = 1.0
                
                norm_weight = weight / total_weight
                weighted_contrib = mean_contrib * norm_weight
                
                data.append({
                    "Objective": obj_name,
                    "Mean_Contribution": mean_contrib,
                    "Weight": norm_weight,
                    "Weighted_Contribution": weighted_contrib
                })
        
        return pd.DataFrame(data).sort_values("Weighted_Contribution", ascending=False)
    
    def compute_rpi_explicit(self, objective_weights: Dict[str, float]) -> np.ndarray:
        """
        Explicit RPI Computation (Dissertation §7.2, core/projection.py)
        
        Computes: RPI_i = E_s[ ∑_{k=1}^K θ_k × normalized(Δ_i^{k,s}) ]
        
        This is the core mathematical formula for vehicle prioritization.
        
        Parameters
        ----------
        objective_weights : Dict[str, float]
            User-specified weights for each objective (auto-normalized)
        
        Returns
        -------
        rpi : np.ndarray
            Shape (N,) - Replacement Priority Index per vehicle
        
        Mathematical Reference
        ----------------------
        Dissertation §7.2:
            RPI_i = E_s[ ∑_k θ_k × Δ_i^{k,s} ]
        
        where:
            Δ_i^{k,s} = vehicle i's marginal contribution to objective k in scenario s
            θ_k = normalized weight for objective k
            E_s = expectation (mean) across all Monte Carlo scenarios
        
        Implementation Details
        ----------------------
        1. Normalize weights to sum to 1.0
        2. Aggregate per-scenario weighted marginals: Σ_k θ_k × marg_ik
        3. Average across scenarios: E_s[...]
        """
        # Normalize weights
        total_weight = sum(objective_weights.values())
        if total_weight <= 0:
            total_weight = 1.0
        weights_normalized = {k: v / total_weight for k, v in objective_weights.items()}
        
        # Compute weighted sum across objectives per scenario
        weighted_marginals = np.zeros((self.S, self.N))
        
        for obj_name, weight in weights_normalized.items():
            if obj_name in self._normalized_marginals:
                weighted_marginals += weight * self._normalized_marginals[obj_name]
        
        # Average across scenarios
        rpi = np.mean(weighted_marginals, axis=0)
        return rpi
    
    def compute_robustness_metrics(
        self,
        objective_weights: Dict[str, float],
        top_k: int = 5
    ) -> Dict[str, any]:
        """
        Compute Robustness Metrics (Dissertation §8.4)
        
        Computes:
        - Top-K probability: P_i^(K) = Pr(Rank_i ≤ K) across scenarios
        - Ranking stability: How consistently each vehicle ranks
        - Volatility classification: Robust vs. Context-Sensitive vs. Low-Impact
        
        Parameters
        ----------
        objective_weights : Dict[str, float]
            User-specified objective weights
        top_k : int
            Track probability of being in top K (default: top 5)
        
        Returns
        -------
        metrics : Dict with keys:
            - 'top_k_probability': ndarray(N,) - P_i^(K) for each vehicle
            - 'mean_rank': ndarray(N,) - E[Rank_i] across scenarios
            - 'rank_volatility': ndarray(N,) - Std[Rank_i] across scenarios
            - 'rank_variance': ndarray(N,) - Var[Rank_i] across scenarios
            - 'robustness_class': List[str] - classification per vehicle
            - 'rpi': ndarray(N,) - overall RPI
            - 'rank_positions_per_scenario': ndarray(S, N) - rank per scenario
        
        Mathematical Reference
        ----------------------
        Dissertation §8.4 (Robustness Framework):
            P_i^(K) = Pr(Rank_i ≤ K)  [Probability in top K]
            
            Classification:
            - Structurally Robust: P_i^(K) > 0.9 AND Var(Rank) < median
            - Context-Sensitive: P_i^(K) > 0.9 AND Var(Rank) ≥ median  
            - Low-Impact: P_i^(K) ≤ 0.1
            - Feasibility-Critical: NaN RPI (infeasible without this vehicle)
        
        Algorithm
        ---------
        1. For each scenario s ∈ [1..S]:
           a. Compute weighted RPI: Σ_k θ_k × normalized(Δ_i^{k,s})
           b. Rank vehicles 1..N by RPI
        2. For each vehicle i:
           a. Collect rank_positions across all scenarios
           b. Compute: mean_rank, volatility (std), variance
           c. Count how many scenarios i appeared in top_k
           d. P_i^(K) = count / S
        3. Classify each vehicle based on P_i^(K) and volatility
        """
        # Normalize weights
        total_weight = sum(objective_weights.values())
        if total_weight <= 0:
            total_weight = 1.0
        weights_norm = {k: v / total_weight for k, v in objective_weights.items()}
        
        # Step 1: Compute per-scenario rankings
        scenario_rankings = np.zeros((self.S, self.N), dtype=int)
        
        for s in range(self.S):
            weighted_s = np.zeros(self.N)
            
            for obj_name in self.objective_names:
                if obj_name in self._normalized_marginals:
                    weighted_s += weights_norm.get(obj_name, 0) * self._normalized_marginals[obj_name][s, :]
            
            # Rank vehicles by descending RPI (1 = best)
            scenario_rankings[s, :] = np.argsort(-weighted_s)
        
        # Step 2: Convert rankings to rank positions
        rank_positions = np.zeros((self.S, self.N), dtype=int)
        for s in range(self.S):
            rank_positions[s, scenario_rankings[s, :]] = np.arange(1, self.N + 1)
        
        # Step 3: Compute robustness metrics
        mean_rank = np.mean(rank_positions, axis=0)
        rank_volatility = np.std(rank_positions, axis=0)
        rank_variance = np.var(rank_positions, axis=0)
        
        # Step 4: Compute top-K probability
        top_k_count = np.sum(rank_positions <= top_k, axis=0)
        top_k_probability = top_k_count / self.S
        
        # Step 5: Compute overall RPI for this weighting
        rpi = self.compute_rpi_explicit(objective_weights)
        
        # Step 6: Classify robustness
        robustness_class = []
        median_volatility = np.median(rank_volatility)
        
        for i in range(self.N):
            if np.isinf(rpi[i]) or np.isnan(rpi[i]):
                robustness_class.append("Feasibility-Critical")
            elif top_k_probability[i] > 0.9 and rank_volatility[i] < median_volatility:
                robustness_class.append("Structurally Robust")
            elif top_k_probability[i] > 0.9 and rank_volatility[i] >= median_volatility:
                robustness_class.append("Context-Sensitive")
            elif top_k_probability[i] <= 0.1:
                robustness_class.append("Low-Impact")
            else:
                robustness_class.append("Moderate-Priority")
        
        return {
            'top_k_probability': top_k_probability,
            'mean_rank': mean_rank,
            'rank_volatility': rank_volatility,
            'rank_variance': rank_variance,
            'robustness_class': robustness_class,
            'rpi': rpi,
            'rank_positions_per_scenario': rank_positions
        }
    
    def get_robustness_summary(
        self,
        objective_weights: Dict[str, float],
        top_k: int = 5
    ) -> pd.DataFrame:
        """
        Create a summary table of robustness metrics.
        
        Parameters
        ----------
        objective_weights : Dict[str, float]
            User-specified objective weights
        top_k : int
            Window for top-K probability (default: 5)
        
        Returns
        -------
        summary_df : pd.DataFrame
            Summary table with all robustness indicators
            Columns: vehicle_id, rpi_score, mean_rank, rank_volatility, top_k_probability, robustness_class
        
        Example
        -------
        >>> engine = ProjectionEngine(scenario_marginals, vehicle_ids, objective_names)
        >>> weights = {'Economic': 0.4, 'Environmental': 0.3, 'Operational': 0.2, 'Asset': 0.1}
        >>> summary = engine.get_robustness_summary(weights, top_k=5)
        >>> print(summary)
        """
        metrics = self.compute_robustness_metrics(objective_weights, top_k)
        
        df = pd.DataFrame({
            'vehicle_id': self.vehicle_ids,
            'rpi_score': np.round(metrics['rpi'], 3),
            'mean_rank': np.round(metrics['mean_rank'], 1),
            'rank_volatility': np.round(metrics['rank_volatility'], 1),
            f'top_{top_k}_probability': np.round(metrics['top_k_probability'], 3),
            'robustness_class': metrics['robustness_class']
        })
        
        return df.sort_values('rpi_score', ascending=False).reset_index(drop=True)


# ============================================================================
# CORE FORMULATION FUNCTIONS (Dissertation §7.2, §8.4)
# ============================================================================

def compute_rpi_with_weights(
    marginals: Dict[str, np.ndarray],
    objective_weights: Dict[str, float]
) -> np.ndarray:
    """
    Explicit RPI Computation (Dissertation §7.2)
    
    Computes: RPI_i = E_s[ ∑_{k=1}^K θ_k × normalized(Δ_i^{k,s}) ]
    
    This is the core mathematical formula for vehicle prioritization.
    
    Parameters
    ----------
    marginals : Dict[str, np.ndarray]
        Per-objective marginal contributions
        Shape: {objective_name → ndarray(S, N)}
        where S = scenarios, N = vehicles
    
    objective_weights : Dict[str, float]
        User-specified weights for each objective
        Must sum to 1.0 (normalized)
        Example: {'Economic': 0.4, 'Environmental': 0.3, 'Operational': 0.2, 'Asset': 0.1}
    
    Returns
    -------
    rpi : np.ndarray
        Shape (N,) - Replacement Priority Index per vehicle
        Higher value = higher replacement priority
    
    Mathematical Reference
    ----------------------
    Dissertation §7.2:
        RPI_i = E_s[ ∑_k θ_k × Δ_i^{k,s} ]
    
    where:
        Δ_i^{k,s} = vehicle i's marginal contribution to objective k in scenario s
        θ_k = normalized weight for objective k
        E_s = expectation (mean) across all Monte Carlo scenarios
    
    Code Implementation Map
    -----------------------
    core/marginal.py:52-110    → Compute Δ_i^{k,s} (marginal contributions)
    core/montecarlo_custom.py  → Run scenarios s=1..S
    HERE                       → Aggregate with weights θ and scenarios
    """
    n_vehicles = next(iter(marginals.values())).shape[1]
    n_scenarios = next(iter(marginals.values())).shape[0]
    
    # Step 1: Normalize weights to sum to 1.0
    total_weight = sum(objective_weights.values())
    if total_weight <= 0:
        total_weight = 1.0
    weights_normalized = {
        k: v / total_weight for k, v in objective_weights.items()
    }
    
    # Step 2: Initialize weighted marginal storage (S, N)
    weighted_marginals = np.zeros((n_scenarios, n_vehicles))
    
    # Step 3: Normalize each objective's marginals to [0,1]
    # This ensures fair weighting across different objective scales
    normalized_marginals = {}
    for obj_name, marg in marginals.items():
        flat = marg.flatten()
        finite = flat[np.isfinite(flat)]
        
        if len(finite) > 0:
            marg_min = np.min(finite)
            marg_max = np.max(finite)
            
            if marg_max > marg_min:
                normalized_marginals[obj_name] = (marg - marg_min) / (marg_max - marg_min)
            else:
                normalized_marginals[obj_name] = np.zeros_like(marg)
        else:
            normalized_marginals[obj_name] = np.zeros_like(marg)
    
    # Step 4: Compute weighted sum per scenario
    # weighted_marginals[s, i] = ∑_k θ_k × normalized(Δ_i^{k,s})
    for obj_name, weight in weights_normalized.items():
        if obj_name in normalized_marginals:
            weighted_marginals += weight * normalized_marginals[obj_name]
    
    # Step 5: Aggregate across scenarios
    # RPI_i = E_s[ weighted_marginals[s, i] ]
    rpi = np.mean(weighted_marginals, axis=0)
    
    return rpi


def compute_robustness_metrics(
    marginals: Dict[str, np.ndarray],
    objective_weights: Dict[str, float],
    top_k: int = 5
) -> Dict[str, any]:
    """
    Compute Robustness Metrics (Dissertation §8.4)
    
    Computes:
    - Top-K probability: P_i^(K) = Pr(Rank_i ≤ K) across scenarios
    - Ranking stability: How often vehicle appears in consistent rank
    - Volatility classification: Robust vs. Sensitive
    
    Parameters
    ----------
    marginals : Dict[str, np.ndarray]
        Per-objective marginal contributions {obj_name → ndarray(S, N)}
    objective_weights : Dict[str, float]
        User-specified objective weights
    top_k : int
        Track probability of being in top K (default: top 5)
    
    Returns
    -------
    metrics : Dict
        {
            'top_k_probability': ndarray(N,),  # P_i^(K) for each vehicle
            'mean_rank': ndarray(N,),          # E[Rank_i] across scenarios
            'rank_volatility': ndarray(N,),    # Std[Rank_i] across scenarios
            'rank_variance': ndarray(N,),      # Var[Rank_i] across scenarios
            'robustness_class': List[str],     # ["Structurally Robust", "Context-Sensitive", ...]
            'rpi': ndarray(N,)                 # Overall RPI
        }
    
    Mathematical Reference
    ----------------------
    Dissertation §8.4:
        P_i^(K) = Pr(Rank_i ≤ K)  [Probability vehicle in top K]
        Structurally Robust: P_i^(20%) > 0.9 AND Var(Rank) < median
        Context-Sensitive: P_i^(20%) > 0.9 AND Var(Rank) ≥ median
        Low-Impact: P_i^(20%) ≤ 0.1
    """
    n_vehicles = next(iter(marginals.values())).shape[1]
    n_scenarios = next(iter(marginals.values())).shape[0]
    
    # Step 1: Compute RPI
    rpi = compute_rpi_with_weights(marginals, objective_weights)
    
    # Step 2: Compute per-scenario rankings
    scenario_rankings = np.zeros((n_scenarios, n_vehicles), dtype=int)
    
    # Normalize weights
    total_weight = sum(objective_weights.values())
    if total_weight <= 0:
        total_weight = 1.0
    weights_norm = {k: v / total_weight for k, v in objective_weights.items()}
    
    # For each scenario, compute weighted RPI and ranking
    for s in range(n_scenarios):
        weighted_s = np.zeros(n_vehicles)
        
        for obj_name in marginals.keys():
            marg = marginals[obj_name][s, :]  # (N,) for this scenario
            
            # Normalize within scenario
            finite = marg[np.isfinite(marg)]
            if len(finite) > 0:
                marg_min = np.min(finite)
                marg_max = np.max(finite)
                if marg_max > marg_min:
                    marg_norm = (marg - marg_min) / (marg_max - marg_min)
                else:
                    marg_norm = np.zeros_like(marg)
            else:
                marg_norm = np.zeros_like(marg)
            
            weighted_s += weights_norm.get(obj_name, 0) * marg_norm
        
        # Rank vehicles by weighted RPI (descending)
        scenario_rankings[s, :] = np.argsort(-weighted_s)
    
    # Step 3: Convert rankings to rank positions (1st, 2nd, 3rd, etc.)
    rank_positions = np.zeros((n_scenarios, n_vehicles), dtype=int)
    for s in range(n_scenarios):
        rank_positions[s, scenario_rankings[s, :]] = np.arange(1, n_vehicles + 1)
    
    # Step 4: Compute robustness metrics
    mean_rank = np.mean(rank_positions, axis=0)
    rank_volatility = np.std(rank_positions, axis=0)
    rank_variance = np.var(rank_positions, axis=0)
    
    # Step 5: Compute top-K probability
    # P_i^(K) = fraction of scenarios where vehicle i ranked ≤ K
    top_k_count = np.sum(rank_positions <= top_k, axis=0)
    top_k_probability = top_k_count / n_scenarios
    
    # Step 6: Classify robustness (Dissertation §8.4)
    robustness_class = []
    median_volatility = np.median(rank_volatility)
    
    for i in range(n_vehicles):
        if np.isinf(rpi[i]) or np.isnan(rpi[i]):
            robustness_class.append("Feasibility-Critical")
        elif top_k_probability[i] > 0.9 and rank_volatility[i] < median_volatility:
            robustness_class.append("Structurally Robust")
        elif top_k_probability[i] > 0.9 and rank_volatility[i] >= median_volatility:
            robustness_class.append("Context-Sensitive")
        elif top_k_probability[i] <= 0.1:
            robustness_class.append("Low-Impact")
        else:
            robustness_class.append("Moderate-Priority")
    
    return {
        'top_k_probability': top_k_probability,
        'mean_rank': mean_rank,
        'rank_volatility': rank_volatility,
        'rank_variance': rank_variance,
        'robustness_class': robustness_class,
        'rpi': rpi,
        'rank_positions_per_scenario': rank_positions  # For detailed analysis
    }


def get_robustness_summary(
    robustness_metrics: Dict[str, any],
    vehicle_ids: List[str]
) -> pd.DataFrame:
    """
    Create a summary table of robustness metrics.
    
    Parameters
    ----------
    robustness_metrics : Dict
        Output from compute_robustness_metrics()
    vehicle_ids : List[str]
        Vehicle identifiers
    
    Returns
    -------
    summary_df : pd.DataFrame
        Summary table with all robustness indicators
    """
    df = pd.DataFrame({
        'vehicle_id': vehicle_ids,
        'rpi_score': np.round(robustness_metrics['rpi'], 3),
        'mean_rank': np.round(robustness_metrics['mean_rank'], 1),
        'rank_volatility': np.round(robustness_metrics['rank_volatility'], 1),
        'top_5_probability': np.round(robustness_metrics['top_k_probability'], 3),
        'robustness_class': robustness_metrics['robustness_class']
    })
    
    return df.sort_values('rpi_score', ascending=False).reset_index(drop=True)
