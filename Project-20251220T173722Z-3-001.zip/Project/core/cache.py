"""
CACHING & STATE MANAGEMENT LAYER
=================================

Manages persistent storage of:
- Optimization results
- Monte Carlo scenario outputs
- Projection cache
- Metadata

Enables non-destructive reweighting and scenario exploration.
"""

import hashlib
import json
import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class ComputationMetadata:
    """Track what was computed, when, and with what configuration."""
    timestamp: str
    dataset_hash: str
    feasibility_config: Dict
    objective_config: Dict
    optimization_time: float
    monte_carlo_time: float
    n_scenarios: int
    solver_status: str
    

class StateCache:
    """
    Manages computation results and metadata.
    
    Implements:
    - Hash-based invalidation
    - Lazy computation triggering
    - Scenario result storage
    """
    
    def __init__(self):
        self.optimization_result = None      # x*, solver status
        self.marginal_contributions = None   # Dict[str, ndarray(S, N)]
        self.metadata = None                 # ComputationMetadata
        
        # Cache keys for invalidation tracking
        self._feasibility_hash = None
        self._objective_hash = None
        self._dataset_hash = None
    
    def set_optimization_result(
        self,
        x_star: np.ndarray,
        solver_status: str,
        computation_time: float,
        feasibility_config: Dict,
        objective_config: Dict,
        dataset_hash: str,
        n_scenarios: int = 0
    ):
        """Store optimization result with metadata."""
        self.optimization_result = {
            "x_star": x_star,
            "solver_status": solver_status,
            "computation_time": computation_time
        }
        
        self.metadata = ComputationMetadata(
            timestamp=datetime.now().isoformat(),
            dataset_hash=dataset_hash,
            feasibility_config=feasibility_config,
            objective_config=objective_config,
            optimization_time=computation_time,
            monte_carlo_time=0,
            n_scenarios=n_scenarios,
            solver_status=solver_status
        )
        
        self._feasibility_hash = hash_dict(feasibility_config)
        self._objective_hash = hash_dict(objective_config)
        self._dataset_hash = dataset_hash
    
    def set_marginal_contributions(
        self,
        marginals: Dict[str, np.ndarray],
        monte_carlo_time: float,
        n_scenarios: int
    ):
        """Store Monte Carlo marginal contribution results."""
        self.marginal_contributions = marginals
        
        if self.metadata:
            self.metadata.monte_carlo_time = monte_carlo_time
            self.metadata.n_scenarios = n_scenarios
    
    def has_valid_optimization(
        self,
        feasibility_config: Dict,
        objective_config: Dict,
        dataset_hash: str
    ) -> bool:
        """Check if cached optimization is valid for current config."""
        if self.optimization_result is None:
            return False
        
        return (
            hash_dict(feasibility_config) == self._feasibility_hash and
            hash_dict(objective_config) == self._objective_hash and
            dataset_hash == self._dataset_hash
        )
    
    def has_valid_monte_carlo(
        self,
        feasibility_config: Dict,
        objective_config: Dict,
        dataset_hash: str
    ) -> bool:
        """Check if cached Monte Carlo results are valid."""
        if self.marginal_contributions is None:
            return False
        
        return (
            hash_dict(feasibility_config) == self._feasibility_hash and
            hash_dict(objective_config) == self._objective_config and
            dataset_hash == self._dataset_hash
        )
    
    def invalidate_optimization(self):
        """Clear cached optimization (but keep Monte Carlo)."""
        self.optimization_result = None
        if self.metadata:
            self.metadata.solver_status = "invalidated"
    
    def invalidate_all(self):
        """Clear all cached results."""
        self.optimization_result = None
        self.marginal_contributions = None
        self.metadata = None
        self._feasibility_hash = None
        self._objective_hash = None
        self._dataset_hash = None
    
    def get_summary(self) -> Dict[str, Any]:
        """Get human-readable summary of cached state."""
        if self.metadata is None:
            return {"status": "empty"}
        
        return {
            "status": "cached",
            "timestamp": self.metadata.timestamp,
            "optimization_time": f"{self.metadata.optimization_time:.2f}s",
            "monte_carlo_time": f"{self.metadata.monte_carlo_time:.2f}s",
            "n_scenarios": self.metadata.n_scenarios,
            "solver_status": self.metadata.solver_status,
            "has_optimization": self.optimization_result is not None,
            "has_monte_carlo": self.marginal_contributions is not None
        }
    
    @property
    def objectives(self) -> Optional[Dict]:
        """Get objectives from metadata if available."""
        if self.metadata:
            return self.metadata.objective_config
        return None


class SessionStateManager:
    """
    Streamlit session state wrapper with validation.
    Ensures clean state transitions.
    """
    
    def __init__(self, streamlit_session):
        """
        Parameters
        ----------
        streamlit_session : streamlit.delta_generator.DeltaGenerator.session_state
        """
        self.st_session = streamlit_session
        self._ensure_keys()
    
    def _ensure_keys(self):
        """Initialize required session state keys."""
        required_keys = {
            "cache": StateCache,
            "data": None,
            "raw_df": None,
            "norm_df": None,
            "dataset_hash": None,
            "current_feasibility": None,
            "current_objectives": None,
            "computation_in_progress": False,
            "last_error": None
        }
        
        for key, default_value in required_keys.items():
            if key not in self.st_session:
                if isinstance(default_value, type):
                    self.st_session[key] = default_value()
                else:
                    self.st_session[key] = default_value
    
    def set_data(self, raw_df, norm_df, dataset_hash):
        """Update loaded data."""
        self.st_session.raw_df = raw_df
        self.st_session.norm_df = norm_df
        self.st_session.dataset_hash = dataset_hash
        self.st_session.cache.invalidate_all()  # New data = new everything
    
    def set_config(self, feasibility_config, objective_config):
        """Update current configuration."""
        self.st_session.current_feasibility = feasibility_config
        self.st_session.current_objectives = objective_config
    
    def get_cache(self) -> StateCache:
        """Get the computation cache."""
        return self.st_session.cache
    
    def record_error(self, error_msg: str):
        """Log error for debugging."""
        self.st_session.last_error = error_msg
    
    def get_summary(self) -> Dict[str, Any]:
        """Get state summary for UI."""
        return {
            "cache": self.st_session.cache.get_summary(),
            "data_loaded": self.st_session.raw_df is not None,
            "computation_in_progress": self.st_session.computation_in_progress,
            "last_error": self.st_session.last_error
        }


def hash_dict(d: Dict) -> str:
    """
    Create hash of dictionary for cache invalidation.
    
    Handles nested dicts and non-serializable objects gracefully.
    """
    try:
        serialized = json.dumps(d, sort_keys=True, default=str)
    except (TypeError, ValueError):
        serialized = str(sorted(d.items()))
    
    return hashlib.md5(serialized.encode()).hexdigest()


def hash_dataframe(df: pd.DataFrame) -> str:
    """Create hash of DataFrame contents."""
    return hashlib.md5(
        pd.util.hash_pandas_object(df, index=True).values
    ).hexdigest()
