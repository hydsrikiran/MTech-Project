"""
EXPLAINABILITY ENGINE
====================

Generates human-readable explanations for:
- Why a vehicle is ranked high/low
- Which objectives drive each decision
- What happens if you change preferences
- Sensitivity analysis

This is critical for patent-level, human-centered decision support.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple


class ExplainabilityEngine:
    """
    Generates structured explanations for vehicle recommendations.
    
    Explains:
    1. Why is this vehicle recommended?
    2. What would happen if you changed objectives?
    3. Which factors are critical?
    """
    
    def __init__(
        self,
        vehicle_data: pd.DataFrame,
        projection_engine,
        vehicle_ids: List[str]
    ):
        """
        Parameters
        ----------
        vehicle_data : pd.DataFrame
            Raw vehicle attributes
        projection_engine : ProjectionEngine
            For computing reweighted metrics
        vehicle_ids : List[str]
        """
        self.vehicle_data = vehicle_data
        self.projection = projection_engine
        self.vehicle_ids = vehicle_ids
    
    def explain_vehicle_recommendation(
        self,
        vehicle_idx: int,
        objective_weights: Dict[str, float],
        rank: int,
        classification: str
    ) -> Dict:
        """
        Generate comprehensive explanation for a vehicle's ranking.
        
        Returns
        -------
        explanation : Dict
            - summary: One-line reason
            - detailed: Multi-line explanation
            - key_drivers: Which objectives matter most
            - what_if: What changes would affect this vehicle
        """
        
        vehicle_id = self.vehicle_ids[vehicle_idx]
        
        # Get contribution breakdown
        contribution_df = self.projection.get_contribution_breakdown(
            vehicle_idx, objective_weights
        )
        
        # Get ranking info
        rpi = self.projection.project_rpi(objective_weights)[vehicle_idx]
        vol = self.projection.project_volatility(objective_weights)[vehicle_idx]
        
        # Summary
        summary = self._generate_summary(
            rank, classification, rpi, vol, contribution_df
        )
        
        # Key drivers (top 2-3 objectives)
        top_drivers = contribution_df.head(2)["Objective"].tolist()
        
        # What-if scenarios
        what_if = self._generate_what_if(
            vehicle_idx, vehicle_id, rpi, vol, contribution_df
        )
        
        return {
            "vehicle_id": vehicle_id,
            "rank": rank,
            "classification": classification,
            "rpi": float(rpi),
            "volatility": float(vol),
            "summary": summary,
            "top_drivers": top_drivers,
            "contribution_breakdown": contribution_df.to_dict("records"),
            "what_if_scenarios": what_if
        }
    
    def _generate_summary(
        self,
        rank: int,
        classification: str,
        rpi: float,
        volatility: float,
        contributions: pd.DataFrame
    ) -> str:
        """Generate one-line explanation."""
        
        main_driver = contributions.iloc[0]["Objective"] if len(contributions) > 0 else "Unknown"
        
        if "High-Priority" in classification:
            return (
                f"Rank #{rank}: High replacement priority driven by {main_driver}. "
                f"Strong potential benefit (RPI: {rpi:.2f})."
            )
        elif "Low-Priority" in classification:
            return (
                f"Rank #{rank}: Low replacement priority. "
                f"Consider this vehicle later in implementation."
            )
        elif "Feasibility-Critical" in classification:
            return (
                f"Rank #{rank}: CRITICAL. This vehicle is essential for feasibility. "
                f"Must be included in any implementation."
            )
        else:
            return (
                f"Rank #{rank}: Medium priority. "
                f"Flexible in implementation sequence."
            )
    
    def _generate_what_if(
        self,
        vehicle_idx: int,
        vehicle_id: str,
        current_rpi: float,
        current_vol: float,
        current_contributions: pd.DataFrame
    ) -> List[Dict]:
        """
        Generate what-if scenarios: how would this vehicle's rank change?
        """
        scenarios = []
        
        # What if we emphasize each objective?
        for obj_name in current_contributions["Objective"].unique():
            test_weights = {obj_name: 1.0}  # Only this objective
            test_rpi = self.projection.project_rpi(test_weights)[vehicle_idx]
            
            change = ((test_rpi - current_rpi) / (abs(current_rpi) + 1e-9)) * 100
            
            if abs(change) > 5:  # Only show significant changes
                scenarios.append({
                    "scenario": f"If only {obj_name} mattered",
                    "new_rpi": float(test_rpi),
                    "change_percent": float(change),
                    "direction": "↑ Improves" if change > 0 else "↓ Worsens"
                })
        
        return scenarios[:3]  # Top 3 scenarios
    
    def generate_fleet_narrative(
        self,
        objective_weights: Dict[str, float],
        top_n: int = 5
    ) -> str:
        """
        Generate a narrative summary of the fleet status.
        """
        
        summary_df = self.projection.get_summary_table(objective_weights)
        
        high_priority = summary_df[
            summary_df["Classification"].str.contains("High-Priority")
        ]
        critical = summary_df[
            summary_df["Classification"].str.contains("Feasibility-Critical")
        ]
        
        narrative = f"""
FLEET ELECTRIFICATION ASSESSMENT
================================

## Executive Summary

Total Fleet Size: {len(summary_df)} vehicles

Critical Vehicles (Must Include): {len(critical)}
High-Priority Vehicles: {len(high_priority)}

## Top {top_n} Candidates for Replacement

"""
        
        for idx, row in summary_df.head(top_n).iterrows():
            narrative += f"""
### {idx + 1}. {row['vehicle_id']}
- **Rank**: {row['rank']}
- **Priority Score**: {row['RPI']:.3f}
- **Stability**: {row['Volatility']:.3f}
- **Category**: {row['Classification']}
"""
        
        narrative += f"""

## Key Insights

1. **Volatility Analysis**: {self._volatility_insight(summary_df)}
2. **Robustness**: {self._robustness_insight(summary_df)}
3. **Implementation Strategy**: {self._implementation_strategy(summary_df)}
"""
        
        return narrative
    
    def _volatility_insight(self, summary_df: pd.DataFrame) -> str:
        """Generate insight about decision volatility."""
        avg_vol = summary_df["Volatility"].mean()
        high_vol = (summary_df["Volatility"] > summary_df["Volatility"].quantile(0.75)).sum()
        
        if high_vol > len(summary_df) * 0.3:
            return f"Fleet is highly sensitive to scenario changes ({high_vol} vehicles). Recommend conservative phasing."
        else:
            return f"Fleet decisions are relatively stable across scenarios. Safe to accelerate replacement."
    
    def _robustness_insight(self, summary_df: pd.DataFrame) -> str:
        """Generate insight about decision robustness."""
        robust = (summary_df["Classification"].str.contains("Robust")).sum()
        sensitive = (summary_df["Classification"].str.contains("Sensitive")).sum()
        
        ratio = robust / (sensitive + 1e-9)
        
        if ratio > 1.5:
            return f"Strong consensus on priorities ({robust} robust decisions). High confidence in recommendations."
        else:
            return f"Mixed signals ({robust} robust, {sensitive} sensitive). Consider wider stakeholder input."
    
    def _implementation_strategy(self, summary_df: pd.DataFrame) -> str:
        """Generate implementation recommendation."""
        high_priority = (summary_df["Classification"].str.contains("High-Priority")).sum()
        low_priority = (summary_df["Classification"].str.contains("Low-Priority")).sum()
        
        if high_priority <= 3:
            return f"Small high-priority set ({high_priority} vehicles). Consider pilot phase first."
        elif high_priority <= 10:
            return f"Manageable high-priority set ({high_priority} vehicles). Recommend phased rollout in 2-3 waves."
        else:
            return f"Large replacement cohort ({high_priority} vehicles). Recommend 3-4 implementation phases."


class SensitivityAnalysis:
    """
    Analyze how vehicle rankings change with parameter variations.
    """
    
    def __init__(self, projection_engine, vehicle_ids: List[str]):
        self.projection = projection_engine
        self.vehicle_ids = vehicle_ids
    
    def objective_sensitivity(
        self,
        base_weights: Dict[str, float],
        n_points: int = 11
    ) -> Dict:
        """
        How does each vehicle's ranking change as objective weights vary?
        """
        
        results = {}
        
        for obj_name in base_weights.keys():
            weights_variation = []
            rpi_variation = []
            
            for factor in np.linspace(0.1, 2.0, n_points):
                test_weights = base_weights.copy()
                test_weights[obj_name] = base_weights[obj_name] * factor
                
                rpi = self.projection.project_rpi(test_weights)
                rankings = np.argsort(-rpi)
                
                weights_variation.append(factor)
                rpi_variation.append(rpi)
            
            results[obj_name] = {
                "weight_factors": weights_variation,
                "rpi_by_vehicle": {
                    self.vehicle_ids[i]: [float(rpi_var[i]) for rpi_var in rpi_variation]
                    for i in range(len(self.vehicle_ids))
                }
            }
        
        return results
    
    def ranking_stability(
        self,
        base_weights: Dict[str, float],
        n_samples: int = 100
    ) -> pd.DataFrame:
        """
        For each vehicle, how often is it in top-K across weight perturbations?
        """
        
        top_k_counts = {v_id: 0 for v_id in self.vehicle_ids}
        
        for _ in range(n_samples):
            # Random perturbation of weights (±20%)
            test_weights = {}
            for obj, w in base_weights.items():
                perturbation = np.random.normal(0, 0.2)
                test_weights[obj] = w * np.exp(perturbation)
            
            # Normalize
            total = sum(test_weights.values())
            test_weights = {k: v / total for k, v in test_weights.items()}
            
            # Get top 5
            rpi = self.projection.project_rpi(test_weights)
            top_indices = np.argsort(-rpi)[:5]
            
            for idx in top_indices:
                top_k_counts[self.vehicle_ids[idx]] += 1
        
        df = pd.DataFrame({
            "vehicle_id": list(top_k_counts.keys()),
            "top_5_frequency": list(top_k_counts.values()),
            "stability_percent": [100 * c / n_samples for c in top_k_counts.values()]
        })
        
        return df.sort_values("stability_percent", ascending=False)
