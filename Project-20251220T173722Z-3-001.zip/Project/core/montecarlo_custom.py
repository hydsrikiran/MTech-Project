"""
Monte Carlo Engine for Custom Objectives
=========================================

Extends MonteCarloEngine to work with CustomObjectiveBuilder
instead of ObjectiveCompositionEngine.

RESEARCH-GRADE: Computes full marginal contributions via vehicle removal,
not just objective values. Required for patent/thesis documentation.
"""

import numpy as np
import pandas as pd
from typing import Dict
from core.marginal import MarginalContributionEngine


class MonteCarloEngineCustom:
    """
    Monte Carlo simulation with custom objectives.
    
    Perturbs input data and re-runs optimization across scenarios
    to compute per-vehicle marginal contributions.
    """
    
    def __init__(
        self,
        raw_df: pd.DataFrame,
        norm_df: pd.DataFrame,
        builder,  # CustomObjectiveBuilder instance
        feasibility_config: Dict,
        n_scenarios: int = 50,
        seed: int = 42
    ):
        """
        Initialize Monte Carlo engine for custom objectives.
        
        Args:
            raw_df: Raw vehicle data
            norm_df: Normalized vehicle data
            builder: CustomObjectiveBuilder instance
            feasibility_config: Feasibility constraints
            n_scenarios: Number of perturbation scenarios
            seed: Random seed
        """
        self.raw_df = raw_df
        self.norm_df = norm_df
        self.builder = builder
        self.feasibility_config = feasibility_config
        self.n_scenarios = n_scenarios
        self.rng = np.random.default_rng(seed)
    
    def _perturb_inputs(self) -> tuple:
        """
        Perturb vehicle data with ±5% normal noise.
        
        Returns:
            (perturbed_raw, perturbed_norm)
        """
        perturbation = self.rng.normal(1.0, 0.05, size=self.raw_df.shape)
        
        perturbed_raw = self.raw_df.copy()
        numeric_cols = self.raw_df.select_dtypes(include=[np.number]).columns
        
        for col in numeric_cols:
            if col != 'vehicle_id':
                col_idx = self.raw_df.columns.get_loc(col)
                perturbed_raw[col] = self.raw_df[col] * perturbation[:, col_idx]
                perturbed_raw[col] = perturbed_raw[col].clip(lower=0)
        
        # Re-normalize using data-driven approach (not metadata)
        perturbed_norm = perturbed_raw.copy()
        for col in numeric_cols:
            if col != 'vehicle_id':
                min_val = perturbed_raw[col].min()
                max_val = perturbed_raw[col].max()
                if max_val > min_val:
                    perturbed_norm[col] = (perturbed_raw[col] - min_val) / (max_val - min_val)
                    perturbed_norm[col] = perturbed_norm[col].clip(0, 1)
                else:
                    perturbed_norm[col] = 0.0
        
        return perturbed_raw, perturbed_norm
    
    def run(self) -> Dict[str, np.ndarray]:
        """
        Run Monte Carlo scenarios with FULL MARGINAL COMPUTATION.
        
        RESEARCH-GRADE approach (required for patent/thesis):
        For each scenario:
        1. Perturb vehicle data (±5% normally distributed)
        2. Re-normalize
        3. Rebuild objectives with builder's fixed config
        4. COMPUTE MARGINALS via vehicle removal (MarginalContributionEngine)
           - Shows each vehicle's TRUE contribution via removal analysis
           - Mathematically rigorous for patent documentation
        
        Returns:
            Dict[objective_name -> ndarray(S, N)]
            where S = scenarios, N = vehicles
            
        Note: Takes ~30-60s (like app_refactored.py) because of full marginal computation.
              This is necessary for research/patent-grade analysis.
        """
        
        n_vehicles = len(self.raw_df)
        objective_names = self.builder.list_objectives()
        
        # Initialize scenario storage
        marginals = {
            obj_name: np.zeros((self.n_scenarios, n_vehicles))
            for obj_name in objective_names
        }
        
        print(f"Running {self.n_scenarios} Monte Carlo scenarios with FULL MARGINAL COMPUTATION...")
        print(f"(Research-grade: computes marginals via vehicle removal)")
        print(f"Estimated time: ~{self.n_scenarios * 0.5:.0f}-{self.n_scenarios * 1.0:.0f} seconds\n")
        
        for scenario in range(self.n_scenarios):
            try:
                # Perturb inputs
                perturbed_raw, perturbed_norm = self._perturb_inputs()
                
                # Build objectives for this scenario using perturbed normalized data
                scenario_objectives = self.builder.build(norm_df=perturbed_norm)
                
                # RESEARCH-GRADE: Compute full marginals via vehicle removal
                # This shows each vehicle's true contribution by removing it and re-solving
                marginal_engine = MarginalContributionEngine(
                    perturbed_raw,
                    perturbed_norm,
                    scenario_objectives,
                    self.feasibility_config
                )
                
                # Compute marginal contributions (requires solving optimization multiple times)
                scenario_marginals = marginal_engine.compute_marginal_contributions()
                
                # Store in result dict
                for obj_name in objective_names:
                    if obj_name in scenario_marginals:
                        marginals[obj_name][scenario, :] = scenario_marginals[obj_name]
                
            except Exception as e:
                print(f"Error: Scenario {scenario} failed: {str(e)}")
                raise
            
            if (scenario + 1) % 10 == 0:
                print(f"  Completed {scenario + 1}/{self.n_scenarios} scenarios")
        
        print("Monte Carlo complete!")
        return marginals

