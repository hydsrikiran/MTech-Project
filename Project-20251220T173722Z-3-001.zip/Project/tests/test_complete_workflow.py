#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Complete workflow test with updated fleet_sample.csv
"""

import pandas as pd
import numpy as np
import json
from core.objective_composer import ObjectiveCompositionEngine, PolicyState
from core.validation import DatasetValidator
from core.optimize import OptimizationEngine
from core.montecarlo import MonteCarloEngine

def normalize_data(raw_df, metadata):
    """Normalize data to [0,1] scale based on metadata valid ranges."""
    norm_df = raw_df.copy()
    
    for col in raw_df.columns:
        if col == 'vehicle_id':
            continue
        if col not in metadata:
            continue
            
        var_config = metadata[col]
        min_val, max_val = var_config.get('valid_range', [0, 100])
        
        # Handle null (unlimited) max by using 2*max of data
        if max_val is None:
            max_val = raw_df[col].max() * 1.5
        if min_val is None:
            min_val = raw_df[col].min() * 0.5
        
        norm_df[col] = (raw_df[col] - min_val) / (max_val - min_val + 1e-6)
        norm_df[col] = norm_df[col].clip(0, 1)
    
    return norm_df

# Load metadata
with open('variable_metadata.json') as f:
    metadata = json.load(f)

# Load data
print("Loading fleet_sample.csv...")
raw_df = pd.read_csv('fleet_sample.csv')
print(f"[OK] Loaded {len(raw_df)} vehicles with {len(raw_df.columns)} variables")
print(f"  Columns: {list(raw_df.columns)}")

# Normalize data
print("\nNormalizing data...")
norm_df = normalize_data(raw_df, metadata)
print(f"[OK] Data normalized to [0,1] scale")

# Validate data
print("\nValidating data...")
validator = DatasetValidator()
validation_result = validator.validate(raw_df)
print(f"[OK] Validation: {validation_result.status}")
if validation_result.messages:
    for msg in validation_result.messages:
        print(f"  {msg}")

# Create policy state
print("\nCreating policy state...")
policy = PolicyState(
    EV_mandate=True,
    subsidy_active=True,
    carbon_tax_per_gco2=0.05,  # $/g CO2
    emission_cap_gpkm=150,  # g/km
    region='urban',
    year=2024
)
print(f"[OK] Policy State: EV Mandate={policy.EV_mandate}, Subsidy={policy.subsidy_active}, Tax=${policy.carbon_tax_per_gco2}/g CO2")

# Create feasibility constraints
print("\nCreating feasibility constraints...")
feasibility = {
    'budget_limit': 10000000,  # 10M INR
    'service_level': 0.95,     # 95% uptime
    'charging_capacity': 100,  # units
    'mandatory_replacement': False
}
print(f"[OK] Feasibility: Budget={feasibility['budget_limit']:,} INR, Service Level={feasibility['service_level']:.0%}")

# Build objectives
print("\nBuilding objectives with OCE...")
oce = ObjectiveCompositionEngine(raw_df, norm_df, policy)
objectives = oce.build_objectives()
print(f"[OK] Created {len(objectives)} objectives:")
for obj_name, obj_values in objectives.items():
    print(f"  - {obj_name}: mean={obj_values.mean():.3f}, std={obj_values.std():.3f}")

# Run optimization
print("\nRunning optimization...")
try:
    opt_engine = OptimizationEngine(raw_df, norm_df, objectives, feasibility)
    selected_vehicles, objective_values = opt_engine.solve()
    print(f"[OK] Optimization complete")
    print(f"  Selected vehicles: {selected_vehicles}")
    print(f"  Objective values: {objective_values}")
except Exception as e:
    print(f"[FAIL] Optimization failed: {e}")
    import traceback
    traceback.print_exc()

# Run Monte Carlo
print("\nRunning Monte Carlo analysis (5 scenarios)...")
try:
    mc_engine = MonteCarloEngine(raw_df, oce, feasibility, n_scenarios=5, seed=42)
    mc_results = mc_engine.run()
    print(f"[OK] Monte Carlo complete")
    print(f"  Scenario count: {len(mc_results)}")
    print(f"  Objectives keys: {list(mc_results.keys())}")
except Exception as e:
    print(f"[FAIL] Monte Carlo failed: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*60)
print("WORKFLOW TEST COMPLETE")
print("="*60)
