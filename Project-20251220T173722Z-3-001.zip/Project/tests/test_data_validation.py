#!/usr/bin/env python3
"""Test core/data.py schema validation with fleet_sample.csv"""

from core.data import validate_schema, normalize
import pandas as pd

# Load the sample data
df = pd.read_csv('fleet_sample.csv')

print("Testing core/data.py schema validation...")
print(f"Columns in fleet_sample.csv: {len(df.columns)}")
print(f"Columns: {list(df.columns)}\n")

# Test validation
try:
    validate_schema(df)
    print("[OK] Schema validation passed!")
except ValueError as e:
    print(f"[FAIL] Schema validation failed: {e}")

# Test normalization
try:
    norm_df = normalize(df)
    print("[OK] Normalization successful!")
    print(f"Normalized shape: {norm_df.shape}")
    print(f"Sample normalized values (row 0):")
    for col in list(df.columns)[:5]:
        print(f"  {col}: {df.iloc[0][col]} -> {norm_df.iloc[0][col]:.3f}")
except Exception as e:
    print(f"[FAIL] Normalization failed: {e}")

print("\nData loading pipeline: READY FOR STREAMLIT")
