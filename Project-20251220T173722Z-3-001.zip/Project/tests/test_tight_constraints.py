"""Test: What DOES produce non-zero marginals?"""
import numpy as np
from core.data import load_and_prepare
from core.custom_objectives import CustomObjectiveBuilder
from core.optimize import OptimizationEngine
from core.marginal import MarginalContributionEngine

raw, norm = load_and_prepare('fleet_sample.csv')

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])
builder.add_objective('Operations', ['maintenance_cost_per_year', 'downtime_cost_per_day'], [0.6, 0.4])
builder.add_objective('Asset Quality', ['reliability_score', 'remaining_useful_life'], [0.7, 0.3])

objectives = builder.build()

# MUCH TIGHTER: budget barely covers 2 vehicles
tight_feas = {
    'budget': 2_600_000,  # Only 2 vehicles max
    'service_level': 0.99,  # Very strict
    'charging_capacity': 80,  # High demand
    'min_fleet_size': 2,
}

print("=" * 70)
print("TEST: EXTREMELY TIGHT CONSTRAINTS")
print("=" * 70)
print(f"Budget: ₹2.6M (forces hard choice)")
print(f"Service: 99%")
print(f"Charging: 80%")
print()

opt = OptimizationEngine(raw, norm, objectives, tight_feas)
x_base, obj_base = opt.solve()
selected = [i for i in range(10) if x_base[i] > 0.5]
cost = raw.iloc[selected]['capex_ev'].sum() if selected else 0

print(f"Selected: {selected}")
print(f"Budget used: ₹{cost:,.0f}")
print()

engine = MarginalContributionEngine(raw, norm, objectives, tight_feas)
marginals = engine.compute_marginal_contributions()

print("Marginals:")
for obj_name, m in marginals.items():
    print(f"  {obj_name}: {m}")
    print(f"    All zero? {np.all(m == 0)}")

if not np.all(marginals['Cost'] == 0):
    print("\n✓ SUCCESS! Non-zero marginals found!")
    print("  This means the constraint is TIGHT enough that")
    print("  vehicle removal DOES degrade performance")
else:
    print("\n⚠️ Still degenerate even with ₹2.6M budget")
    print("   Try even tighter: ₹2.4M or ₹2.3M")
