from core.custom_objectives import CustomObjectiveBuilder
from core.data import load_and_prepare
from core.marginal import MarginalContributionEngine
import numpy as np

raw, norm = load_and_prepare('fleet_sample.csv')

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])

objectives = builder.build()

# Test with tight constraints (like user has)
tight_feas = {
    'budget': 12_190_000,
    'min_fleet_size': 5,
    'min_service_level': 0.95,
    'max_charging_load': 50
}

print("Testing MarginalContributionEngine with tight constraints...")
print(f"Budget: {tight_feas['budget']:,}")
print(f"Min fleet: {tight_feas['min_fleet_size']}")
print()

engine = MarginalContributionEngine(raw, norm, objectives, tight_feas)

# Get baseline
baseline_x, baseline_objs = engine.baseline_solution()
print(f"Baseline: {int(sum(baseline_x))} vehicles selected")
print(f"Baseline Cost: {baseline_objs['Cost']:.3f}")
print()

# Compute marginals
print("Computing marginals...")
marginals = engine.compute_marginal_contributions()

print("\nMarginals for Cost objective:")
print(marginals['Cost'])
print(f"\nContains inf? {np.any(np.isinf(marginals['Cost']))}")
if not np.all(np.isinf(marginals['Cost'])):
    finite = marginals['Cost'][~np.isinf(marginals['Cost'])]
    print(f"Min: {np.min(finite):.3f}")
    print(f"Max: {np.max(finite):.3f}")
else:
    print("All values are inf - all vehicles critical!")
