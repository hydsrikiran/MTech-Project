"""Quick test: Does the new budget work?"""
from core.data import load_and_prepare
from core.custom_objectives import CustomObjectiveBuilder
from core.optimize import OptimizationEngine

raw, norm = load_and_prepare('fleet_sample.csv')
avg_cost = raw['capex_ev'].mean()
budget = int(avg_cost * 3.0)

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])
builder.add_objective('Operations', ['maintenance_cost_per_year', 'downtime_cost_per_day'], [0.6, 0.4])
builder.add_objective('Asset Quality', ['reliability_score', 'remaining_useful_life'], [0.7, 0.3])

objectives = builder.build()

feas = {
    'budget': budget,
    'service_level': 0.95,
    'charging_capacity': 50,
    'min_fleet_size': 3,
}

print(f"Budget: ₹{budget:,}")
print("Running optimization...")

try:
    opt = OptimizationEngine(raw, norm, objectives, feas)
    x_star, _ = opt.solve()
    selected = [i for i in range(10) if x_star[i] > 0.5]
    print(f"✓ SUCCESS! Selected: {selected}")
except Exception as e:
    print(f"✗ FAILED: {e}")
