"""Deep dive: what's really in the marginals?"""
import numpy as np
from core.data import load_and_prepare
from core.custom_objectives import CustomObjectiveBuilder
from core.marginal import MarginalContributionEngine

raw, norm = load_and_prepare('fleet_sample.csv')

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm'], [1.0])

objectives = builder.build()

feas = {
    'budget': 12_190_000,
    'service_level': 0.95,
    'charging_capacity': 50,
    'min_fleet_size': 5,
}

print("=" * 70)
print("MARGINAL CONTRIBUTION ANALYSIS")
print("=" * 70)

engine = MarginalContributionEngine(raw, norm, objectives, feas)

# Get baseline
print("\n1. BASELINE SOLUTION")
x_base, obj_base = engine.baseline_solution()
selected = [i for i in range(10) if x_base[i] > 0.5]
print(f"  Selected vehicles: {selected}")
print(f"  Cost objective: {obj_base['Cost']:.6f}")
print(f"  Environment objective: {obj_base['Environment']:.6f}")

# Compute marginals
print("\n2. COMPUTING MARGINALS (removing each baseline vehicle)...")
marginals = engine.compute_marginal_contributions()

print(f"  Cost marginals: {marginals['Cost']}")
print(f"  Env marginals: {marginals['Environment']}")

print("\n3. INTERPRETATION")
for i in range(10):
    cost_marg = marginals['Cost'][i]
    env_marg = marginals['Environment'][i]
    in_baseline = "✓ SELECTED" if x_base[i] > 0.5 else "  unselected"
    print(f"  V{i:02d} {in_baseline}: Cost_marg={cost_marg:+.6f}, Env_marg={env_marg:+.6f}")

print(f"\n4. ANALYSIS")
print(f"  All Cost marginals zero? {np.all(marginals['Cost'] == 0)}")
print(f"  All Env marginals zero? {np.all(marginals['Environment'] == 0)}")
print(f"  This means: Each selected vehicle's removal doesn't change objectives")
print(f"  Implication: Alternative vehicles could substitute without loss")
