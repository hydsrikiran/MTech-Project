from core.custom_objectives import CustomObjectiveBuilder
from core.data import load_and_prepare
from core.montecarlo_custom import MonteCarloEngineCustom
import time

raw, norm = load_and_prepare('fleet_sample.csv')

builder = CustomObjectiveBuilder(norm, {})
builder.add_objective('Cost', ['fuel_cost_per_km', 'capex_ev'], [0.5, 0.5])
builder.add_objective('Environment', ['co2_emission_gpkm', 'pollutants_index'], [0.5, 0.5])
builder.add_objective('Operations', ['utilization_percent', 'downtime_hours_annual'], [0.5, 0.5])
builder.add_objective('Asset Quality', ['reliability_score', 'vehicle_age'], [0.5, 0.5])

print('Starting MC with 50 scenarios...')
start = time.time()

mc = MonteCarloEngineCustom(
    raw, norm, builder, 
    {'budget': 10_000_000, 'min_fleet_size': 5}, 
    n_scenarios=50
)

# Test individual scenario timing
print('\nTesting single scenario...')
scenario_start = time.time()
for i in range(1):
    perturbed_raw, perturbed_norm = mc._perturb_inputs()
    obj = builder.build(norm_df=perturbed_norm)
scenario_elapsed = time.time() - scenario_start
print(f'Single scenario took {scenario_elapsed:.3f}s')
print(f'50 scenarios would take ~{scenario_elapsed * 50:.1f}s')

print('\nRunning full MC...')
mc2 = MonteCarloEngineCustom(
    raw, norm, builder, 
    {'budget': 10_000_000, 'min_fleet_size': 5}, 
    n_scenarios=50
)
marginals = mc2.run()

elapsed = time.time() - start
print(f'\nTotal time: {elapsed:.1f}s')
print(f'Marginals shape: {marginals["Cost"].shape}')

