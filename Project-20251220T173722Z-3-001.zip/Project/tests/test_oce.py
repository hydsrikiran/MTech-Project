"""
Quick test of Objective Composition Engine (OCE)

Run this to see OCE in action with sample data.
"""

import pandas as pd
import numpy as np
from core.objective_composer import ObjectiveCompositionEngine, PolicyState
from core.variable_registry import VARIABLE_REGISTRY

# ============================================================================
# Create sample data
# ============================================================================

np.random.seed(42)
n_vehicles = 10

raw_df = pd.DataFrame({
    "vehicle_id": [f"V{i:03d}" for i in range(n_vehicles)],
    "fuel_cost_per_km": np.random.uniform(8, 15, n_vehicles),
    "maintenance_cost_per_year": np.random.uniform(20000, 80000, n_vehicles),
    "capex_ev": np.random.uniform(800000, 1500000, n_vehicles),
    "downtime_cost_per_day": np.random.uniform(5000, 15000, n_vehicles),
    "co2_emission_gpkm": np.random.uniform(60, 200, n_vehicles),
    "pollutants_index": np.random.uniform(20, 80, n_vehicles),
    "compliance_liability": np.random.uniform(0, 50000, n_vehicles),
    "utilization_percent": np.random.uniform(50, 95, n_vehicles),
    "service_criticality": np.random.uniform(1, 10, n_vehicles),
    "downtime_hours_annual": np.random.uniform(50, 500, n_vehicles),
    "vehicle_age": np.random.uniform(2, 12, n_vehicles),
    "remaining_useful_life": np.random.uniform(1, 10, n_vehicles),
    "reliability_score": np.random.uniform(50, 95, n_vehicles),
    "charging_availability": np.random.uniform(20, 95, n_vehicles),
    "grid_dependency": np.random.uniform(10, 80, n_vehicles),
    "fuel_price_volatility": np.random.uniform(0.1, 0.4, n_vehicles),
    "policy_stability_score": np.random.uniform(40, 90, n_vehicles),
})

# Normalize [0, 1]
norm_df = raw_df.copy()
for col in norm_df.columns:
    if col != "vehicle_id":
        min_val = norm_df[col].min()
        max_val = norm_df[col].max()
        if max_val > min_val:
            norm_df[col] = (norm_df[col] - min_val) / (max_val - min_val)
        else:
            norm_df[col] = 0.5


# ============================================================================
# Test 1: Basic OCE - No Policy
# ============================================================================

print("\n" + "="*80)
print("TEST 1: Basic OCE - No Policy")
print("="*80)

policy = PolicyState()
oce = ObjectiveCompositionEngine(raw_df, norm_df, policy)
objectives = oce.build_objectives()

print("\nObjectives built:")
for obj_name, obj_values in objectives.items():
    print(f"  {obj_name}: min={obj_values.min():.3f}, max={obj_values.max():.3f}, mean={obj_values.mean():.3f}")

print("\nSummary:")
summary = oce.get_summary()
for obj_name, stats in summary.items():
    print(f"  {obj_name}: {stats}")


# ============================================================================
# Test 2: With Subsidy Policy
# ============================================================================

print("\n" + "="*80)
print("TEST 2: With Subsidy Policy (30% reduction on CAPEX)")
print("="*80)

policy_subsidy = PolicyState(
    subsidy_active=True,
    subsidy_fraction=0.30
)

oce_subsidy = ObjectiveCompositionEngine(raw_df, norm_df, policy_subsidy)
objectives_subsidy = oce_subsidy.build_objectives()
objectives_subsidy = oce_subsidy.apply_policy_modifiers()

print("\nObjectives with subsidy:")
for obj_name, obj_values in objectives_subsidy.items():
    print(f"  {obj_name}: min={obj_values.min():.3f}, max={obj_values.max():.3f}, mean={obj_values.mean():.3f}")

# Compare Economic objective
print(f"\nEconomic objective DIFFERENCE (subsidy effect):")
print(f"  Before subsidy: {objectives['Economic'].mean():.3f}")
print(f"  After subsidy:  {objectives_subsidy['Economic'].mean():.3f}")
print(f"  Change:         {objectives_subsidy['Economic'].mean() - objectives['Economic'].mean():.3f} (lower is better)")


# ============================================================================
# Test 3: With Carbon Tax Policy
# ============================================================================

print("\n" + "="*80)
print("TEST 3: With Carbon Tax (2 INR per gCO2)")
print("="*80)

policy_carbon = PolicyState(
    carbon_tax=True,
    carbon_tax_per_gco2=2.0
)

oce_carbon = ObjectiveCompositionEngine(raw_df, norm_df, policy_carbon)
objectives_carbon = oce_carbon.build_objectives()
objectives_carbon = oce_carbon.apply_policy_modifiers()

print("\nObjectives with carbon tax:")
for obj_name, obj_values in objectives_carbon.items():
    print(f"  {obj_name}: min={obj_values.min():.3f}, max={obj_values.max():.3f}, mean={obj_values.mean():.3f}")

print(f"\nEnvironmental objective DIFFERENCE (carbon tax effect):")
print(f"  Before tax: {objectives['Environmental'].mean():.3f}")
print(f"  After tax:  {objectives_carbon['Environmental'].mean():.3f}")
print(f"  Change:     {objectives_carbon['Environmental'].mean() - objectives['Environmental'].mean():.3f} (higher = worse)")


# ============================================================================
# Test 4: Get Contributions for Projection Layer
# ============================================================================

print("\n" + "="*80)
print("TEST 4: Objective Contributions (for Projection Layer)")
print("="*80)

contributions = oce.objective_contributions()

print("\nContributions shape and range:")
for obj_name, contrib_array in contributions.items():
    print(f"  {obj_name}: shape={contrib_array.shape}, range=[{contrib_array.min():.3f}, {contrib_array.max():.3f}]")

print("\nFirst vehicle's contributions:")
for obj_name, contrib_array in contributions.items():
    print(f"  {obj_name}: {contrib_array[0]:.3f}")


# ============================================================================
# Test 5: Variable Registry Inspection
# ============================================================================

print("\n" + "="*80)
print("TEST 5: Variable Registry")
print("="*80)

print(f"\nTotal variables in registry: {len(VARIABLE_REGISTRY)}")
print(f"Categories: {set(v['category'] for v in VARIABLE_REGISTRY.values())}")

print("\nVariables by category:")
categories = set(v['category'] for v in VARIABLE_REGISTRY.values())
for cat in sorted(categories):
    vars_in_cat = [v for v, meta in VARIABLE_REGISTRY.items() if meta['category'] == cat]
    print(f"  {cat}: {vars_in_cat}")

print("\nVariable roles:")
roles = set(v['role'] for v in VARIABLE_REGISTRY.values())
for role in sorted(roles):
    vars_with_role = [v for v, meta in VARIABLE_REGISTRY.items() if meta['role'] == role]
    print(f"  {role}: {vars_with_role}")


# ============================================================================
# Test 6: Export to DataFrame
# ============================================================================

print("\n" + "="*80)
print("TEST 6: Export Objectives to DataFrame")
print("="*80)

result_df = oce.to_dataframe()
print("\nFirst 5 rows:")
print(result_df.head())


print("\n" + "="*80)
print("ALL TESTS COMPLETE ✓")
print("="*80)
